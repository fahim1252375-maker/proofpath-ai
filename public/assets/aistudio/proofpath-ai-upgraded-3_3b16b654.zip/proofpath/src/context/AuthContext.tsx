import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { apiFetch } from '../lib/api.ts';
import { TRANSLATIONS } from '../i18n/translations.ts';
import type { LanguageCode, StudentProfile, UserAccount } from '../types/proofpath.ts';

interface AuthContextValue {
  user: UserAccount | null;
  profile: StudentProfile | null;
  loading: boolean;
  theme: 'dark' | 'light';
  language: LanguageCode;
  geminiConfigured: boolean;
  compareIds: string[];
  unreadNotifications: number;
  t: (typeof TRANSLATIONS)['en'] | (typeof TRANSLATIONS)['bn'];
  toggleTheme: () => void;
  setLanguage: (lang: LanguageCode) => void;
  login: (email: string, password: string) => Promise<UserAccount>;
  register: (name: string, email: string, password: string) => Promise<UserAccount>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  refreshNotifications: () => Promise<void>;
  toggleCompareId: (id: string) => void;
  clearCompareIds: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [geminiConfigured, setGeminiConfigured] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('proofpath_theme');
    return saved === 'light' ? 'light' : 'dark';
  });

  const [language, setLanguageState] = useState<LanguageCode>(() => {
    const saved = localStorage.getItem('proofpath_lang');
    return saved === 'bn' ? 'bn' : 'en';
  });

  const [compareIds, setCompareIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('proofpath_compare');
      return saved ? JSON.parse(saved) : ['demo-opp-consistent', 'demo-opp-contradicted'];
    } catch {
      return ['demo-opp-consistent', 'demo-opp-contradicted'];
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('proofpath_theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('proofpath_lang', language);
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    localStorage.setItem('proofpath_compare', JSON.stringify(compareIds));
  }, [compareIds]);

  const refreshProfile = useCallback(async () => {
    try {
      const data = await apiFetch<{ profile: StudentProfile | null }>('/api/profile');
      setProfile(data.profile);
    } catch {
      setProfile(null);
    }
  }, []);

  const refreshNotifications = useCallback(async () => {
    try {
      const data = await apiFetch<{ notifications: Array<{ is_read: boolean }> }>('/api/notifications');
      setUnreadNotifications(data.notifications.filter((n) => !n.is_read).length);
    } catch {
      setUnreadNotifications(0);
    }
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const [health, me] = await Promise.allSettled([
        apiFetch<{ geminiConfigured: boolean }>('/api/health'),
        apiFetch<{ user: UserAccount }>('/api/auth/me'),
      ]);
      if (health.status === 'fulfilled') {
        setGeminiConfigured(health.value.geminiConfigured);
      }
      if (me.status === 'fulfilled') {
        setUser(me.value.user);
        await Promise.all([refreshProfile(), refreshNotifications()]);
      } else {
        setUser(null);
        setProfile(null);
        setUnreadNotifications(0);
      }
    } finally {
      setLoading(false);
    }
  }, [refreshNotifications, refreshProfile]);

  useEffect(() => {
    void refreshUser();
  }, [refreshUser]);

  const toggleTheme = () => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    if (user) {
      void apiFetch('/api/auth/preferences', {
        method: 'PUT',
        body: JSON.stringify({ preferred_language: lang }),
      }).catch(() => {});
    }
  };

  const login = async (email: string, password: string) => {
    const res = await apiFetch<{ token: string; user: UserAccount }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    localStorage.setItem('proofpath_token', res.token);
    setUser(res.user);
    await Promise.all([refreshProfile(), refreshNotifications()]);
    return res.user;
  };

  const register = async (name: string, email: string, password: string) => {
    const res = await apiFetch<{ token: string; user: UserAccount }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password, preferred_language: language }),
    });
    localStorage.setItem('proofpath_token', res.token);
    setUser(res.user);
    await Promise.all([refreshProfile(), refreshNotifications()]);
    return res.user;
  };

  const logout = async () => {
    await apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    localStorage.removeItem('proofpath_token');
    setUser(null);
    setProfile(null);
    setUnreadNotifications(0);
  };

  const toggleCompareId = (id: string) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 4) return [...prev.slice(1), id];
      return [...prev, id];
    });
  };

  const clearCompareIds = () => setCompareIds([]);

  const t = TRANSLATIONS[language];

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        theme,
        language,
        geminiConfigured,
        compareIds,
        unreadNotifications,
        t,
        toggleTheme,
        setLanguage,
        login,
        register,
        logout,
        refreshUser,
        refreshProfile,
        refreshNotifications,
        toggleCompareId,
        clearCompareIds,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
