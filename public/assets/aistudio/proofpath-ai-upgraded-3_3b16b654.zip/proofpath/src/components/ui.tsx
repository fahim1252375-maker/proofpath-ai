import React, { createContext, useCallback, useContext, useState } from 'react';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';

type ToastKind = 'success' | 'error' | 'info';
interface ToastItem { id: number; kind: ToastKind; message: string }
const ToastCtx = createContext<(message: string, kind?: ToastKind) => void>(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const dismiss = useCallback((id: number) => setItems((p) => p.filter((x) => x.id !== id)), []);
  const push = useCallback((message: string, kind: ToastKind = 'info') => {
    const id = Date.now() + Math.random();
    setItems((p) => [...p.slice(-3), { id, kind, message }]);
    setTimeout(() => dismiss(id), 4200);
  }, [dismiss]);
  const Icon = { success: CheckCircle2, error: AlertCircle, info: Info };
  const tone = { success: 'text-emerald-500', error: 'text-rose-500', info: 'text-blue-500' };
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 w-[min(92vw,22rem)] no-print" aria-live="polite">
        {items.map((t) => {
          const I = Icon[t.kind];
          return (
            <div key={t.id} role="status" className="pp-glass pp-toast-in flex items-start gap-3 p-3 rounded-xl shadow-xl">
              <I className={`w-5 h-5 shrink-0 mt-0.5 ${tone[t.kind]}`} />
              <p className="text-sm flex-1 text-slate-800 dark:text-slate-100">{t.message}</p>
              <button type="button" aria-label="Dismiss" onClick={() => dismiss(t.id)} className="text-slate-400 hover:text-slate-700 dark:hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastCtx.Provider>
  );
}

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`pp-skeleton rounded-lg ${className}`} aria-hidden="true" />;
}

export function StatCard({ label, value, hint, Icon, accent = 'blue' }: {
  label: string; value: React.ReactNode; hint?: string; Icon: React.ComponentType<{ className?: string }>; accent?: 'blue' | 'emerald' | 'amber' | 'rose';
}) {
  const bg = { blue: 'from-blue-500/20 text-blue-500', emerald: 'from-emerald-500/20 text-emerald-500', amber: 'from-amber-500/20 text-amber-500', rose: 'from-rose-500/20 text-rose-500' }[accent];
  return (
    <div className="pp-card p-5 flex items-start justify-between gap-3">
      <div className="space-y-1">
        <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</p>
        <p className="font-display text-3xl font-bold tabular-nums text-slate-900 dark:text-white">{value}</p>
        {hint && <p className="text-xs text-slate-500 dark:text-slate-400">{hint}</p>}
      </div>
      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${bg} to-transparent flex items-center justify-center`}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  );
}
