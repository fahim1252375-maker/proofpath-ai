import React, { useState } from 'react';
import { FileUp, Loader2, ShieldCheck, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { VerificationReportView } from './VerificationReportView.tsx';
import type { VerificationReport } from '../types/proofpath.ts';

const DEMO_SCENARIOS = [
  {
    id: 'case-a',
    label: 'Case A: Consistent Evidence (DEMO)',
    rawText:
      'Nordic Youth Climate Innovation Grant 2027\nHosted by: Nordic Environmental Youth Council\nOpen to international students aged 16-24.\nApplication Fee: Free ($0)\nApplication Deadline: 2027-03-15\nIncludes up to $5,000 micro-grant and free completion certificate.',
    officialUrl: '',
    officialEvidenceText:
      'Official Announcement: Nordic Environmental Youth Council confirms zero application fee ($0), deadline 2027-03-15, open to international students aged 16-24.',
  },
  {
    id: 'case-b',
    label: 'Case B: Contradicted Fee & Eligibility (DEMO)',
    rawText:
      'Global Scholars STEM Summit Fellowship\nPresented by: Global Scholars Exchange Initiative\n100% Free entry! Open to all countries and international students worldwide.\nApplication Deadline: 2027-02-10',
    officialUrl: '',
    officialEvidenceText:
      'Official University Guidelines: Mandatory application fee: $45 before review. Restricted to eligible countries list: Germany, France, UK, Canada, Japan, USA.',
  },
  {
    id: 'case-c',
    label: 'Case C: Insufficient Evidence (DEMO)',
    rawText:
      'Apex Frontier AI Youth Olympiad\nWin $10,000 cash prizes! Submit your project via our messaging group Google Form before 2027-04-01. Open to school and college students.',
    officialUrl: '',
    officialEvidenceText: '',
  },
  {
    id: 'case-d',
    label: 'Case D: Expired Deadline (DEMO)',
    rawText:
      'Pacific Rim Undergraduate Research Exchange\nHosted by: Pacific Academic Consortium\nFully funded summer placement. Application Fee: Free.\nApplication Deadline: 2025-11-30',
    officialUrl: '',
    officialEvidenceText:
      'Official Academic Notice: Pacific Academic Consortium undergraduate research cycle closes 2025-11-30. Zero application fee.',
  },
  {
    id: 'case-e',
    label: 'Case E: Suspicious Payment & Scam Signals (DEMO)',
    rawText:
      'URGENT: Guaranteed International Merit Grant Award!\nGuaranteed scholarship of $15,000 for every applicant who registers within 24 hours! Pay a $35 certificate processing fee via wire transfer or gift card and provide bank routing number.\nDeadline: 2027-01-20',
    officialUrl: '',
    officialEvidenceText: '',
  },
];

export function VerificationWorkbench({
  initialReport,
}: {
  initialReport?: VerificationReport | null;
}) {
  const { language, geminiConfigured } = useAuth();
  const [mode, setMode] = useState<'text' | 'document'>('text');
  const [rawText, setRawText] = useState(DEMO_SCENARIOS[1].rawText);
  const [officialUrl, setOfficialUrl] = useState('');
  const [registrationUrl, setRegistrationUrl] = useState('');
  const [officialEvidenceText, setOfficialEvidenceText] = useState(
    DEMO_SCENARIOS[1].officialEvidenceText
  );
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [docNotes, setDocNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<VerificationReport | null>(initialReport || null);

  const loadScenario = (s: (typeof DEMO_SCENARIOS)[number]) => {
    setMode('text');
    setRawText(s.rawText);
    setOfficialUrl(s.officialUrl);
    setOfficialEvidenceText(s.officialEvidenceText);
    setError(null);
  };

  const handleAnalyzeText = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await apiFetch<{ report: VerificationReport }>('/api/verification/analyze', {
        method: 'POST',
        body: JSON.stringify({
          rawText,
          officialUrl: officialUrl.trim() || null,
          registrationUrl: registrationUrl.trim() || null,
          officialEvidenceText: officialEvidenceText.trim() || null,
          language,
        }),
      });
      setReport(res.report);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification request failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAnalyzeDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      setError('Please select a PDF, PNG, JPG, WebP, or TXT file (max 5 MB).');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.append('file', selectedFile);
      fd.append('notes', docNotes);
      if (officialUrl.trim()) fd.append('officialUrl', officialUrl.trim());
      if (officialEvidenceText.trim()) fd.append('officialEvidenceText', officialEvidenceText.trim());
      fd.append('language', language);

      const res = await apiFetch<{ report: VerificationReport }>(
        '/api/verification/analyze-document',
        {
          method: 'POST',
          body: fd,
        }
      );
      setReport(res.report);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Document analysis failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              AI Opportunity & Evidence Verification Engine
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              {geminiConfigured
                ? 'Powered by Google Gemini server-side structured analysis and SSRF-protected source inspection.'
                : 'Running in DEMO MODE (deterministic verification). Load any test scenario or paste custom opportunity details.'}
            </p>
          </div>

          <div className="inline-flex p-1 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0">
            <button
              type="button"
              onClick={() => setMode('text')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === 'text'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Text & URL Input
            </button>
            <button
              type="button"
              onClick={() => setMode('document')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === 'document'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Document / Poster Upload
            </button>
          </div>
        </div>

        {/* One-Click Demo Test Scenarios */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Demo Test Scenarios (DEMO DATA — FOR TESTING AND PRESENTATION ONLY)
          </div>
          <div className="flex flex-wrap gap-2">
            {DEMO_SCENARIOS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => loadScenario(s)}
                className="px-3 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:border-blue-500 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="p-3.5 rounded-lg border border-red-500/30 bg-red-500/10 text-sm text-red-700 dark:text-red-300">
            {error}
          </div>
        )}

        {mode === 'text' ? (
          <form onSubmit={handleAnalyzeText} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Opportunity Announcement, Email, or Advertisement Text
              </label>
              <textarea
                rows={6}
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                placeholder="Paste the scholarship, internship, hackathon, or course announcement here..."
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Official Website or Announcement URL (optional, SSRF-protected)
                </label>
                <input
                  type="url"
                  value={officialUrl}
                  onChange={(e) => setOfficialUrl(e.target.value)}
                  placeholder="https://example.edu/scholarship-guidelines"
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Registration Link (optional)
                </label>
                <input
                  type="url"
                  value={registrationUrl}
                  onChange={(e) => setRegistrationUrl(e.target.value)}
                  placeholder="https://example.edu/apply"
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Official Source Excerpt for Cross-Comparison (optional)
              </label>
              <textarea
                rows={3}
                value={officialEvidenceText}
                onChange={(e) => setOfficialEvidenceText(e.target.value)}
                placeholder="Paste official terms, fee schedule, or eligibility rules from the organizer's official site to detect contradictions..."
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="flex items-center justify-between gap-4 pt-2">
              <span className="text-xs text-slate-500 dark:text-slate-400">
                External text is treated strictly as untrusted data. HTTPS is never treated as proof of legitimacy.
              </span>
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                {submitting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <ShieldCheck className="w-4 h-4" />
                )}
                <span>{submitting ? 'Verifying Claims...' : 'Run Verification'}</span>
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleAnalyzeDocument} className="space-y-4">
            <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center space-y-3">
              <FileUp className="w-8 h-8 text-blue-500 mx-auto" />
              <div className="text-sm font-medium text-slate-800 dark:text-slate-200">
                Upload a scholarship poster, screenshot, PDF brochure, or text notice
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Supported: PDF, PNG, JPG, JPEG, WebP, TXT · Max 5 MB · Validated server-side (never executed)
              </p>
              <input
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.webp,.txt"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="block mx-auto text-xs text-slate-600 dark:text-slate-300 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700"
              />
              {selectedFile && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-slate-100 dark:bg-slate-800 text-xs font-mono">
                  <span>{selectedFile.name}</span>
                  <span>({Math.round(selectedFile.size / 1024)} KB)</span>
                  <button
                    type="button"
                    onClick={() => setSelectedFile(null)}
                    className="text-red-500 hover:text-red-600"
                    aria-label="Remove selected file"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Additional Context or Extracted Text Notes (optional)
              </label>
              <textarea
                rows={3}
                value={docNotes}
                onChange={(e) => setDocNotes(e.target.value)}
                placeholder="Add any accompanying message or URL where you received this poster..."
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors"
              >
                {submitting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <ShieldCheck className="w-4 h-4" />
                )}
                <span>{submitting ? 'Analyzing Document...' : 'Analyze Document'}</span>
              </button>
            </div>
          </form>
        )}
      </div>

      {report && <VerificationReportView report={report} onReportUpdated={setReport} />}
    </div>
  );
}
