import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, Moon, Sun, X, Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

export function PublicLayout({ children }: { children: React.ReactNode }) {
  const { user, theme, toggleTheme, language, setLanguage, t } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { to: '/opportunities', label: t.navOpportunities },
    { to: '/verify', label: t.navVerify },
    { to: '/compare', label: t.navCompare },
    { to: '/pricing', label: t.navPricing },
    { to: '/how-it-works', label: t.navHowItWorks },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-[#0B1120] dark:text-slate-100">
      {/* Strict 3-zone Top Bar Contract */}
      <header className="sticky top-0 z-40 border-b border-slate-200 dark:border-slate-800/90 bg-white/95 dark:bg-[#0B1120]/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          <Link
            to="/"
            className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
          >
            {t.brandName}
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
            {navLinks.map((link) => {
              const active = location.pathname === link.to;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 dark:hover:text-white ${
                    active
                      ? 'text-blue-600 dark:text-blue-400 underline underline-offset-8 decoration-2'
                      : ''
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <Link
              to={user ? '/dashboard' : '/login'}
              className="hidden sm:inline-flex items-center justify-center px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
            >
              {user ? t.openWorkspace : t.signIn}
            </Link>
            <button
              type="button"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle navigation menu"
              className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B1120] px-4 py-4 space-y-2">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className="block py-2.5 px-3 rounded-lg text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                {link.label}
              </Link>
            ))}
            <Link
              to={user ? '/dashboard' : '/login'}
              onClick={() => setMobileOpen(false)}
              className="block text-center py-2.5 px-4 rounded-lg bg-blue-600 text-white text-sm font-semibold"
            >
              {user ? t.openWorkspace : t.signIn}
            </Link>
          </div>
        )}
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#080D19] mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <div className="font-display text-lg font-bold text-slate-900 dark:text-white">
              {t.brandName}
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              {t.tagline} Evidence-powered student opportunity verification, claim comparison, and
              eligibility intelligence for international learners.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={toggleTheme}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
                <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
              </button>
              <button
                type="button"
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
              </button>
            </div>
          </div>

          <div className="space-y-2.5 text-sm">
            <div className="font-semibold text-slate-900 dark:text-white">Platform</div>
            <ul className="space-y-2 text-slate-600 dark:text-slate-400">
              <li><Link to="/verify" className="hover:text-blue-600 dark:hover:text-blue-400">AI Verification Engine</Link></li>
              <li><Link to="/opportunities" className="hover:text-blue-600 dark:hover:text-blue-400">Opportunity Discovery</Link></li>
              <li><Link to="/compare" className="hover:text-blue-600 dark:hover:text-blue-400">Side-by-Side Compare</Link></li>
              <li><Link to="/features" className="hover:text-blue-600 dark:hover:text-blue-400">Features</Link></li>
              <li><Link to="/how-it-works" className="hover:text-blue-600 dark:hover:text-blue-400">How It Works</Link></li>
            </ul>
          </div>

          <div className="space-y-2.5 text-sm">
            <div className="font-semibold text-slate-900 dark:text-white">Company & Access</div>
            <ul className="space-y-2 text-slate-600 dark:text-slate-400">
              <li><Link to="/about" className="hover:text-blue-600 dark:hover:text-blue-400">About</Link></li>
              <li><Link to="/pricing" className="hover:text-blue-600 dark:hover:text-blue-400">Pricing</Link></li>
              <li><Link to="/contact" className="hover:text-blue-600 dark:hover:text-blue-400">Contact</Link></li>
              <li><Link to="/login" className="hover:text-blue-600 dark:hover:text-blue-400">Sign In</Link></li>
              <li><Link to="/register" className="hover:text-blue-600 dark:hover:text-blue-400">Create Account</Link></li>
            </ul>
          </div>

          <div className="space-y-2.5 text-sm">
            <div className="font-semibold text-slate-900 dark:text-white">Trust & Governance</div>
            <ul className="space-y-2 text-slate-600 dark:text-slate-400">
              <li><Link to="/privacy" className="hover:text-blue-600 dark:hover:text-blue-400">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-blue-600 dark:hover:text-blue-400">Terms & Acceptable Use</Link></li>
              <li><Link to="/responsible-ai" className="hover:text-blue-600 dark:hover:text-blue-400">Responsible AI & Security</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-200 dark:border-slate-800/80 py-4 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span>© {new Date().getFullYear()} ProofPath AI. Evidence before conclusions.</span>
          <span>Automated verification does not replace direct institutional confirmation.</span>
        </div>
      </footer>
    </div>
  );
}
