import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  BarChart3,
  Bell,
  Bookmark,
  Calendar,
  CheckSquare,
  ClipboardList,
  Compass,
  FileSearch,
  GitCompare,
  Globe,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquare,
  Moon,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  Sun,
  UserCheck,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

export function DashboardLayout({
  children,
  title,
  breadcrumb,
}: {
  children: React.ReactNode;
  title: string;
  breadcrumb?: string;
}) {
  const {
    user,
    theme,
    toggleTheme,
    language,
    setLanguage,
    logout,
    unreadNotifications,
    t,
    geminiConfigured,
  } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);
  const [cmdQuery, setCmdQuery] = useState('');

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCmdOpen((prev) => !prev);
      }
      if (e.key === 'Escape') setCmdOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const navItems = [
    { to: '/dashboard', label: t.dashboard, Icon: LayoutDashboard },
    { to: '/dashboard/insights', label: 'Insights', Icon: BarChart3 },
    { to: '/dashboard/verify', label: 'Verify Opportunity', Icon: Shield },
    { to: '/dashboard/reports', label: t.reports, Icon: FileSearch },
    { to: '/dashboard/opportunities', label: t.navOpportunities, Icon: Compass },
    { to: '/dashboard/saved', label: t.saved, Icon: Bookmark },
    { to: '/dashboard/compare', label: t.navCompare, Icon: GitCompare },
    { to: '/dashboard/eligibility', label: t.eligibility, Icon: UserCheck },
    { to: '/dashboard/applications', label: t.applications, Icon: ClipboardList },
    { to: '/dashboard/calendar', label: t.calendar, Icon: Calendar },
    { to: '/dashboard/assistant', label: t.assistant, Icon: MessageSquare },
    { to: '/dashboard/community', label: t.community, Icon: ShieldAlert },
    { to: '/dashboard/profile', label: t.profile, Icon: CheckSquare },
    { to: '/dashboard/notifications', label: t.notifications, Icon: Bell },
    { to: '/dashboard/settings', label: t.settings, Icon: Settings },
  ];

  const isAdminOrMod = user?.role === 'admin' || user?.role === 'moderator';
  const filteredCmd = navItems.filter((item) =>
    item.label.toLowerCase().includes(cmdQuery.toLowerCase())
  );

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const sidebarContent = (
    <div className="flex flex-col h-full">
      <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
        <Link
          to="/"
          className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white"
        >
          ProofPath AI
        </Link>
        <button
          type="button"
          onClick={() => setSidebarOpen(false)}
          className="lg:hidden p-2 rounded-md text-slate-500 hover:text-slate-900 dark:hover:text-white"
          aria-label="Close sidebar"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {navItems.map(({ to, label, Icon }) => {
          const active = location.pathname === to;
          return (
            <Link
              key={to}
              to={to}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                active
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
              }`}
            >
              <span className="flex items-center gap-2.5 truncate">
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{label}</span>
              </span>
              {to === '/dashboard/notifications' && unreadNotifications > 0 && (
                <span
                  className={`text-xs font-mono tabular-nums px-1.5 py-0.5 rounded ${
                    active ? 'bg-white/20 text-white' : 'bg-blue-600/15 text-blue-600 dark:text-blue-400'
                  }`}
                >
                  {unreadNotifications}
                </span>
              )}
            </Link>
          );
        })}

        {isAdminOrMod && (
          <div className="pt-4 mt-4 border-t border-slate-200 dark:border-slate-800">
            <Link
              to="/admin"
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                location.pathname.startsWith('/admin')
                  ? 'bg-indigo-600 text-white'
                  : 'text-indigo-700 dark:text-indigo-300 hover:bg-indigo-500/10'
              }`}
            >
              <Shield className="w-4 h-4 shrink-0" />
              <span>{t.adminPanel}</span>
            </Link>
          </div>
        )}
      </nav>

      <div className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
        <div className="text-xs text-slate-600 dark:text-slate-400 truncate">
          <div className="font-medium text-slate-900 dark:text-slate-100 truncate">{user?.name}</div>
          <div className="truncate">{user?.email}</div>
        </div>
        <button
          type="button"
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{t.signOut}</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900 dark:bg-[#0B1120] dark:text-slate-100">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-[#080D19] sticky top-0 h-screen">
        {sidebarContent}
      </aside>

      {/* Mobile Sidebar Drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="w-72 bg-white dark:bg-[#080D19] border-r border-slate-200 dark:border-slate-800 h-full">
            {sidebarContent}
          </div>
          <div
            className="flex-1 bg-black/60"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-[#0B1120]/95 backdrop-blur px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-30 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-800"
              aria-label="Open navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                Workspace / {breadcrumb || title}
              </div>
              <h1 className="text-base font-semibold text-slate-900 dark:text-white truncate">
                {title}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setCmdOpen(true)}
              className="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Quick Jump</span>
              <kbd className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                ⌘K
              </kbd>
            </button>

            <button
              type="button"
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1"
              title="Switch language"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{language === 'en' ? 'EN' : 'বাং'}</span>
            </button>

            <button
              type="button"
              onClick={toggleTheme}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <Link
              to="/dashboard/notifications"
              className="relative p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifications > 0 && (
                <span className="absolute -top-1 -right-1 px-1 min-w-[16px] h-4 rounded bg-blue-600 text-white text-[10px] font-mono flex items-center justify-center">
                  {unreadNotifications}
                </span>
              )}
            </Link>
          </div>
        </header>

        {!geminiConfigured && (
          <div className="bg-amber-500/10 border-b border-amber-500/25 px-4 sm:px-6 py-2 text-xs text-amber-800 dark:text-amber-200 no-print">
            {t.demoModeBanner}
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">{children}</main>
      </div>

      {/* Command Menu Modal */}
      {cmdOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-start justify-center pt-24 px-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-200 dark:border-slate-800">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                autoFocus
                type="text"
                value={cmdQuery}
                onChange={(e) => setCmdQuery(e.target.value)}
                placeholder="Jump to a ProofPath module..."
                className="w-full bg-transparent text-sm outline-none text-slate-900 dark:text-white"
              />
              <button
                type="button"
                onClick={() => setCmdOpen(false)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                ESC
              </button>
            </div>
            <div className="max-h-72 overflow-y-auto p-2 space-y-1">
              {filteredCmd.map(({ to, label, Icon }) => (
                <button
                  key={to}
                  type="button"
                  onClick={() => {
                    navigate(to);
                    setCmdOpen(false);
                    setCmdQuery('');
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <Icon className="w-4 h-4 text-blue-500" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
