import {
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  Clock,
  HelpCircle,
  Info,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import type { ClaimStatus, EligibilityResult, RiskCategory } from '../types/proofpath.ts';

export function ClaimStatusTag({ status }: { status: ClaimStatus }) {
  const styles: Record<ClaimStatus, { cls: string; label: string; Icon: typeof CheckCircle2 }> = {
    VERIFIED: {
      cls: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
      label: 'VERIFIED',
      Icon: ShieldCheck,
    },
    SUPPORTED: {
      cls: 'border-blue-500/30 bg-blue-500/10 text-blue-700 dark:text-blue-300',
      label: 'SUPPORTED',
      Icon: CheckCircle2,
    },
    CONTRADICTED: {
      cls: 'border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300',
      label: 'CONTRADICTED',
      Icon: XCircle,
    },
    UNVERIFIED: {
      cls: 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
      label: 'UNVERIFIED',
      Icon: AlertTriangle,
    },
    INSUFFICIENT_EVIDENCE: {
      cls: 'border-slate-400/40 bg-slate-500/10 text-slate-700 dark:text-slate-300',
      label: 'INSUFFICIENT EVIDENCE',
      Icon: HelpCircle,
    },
    EXPIRED: {
      cls: 'border-orange-500/30 bg-orange-500/10 text-orange-700 dark:text-orange-300',
      label: 'EXPIRED',
      Icon: Clock,
    },
    CONFLICTING_SOURCES: {
      cls: 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
      label: 'CONFLICTING SOURCES',
      Icon: AlertOctagon,
    },
  };

  const cfg = styles[status] || styles.INSUFFICIENT_EVIDENCE;
  const Icon = cfg.Icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-mono font-medium whitespace-nowrap shrink-0 ${cfg.cls}`}
    >
      <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{cfg.label}</span>
    </span>
  );
}

export function RiskCategoryTag({ category }: { category: RiskCategory }) {
  const map: Record<RiskCategory, { cls: string; Icon: typeof ShieldCheck }> = {
    'LOW CONCERN': {
      cls: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
      Icon: ShieldCheck,
    },
    'MODERATE CONCERN': {
      cls: 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
      Icon: AlertTriangle,
    },
    'HIGH CONCERN': {
      cls: 'border-orange-500/30 bg-orange-500/10 text-orange-700 dark:text-orange-300',
      Icon: AlertOctagon,
    },
    'CRITICAL CONCERN': {
      cls: 'border-red-500/40 bg-red-500/15 text-red-700 dark:text-red-300',
      Icon: XCircle,
    },
    'INSUFFICIENT EVIDENCE': {
      cls: 'border-slate-400/40 bg-slate-500/10 text-slate-700 dark:text-slate-300',
      Icon: HelpCircle,
    },
  };
  const cfg = map[category] || map['INSUFFICIENT EVIDENCE'];
  const Icon = cfg.Icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-mono font-medium whitespace-nowrap shrink-0 ${cfg.cls}`}
    >
      <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{category}</span>
    </span>
  );
}

export function EligibilityTag({ result }: { result: EligibilityResult }) {
  const map: Record<EligibilityResult, string> = {
    Eligible: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
    'Likely eligible': 'border-blue-500/30 bg-blue-500/10 text-blue-700 dark:text-blue-300',
    'Possibly eligible': 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
    'Not eligible': 'border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300',
    'Insufficient information':
      'border-slate-400/40 bg-slate-500/10 text-slate-700 dark:text-slate-300',
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-medium whitespace-nowrap shrink-0 ${
        map[result] || map['Insufficient information']
      }`}
    >
      <Info className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{result}</span>
    </span>
  );
}

export function DemoDataCallout({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-md border border-amber-500/30 bg-amber-500/10 text-amber-800 dark:text-amber-200 text-xs">
      <Info className="w-4 h-4 shrink-0" aria-hidden="true" />
      <span>{label || 'DEMO DATA — FOR TESTING AND PRESENTATION ONLY'}</span>
    </div>
  );
}
