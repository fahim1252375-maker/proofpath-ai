import { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Printer,
  Share2,
  ShieldAlert,
} from 'lucide-react';
import { apiFetch } from '../lib/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { formatLocalizedDate } from '../i18n/translations.ts';
import { ClaimStatusTag, RiskCategoryTag } from './StatusBadge.tsx';
import type { ExtractedClaim, VerificationReport } from '../types/proofpath.ts';

export function VerificationReportView({
  report,
  onReportUpdated,
  readOnly = false,
}: {
  report: VerificationReport;
  onReportUpdated?: (updated: VerificationReport) => void;
  readOnly?: boolean;
}) {
  const { language, user } = useAuth();
  const [expandedClaimId, setExpandedClaimId] = useState<string | null>(
    report.claims[0]?.id || null
  );
  const [sharing, setSharing] = useState(false);
  const [shareMsg, setShareMsg] = useState<string | null>(null);

  const toggleShare = async () => {
    if (!user) return;
    setSharing(true);
    try {
      const res = await apiFetch<{ is_public_share: boolean; share_token: string | null }>(
        `/api/verification/${report.id}/share`,
        {
          method: 'POST',
          body: JSON.stringify({ enable: !report.is_public_share }),
        }
      );
      onReportUpdated?.({
        ...report,
        is_public_share: res.is_public_share,
        share_token: res.share_token,
      });
      setShareMsg(
        res.is_public_share && res.share_token
          ? `${window.location.origin}/reports/shared/${res.share_token}`
          : 'Public share link disabled.'
      );
    } finally {
      setSharing(false);
    }
  };

  const renderClaimDrawer = (claim: ExtractedClaim) => (
    <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
      <div>
        <div className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
          Source Excerpt Submitted
        </div>
        <p className="text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-950/60 p-2.5 rounded-md border border-slate-200 dark:border-slate-800 font-mono text-xs">
          {claim.source_text || 'Not explicitly quoted'}
        </p>
      </div>
      <div>
        <div className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
          Normalized Value & Confidence Explanation
        </div>
        <p className="text-slate-900 dark:text-slate-100 font-medium">{claim.normalized_value}</p>
        <p className="text-slate-600 dark:text-slate-400 text-xs mt-1">
          {claim.confidence_explanation}
        </p>
      </div>
      {claim.supporting_evidence && (
        <div className="p-2.5 rounded-md border border-emerald-500/20 bg-emerald-500/5 text-xs text-emerald-800 dark:text-emerald-200">
          <strong className="block mb-0.5">Supporting Evidence</strong>
          {claim.supporting_evidence}
        </div>
      )}
      {claim.contradicting_evidence && (
        <div className="p-2.5 rounded-md border border-red-500/25 bg-red-500/5 text-xs text-red-800 dark:text-red-200">
          <strong className="block mb-0.5">Contradicting Evidence</strong>
          {claim.contradicting_evidence}
        </div>
      )}
      <div className="md:col-span-2 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
        <span>
          Evidence Source:{' '}
          {claim.evidence_url ? (
            <a
              href={claim.evidence_url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
            >
              {claim.evidence_url}
              <ExternalLink className="w-3 h-3" />
            </a>
          ) : (
            'No independent URL retrieved'
          )}
        </span>
        <span className="font-mono tabular-nums">
          Checked: {formatLocalizedDate(claim.last_checked_at, language)}
        </span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Mode / Transparency Disclosure */}
      {report.analysis_mode === 'demo' && (
        <div className="p-3.5 rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-800 dark:text-amber-200 text-xs flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <strong>DEMO MODE REPORT:</strong> Generated using deterministic verification logic
            ({report.model_used}). This output is not a live Gemini API evaluation and does not
            constitute confirmed institutional verification.
          </div>
        </div>
      )}

      {/* Report Header */}
      <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono">
              <span>PROOFPATH AI VERIFICATION REPORT</span>
              <span aria-hidden="true">·</span>
              <span>{report.id}</span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums">
                {formatLocalizedDate(report.created_at, language)}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-50 tracking-tight">
              {report.opportunity_name}
            </h2>
            <div className="flex flex-wrap items-center gap-3 text-sm text-slate-600 dark:text-slate-300">
              <span>Organizer: {report.organizer_name}</span>
              <span aria-hidden="true">·</span>
              <span>Category: {report.category}</span>
              <span aria-hidden="true">·</span>
              <span>Evidence Quality: {report.evidence_quality}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 no-print shrink-0">
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Export / Print PDF</span>
            </button>
            {!readOnly && user && report.user_id === user.id && (
              <button
                type="button"
                onClick={toggleShare}
                disabled={sharing}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-blue-500/40 bg-blue-600/10 text-xs font-medium text-blue-700 dark:text-blue-300 hover:bg-blue-600/20 transition-colors whitespace-nowrap"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>{report.is_public_share ? 'Disable Share Link' : 'Create Share Link'}</span>
              </button>
            )}
          </div>
        </div>

        {shareMsg && (
          <div className="mt-4 p-3 rounded-lg border border-blue-500/30 bg-blue-500/5 text-xs font-mono text-blue-700 dark:text-blue-300 break-all">
            Share URL: {shareMsg}
          </div>
        )}

        <div className="mt-5 pt-5 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mb-1.5">
              Overall Assessment
            </div>
            <ClaimStatusTag status={report.overall_assessment} />
          </div>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mb-1.5">
              Risk Intelligence Category
            </div>
            <RiskCategoryTag category={report.risk_assessment.risk_category} />
          </div>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mb-1.5">
              Analysis Engine
            </div>
            <div className="text-sm font-mono text-slate-800 dark:text-slate-200">
              {report.analysis_mode === 'gemini' ? `Gemini (${report.model_used})` : 'DEMO MODE'}
            </div>
          </div>
        </div>

        <div className="mt-5">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
            Executive Summary
          </div>
          <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-200">
            {report.executive_summary}
          </p>
        </div>
      </div>

      {/* Claim-by-Claim Comparison Table */}
      <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
          <div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50">
              Claim-by-Claim Evidence Comparison
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Open any claim to inspect exact source excerpts, supporting/contradicting evidence, and
              citations.
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
            {report.claims.length} claims extracted
          </span>
        </div>

        <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
          {report.claims.map((claim) => {
            const isOpen = expandedClaimId === claim.id;
            return (
              <div key={claim.id} className="p-4">
                <button
                  type="button"
                  onClick={() => setExpandedClaimId(isOpen ? null : claim.id)}
                  className="w-full flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left"
                >
                  <div className="space-y-1">
                    <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                      {claim.category}
                    </div>
                    <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      {claim.extracted_statement}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <ClaimStatusTag status={claim.status} />
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </button>
                {isOpen && renderClaimDrawer(claim)}
              </div>
            );
          })}
        </div>
      </div>

      {/* Risk Intelligence & Signals */}
      <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50">
              Transparent Risk Intelligence
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Structural risk signals are separated from confirmed fraud determinations.
            </p>
          </div>
          <RiskCategoryTag category={report.risk_assessment.risk_category} />
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
          <strong>Methodology & Limitations:</strong> {report.risk_assessment.methodology_note}
        </p>

        {report.risk_assessment.factors.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {report.risk_assessment.factors.map((f, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40"
              >
                <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  {f.dimension}
                </div>
                <div className="mt-1 text-sm font-medium text-slate-900 dark:text-slate-100">
                  {f.assessment}
                </div>
                <div className="mt-2 text-xs font-mono uppercase text-slate-500 dark:text-slate-400">
                  Signal: {f.status}
                </div>
              </div>
            ))}
          </div>
        )}

        {report.risk_assessment.indicators.length > 0 && (
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Detected Warning Indicators ({report.risk_assessment.indicators.length})
            </h4>
            {report.risk_assessment.indicators.map((ind, idx) => (
              <div
                key={idx}
                className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-medium text-sm text-slate-900 dark:text-slate-100">
                    <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0" />
                    <span>{ind.indicator}</span>
                  </div>
                  <span className="text-xs font-mono uppercase px-2 py-0.5 rounded border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                    Severity: {ind.severity}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300">{ind.explanation}</p>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Evidence: {ind.supporting_evidence} · Action: {ind.recommended_action}
                  {ind.human_review_recommended ? ' · Human review recommended' : ''}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Missing Information, Recommended Actions & Source Snapshots */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
          <h3 className="text-base font-semibold text-slate-900 dark:text-slate-50">
            Missing Information
          </h3>
          {report.missing_information.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No critical missing fields flagged.
            </p>
          ) : (
            <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300">
              {report.missing_information.map((m, i) => (
                <li key={i} className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>{m}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
          <h3 className="text-base font-semibold text-slate-900 dark:text-slate-50">
            Recommended Next Steps
          </h3>
          <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300">
            {report.recommended_actions.map((a, i) => (
              <li key={i} className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                <span>{a}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Source Snapshots & Limitations */}
      <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
        <h3 className="text-base font-semibold text-slate-900 dark:text-slate-50">
          Retrieved Source Snapshots & Important Limitations
        </h3>
        {report.source_snapshots.length === 0 ? (
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Official evidence not available. No live web page snapshot was retrieved for this
            report; claims remain unverified unless corroborated directly.
          </p>
        ) : (
          <div className="space-y-3">
            {report.source_snapshots.map((snap, i) => (
              <div
                key={i}
                className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1.5"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 font-mono text-slate-500 dark:text-slate-400">
                  <span>
                    {snap.source_type} · {snap.domain}
                  </span>
                  <span>{formatLocalizedDate(snap.fetched_at, language)}</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300">{snap.excerpt}</p>
              </div>
            ))}
          </div>
        )}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
          <strong>Important Limitations:</strong> {report.limitations}
        </div>
      </div>
    </div>
  );
}
