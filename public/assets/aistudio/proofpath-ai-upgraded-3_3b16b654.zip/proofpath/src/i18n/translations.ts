import type { LanguageCode } from '../types/proofpath.ts';

export const TRANSLATIONS = {
  en: {
    brandName: 'ProofPath AI',
    tagline: 'Verify Before You Apply.',
    heroHeadline: "Don't Let Fake Opportunities Steal Your Future.",
    heroSubheadline:
      'Verify scholarships, internships, hackathons, and global opportunities with evidence-powered AI intelligence.',
    primaryCta: 'Verify an Opportunity',
    secondaryCta: 'Explore Opportunities',
    navOpportunities: 'Opportunities',
    navVerify: 'Verify',
    navCompare: 'Compare',
    navPricing: 'Pricing',
    navHowItWorks: 'How It Works',
    openWorkspace: 'Open Workspace',
    signIn: 'Sign In',
    signUp: 'Create Account',
    signOut: 'Sign Out',
    dashboard: 'Dashboard',
    profile: 'Student Profile',
    reports: 'Verification Reports',
    saved: 'Saved',
    eligibility: 'Eligibility Check',
    applications: 'Applications',
    calendar: 'Calendar',
    assistant: 'AI Assistant',
    community: 'Community Reports',
    notifications: 'Notifications',
    settings: 'Settings',
    adminPanel: 'Admin Console',
    demoModeBanner:
      'DEMO MODE ACTIVE: Live Gemini API key is not configured. Analysis outputs below use deterministic verification logic for testing and demonstration.',
    demoDataBadge: 'DEMO DATA — FOR TESTING AND PRESENTATION ONLY',
    officialMissing: 'Official evidence not available. This opportunity remains unverified.',
  },
  bn: {
    brandName: 'ProofPath AI',
    tagline: 'আবেদন করার আগে যাচাই করুন।',
    heroHeadline: 'ভুয়া সুযোগকে আপনার ভবিষ্যৎ নষ্ট করতে দেবেন না।',
    heroSubheadline:
      'প্রমাণ-ভিত্তিক এআই বুদ্ধিমত্তার মাধ্যমে বৃত্তি, ইন্টার্নশিপ, হ্যাকাথন এবং আন্তর্জাতিক সুযোগগুলো যাচাই করুন।',
    primaryCta: 'সুযোগ যাচাই করুন',
    secondaryCta: 'সুযোগ খুঁজুন',
    navOpportunities: 'সুযোগসমূহ',
    navVerify: 'যাচাই',
    navCompare: 'তুলনা',
    navPricing: 'মূল্যতালিকা',
    navHowItWorks: 'কাজের ধাপ',
    openWorkspace: 'ওয়ার্কস্পেস খুলুন',
    signIn: 'সাইন ইন',
    signUp: 'অ্যাকাউন্ট খুলুন',
    signOut: 'সাইন আউট',
    dashboard: 'ড্যাশবোর্ড',
    profile: 'শিক্ষার্থী প্রোফাইল',
    reports: 'যাচাইকরণ রিপোর্ট',
    saved: 'সংরক্ষিত',
    eligibility: 'যোগ্যতা যাচাই',
    applications: 'আবেদন ট্র্যাকার',
    calendar: 'ক্যালেন্ডার',
    assistant: 'এআই সহায়ক',
    community: 'কমিউনিটি রিপোর্ট',
    notifications: 'বিজ্ঞপ্তি',
    settings: 'সেটিংস',
    adminPanel: 'অ্যাডমিন কনসোল',
    demoModeBanner:
      'ডেমো মোড সক্রিয়: লাইভ Gemini API কী যুক্ত নেই। পরীক্ষামূলক ও প্রদর্শনের জন্য নির্ধারিত যুক্তি ব্যবহার করে ফলাফল দেখানো হচ্ছে।',
    demoDataBadge: 'ডেমো ডেটা — শুধুমাত্র পরীক্ষা ও প্রদর্শনের জন্য',
    officialMissing: 'অফিশিয়াল প্রমাণ পাওয়া যায়নি। এই সুযোগটি এখনও যাচাইকৃত নয়।',
  },
} as const;

export function formatLocalizedDate(dateStr: string | null | undefined, lang: LanguageCode): string {
  if (!dateStr) return '—';
  const parsed = Date.parse(dateStr);
  if (Number.isNaN(parsed)) return dateStr;
  return new Intl.DateTimeFormat(lang === 'bn' ? 'bn-BD' : 'en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(parsed));
}
