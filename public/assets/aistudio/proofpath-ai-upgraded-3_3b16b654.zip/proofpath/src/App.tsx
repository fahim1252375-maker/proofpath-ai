import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { LandingPage } from './pages/public/LandingPage.tsx';
import { OpportunitiesView } from './pages/public/OpportunitiesPage.tsx';
import { OpportunityDetailPage } from './pages/public/OpportunityDetailPage.tsx';
import { CompareView } from './pages/public/ComparePage.tsx';
import { ForgotPasswordPage, LoginPage, RegisterPage } from './pages/public/AuthPages.tsx';
import {
  AboutPage,
  ContactPage,
  FeaturesPage,
  HowItWorksPage,
  LegalDocPage,
  PricingPage,
  PublicVerifyPage,
  SharedReportPage,
} from './pages/public/PublicPages.tsx';
import { DashboardOverview } from './pages/dashboard/DashboardOverview.tsx';
import { ProfilePage } from './pages/dashboard/ProfilePage.tsx';
import {
  DashboardVerifyPage,
  ReportDetailPage,
  ReportsListPage,
  SavedOpportunitiesPage,
} from './pages/dashboard/ReportsPages.tsx';
import { EligibilityPage } from './pages/dashboard/EligibilityPage.tsx';
import { ApplicationsPage, CalendarPage } from './pages/dashboard/ApplicationsPages.tsx';
import { AssistantPage } from './pages/dashboard/AssistantPage.tsx';
import {
  CommunityPage,
  NotificationsPage,
  SettingsPage,
} from './pages/dashboard/CommunityNotificationsSettings.tsx';
import { InsightsPage } from './pages/dashboard/InsightsPage.tsx';
import { ToastProvider } from './components/ui.tsx';
import { AdminConsole } from './pages/admin/AdminConsole.tsx';

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error.message };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-slate-950 text-slate-100">
          <div className="max-w-md p-6 rounded-xl border border-slate-800 bg-slate-900 space-y-3">
            <h1 className="text-lg font-bold">Something went wrong</h1>
            <p className="text-sm text-slate-400">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-slate-500">
        Loading workspace...
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function RequireAdmin({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-slate-500">
        Verifying permissions...
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'admin' && user.role !== 'moderator') {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <AppErrorBoundary>
      <AuthProvider>
        <ToastProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/features" element={<FeaturesPage />} />
            <Route path="/how-it-works" element={<HowItWorksPage />} />
            <Route path="/opportunities" element={<OpportunitiesView />} />
            <Route path="/opportunities/:id" element={<OpportunityDetailPage />} />
            <Route path="/verify" element={<PublicVerifyPage />} />
            <Route path="/compare" element={<CompareView />} />
            <Route path="/pricing" element={<PricingPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy" element={<LegalDocPage type="privacy" />} />
            <Route path="/terms" element={<LegalDocPage type="terms" />} />
            <Route path="/responsible-ai" element={<LegalDocPage type="responsible-ai" />} />
            <Route path="/reports/shared/:token" element={<SharedReportPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />

            {/* Authenticated Student Dashboard Routes */}
            <Route path="/dashboard" element={<RequireAuth><DashboardOverview /></RequireAuth>} />
            <Route path="/dashboard/insights" element={<RequireAuth><InsightsPage /></RequireAuth>} />
            <Route path="/dashboard/profile" element={<RequireAuth><ProfilePage /></RequireAuth>} />
            <Route path="/dashboard/verify" element={<RequireAuth><DashboardVerifyPage /></RequireAuth>} />
            <Route path="/dashboard/reports" element={<RequireAuth><ReportsListPage /></RequireAuth>} />
            <Route path="/dashboard/reports/:id" element={<RequireAuth><ReportDetailPage /></RequireAuth>} />
            <Route path="/dashboard/opportunities" element={<RequireAuth><OpportunitiesView inDashboard /></RequireAuth>} />
            <Route path="/dashboard/saved" element={<RequireAuth><SavedOpportunitiesPage /></RequireAuth>} />
            <Route path="/dashboard/compare" element={<RequireAuth><CompareView inDashboard /></RequireAuth>} />
            <Route path="/dashboard/eligibility" element={<RequireAuth><EligibilityPage /></RequireAuth>} />
            <Route path="/dashboard/applications" element={<RequireAuth><ApplicationsPage /></RequireAuth>} />
            <Route path="/dashboard/calendar" element={<RequireAuth><CalendarPage /></RequireAuth>} />
            <Route path="/dashboard/assistant" element={<RequireAuth><AssistantPage /></RequireAuth>} />
            <Route path="/dashboard/community" element={<RequireAuth><CommunityPage /></RequireAuth>} />
            <Route path="/dashboard/notifications" element={<RequireAuth><NotificationsPage /></RequireAuth>} />
            <Route path="/dashboard/settings" element={<RequireAuth><SettingsPage /></RequireAuth>} />

            {/* Admin & Moderation Routes */}
            <Route path="/admin" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/users" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/opportunities" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/sources" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/reports" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/moderation" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/ai-usage" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/analytics" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/security" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />
            <Route path="/admin/settings" element={<RequireAdmin><AdminConsole /></RequireAdmin>} />

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
        </ToastProvider>
      </AuthProvider>
    </AppErrorBoundary>
  );
}
