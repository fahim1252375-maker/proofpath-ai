export const CLAIM_STATUSES = [
  'VERIFIED',
  'SUPPORTED',
  'CONTRADICTED',
  'UNVERIFIED',
  'INSUFFICIENT_EVIDENCE',
  'EXPIRED',
  'CONFLICTING_SOURCES',
] as const;
export type ClaimStatus = (typeof CLAIM_STATUSES)[number];

export const RISK_CATEGORIES = [
  'LOW CONCERN',
  'MODERATE CONCERN',
  'HIGH CONCERN',
  'CRITICAL CONCERN',
  'INSUFFICIENT EVIDENCE',
] as const;
export type RiskCategory = (typeof RISK_CATEGORIES)[number];

export const ELIGIBILITY_RESULTS = [
  'Eligible',
  'Likely eligible',
  'Possibly eligible',
  'Not eligible',
  'Insufficient information',
] as const;
export type EligibilityResult = (typeof ELIGIBILITY_RESULTS)[number];

export const APPLICATION_STATUSES = [
  'INTERESTED',
  'RESEARCHING',
  'ELIGIBILITY_CHECK',
  'PREPARING',
  'SUBMITTED',
  'INTERVIEW',
  'ACCEPTED',
  'REJECTED',
  'WAITLISTED',
  'WITHDRAWN',
] as const;
export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];

export const SOURCE_TYPES = [
  'Official organization website',
  'Official government website',
  'Official university website',
  'Official competition website',
  'Official organizer announcement',
  'Recognized partner announcement',
  'Third-party listing',
  'Community-submitted content',
  'Unknown source',
] as const;
export type SourceType = (typeof SOURCE_TYPES)[number];

export const COMMUNITY_REPORT_CATEGORIES = [
  'Suspicious fee',
  'Misleading advertisement',
  'Impersonation',
  'Fake registration',
  'Outdated deadline',
  'Incorrect eligibility',
  'Unverified organizer',
  'Phishing attempt',
  'Other',
] as const;
export type CommunityReportCategory = (typeof COMMUNITY_REPORT_CATEGORIES)[number];

export type UserRole = 'student' | 'moderator' | 'admin';
export type LanguageCode = 'en' | 'bn';

export interface UserAccount {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  status: 'active' | 'suspended';
  preferred_language: LanguageCode;
  timezone: string;
  created_at: string;
}

export interface StudentProfile {
  user_id: string;
  country: string;
  nationality: string;
  age: number | null;
  education_level: string;
  current_year: string;
  institution: string;
  gpa: string;
  academic_interests: string[];
  preferred_categories: string[];
  preferred_countries: string[];
  english_proficiency: string;
  test_scores: {
    sat?: string;
    ielts?: string;
    toefl?: string;
  };
  financial_preference: 'fully_funded_only' | 'free_or_funded' | 'any';
  mode_preference: 'remote' | 'in_person' | 'any';
  team_preference: 'individual' | 'team' | 'any';
  updated_at: string;
}

export interface ExtractedClaim {
  id: string;
  category: string;
  extracted_statement: string;
  normalized_value: string;
  source_text: string;
  status: ClaimStatus;
  supporting_evidence: string | null;
  contradicting_evidence: string | null;
  evidence_url: string | null;
  source_publication_date: string | null;
  confidence_explanation: string;
  last_checked_at: string;
}

export interface RiskIndicator {
  indicator: string;
  explanation: string;
  supporting_evidence: string;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  recommended_action: string;
  human_review_recommended: boolean;
}

export interface RiskFactorBreakdown {
  dimension: string;
  assessment: string;
  status: 'verified' | 'caution' | 'concern' | 'missing';
}

export interface RiskAssessment {
  id: string;
  risk_category: RiskCategory;
  methodology_note: string;
  factors: RiskFactorBreakdown[];
  indicators: RiskIndicator[];
  human_review_recommended: boolean;
  created_at: string;
}

export interface VerificationReport {
  id: string;
  user_id: string | null;
  opportunity_id: string | null;
  opportunity_name: string;
  organizer_name: string;
  category: string;
  input_type: 'text' | 'url' | 'document' | 'demo';
  raw_input: string;
  official_url: string | null;
  registration_url: string | null;
  overall_assessment: ClaimStatus;
  evidence_quality: 'Strong' | 'Moderate' | 'Limited' | 'None';
  executive_summary: string;
  extracted_metadata: {
    deadline?: string | null;
    country_eligibility?: string | null;
    age_eligibility?: string | null;
    education_eligibility?: string | null;
    application_fee?: string | null;
    funding_or_prize?: string | null;
    certificate_availability?: string | null;
    delivery_format?: string | null;
    contact_details?: string | null;
    required_documents?: string[];
  };
  claims: ExtractedClaim[];
  risk_assessment: RiskAssessment;
  source_snapshots: Array<{
    url: string;
    domain: string;
    source_type: SourceType;
    excerpt: string;
    fetched_at: string;
  }>;
  missing_information: string[];
  recommended_actions: string[];
  limitations: string;
  analysis_mode: 'gemini' | 'demo';
  model_used: string;
  is_public_share: boolean;
  share_token: string | null;
  created_at: string;
}

export interface Opportunity {
  id: string;
  name: string;
  organizer: string;
  category: string;
  country: string;
  description: string;
  eligibility_summary: string;
  eligibility_rules: {
    allowed_countries?: string[];
    excluded_countries?: string[];
    min_age?: number | null;
    max_age?: number | null;
    education_levels?: string[];
    min_gpa?: number | null;
    english_required?: string | null;
    team_allowed?: boolean;
    individual_allowed?: boolean;
  };
  deadline: string;
  funding: string;
  fees: string;
  is_free: boolean;
  is_fully_funded: boolean;
  free_certificate: boolean;
  is_paid_internship: boolean;
  delivery_mode: 'remote' | 'in_person' | 'hybrid';
  benefits: string[];
  required_documents: string[];
  official_website: string;
  registration_url: string;
  evidence_status: ClaimStatus;
  source_type: SourceType;
  verification_history: Array<{ date: string; note: string; status: ClaimStatus }>;
  is_demo: boolean;
  demo_scenario: string | null;
  last_checked_at: string;
  created_at: string;
}

export interface CheckedRequirement {
  requirement: string;
  student_value: string;
  opportunity_rule: string;
  status: 'met' | 'likely_met' | 'not_met' | 'missing_info';
  explanation: string;
}

export interface EligibilityCheckRecord {
  id: string;
  user_id: string;
  opportunity_id: string | null;
  opportunity_name: string;
  overall_result: EligibilityResult;
  checked_requirements: CheckedRequirement[];
  missing_profile_fields: string[];
  recommendation_note: string;
  created_at: string;
}

export interface ApplicationRecord {
  id: string;
  user_id: string;
  opportunity_id: string | null;
  opportunity_name: string;
  organizer: string;
  deadline: string;
  status: ApplicationStatus;
  submission_date: string | null;
  checklist: Array<{ id: string; label: string; done: boolean }>;
  document_checklist: Array<{ id: string; label: string; done: boolean }>;
  notes: string;
  interview_date: string | null;
  follow_up_date: string | null;
  outcome: string;
  reminder_enabled: boolean;
  updated_at: string;
  created_at: string;
}

export interface CommunityReport {
  id: string;
  user_id: string | null;
  is_anonymous: boolean;
  opportunity_id: string | null;
  opportunity_name: string;
  target_url: string;
  category: CommunityReportCategory;
  description: string;
  evidence_notes: string;
  status: 'pending' | 'under_review' | 'approved' | 'rejected' | 'needs_evidence';
  moderator_notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  type: 'deadline' | 'verification' | 'eligibility' | 'community' | 'system';
  title: string;
  message: string;
  link: string | null;
  is_read: boolean;
  created_at: string;
}
