import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { apiFetch } from '../../lib/api.ts';
import { ClaimStatusTag } from '../../components/StatusBadge.tsx';
import { SOURCE_TYPES, type ClaimStatus, type CommunityReport, type SourceType, type UserAccount } from '../../types/proofpath.ts';

interface AdminAnalytics {
  totals: {
    users: number;
    verificationReports: number;
    opportunities: number;
    pendingCommunityReports: number;
  };
  claimDistribution: Array<{ status: string; count: number }>;
  riskDistribution: Array<{ risk_category: string; count: number }>;
  categoryBreakdown: Array<{ category: string; count: number }>;
  aiSummary: Array<{
    mode: string;
    requests: number;
    prompt_tokens: number;
    output_tokens: number;
    failures: number;
  }>;
}

const ADMIN_TABS = [
  { to: '/admin', label: 'Overview' },
  { to: '/admin/users', label: 'Users' },
  { to: '/admin/opportunities', label: 'Opportunities' },
  { to: '/admin/sources', label: 'Sources' },
  { to: '/admin/moderation', label: 'Moderation' },
  { to: '/admin/reports', label: 'Reports' },
  { to: '/admin/ai-usage', label: 'AI Usage' },
  { to: '/admin/analytics', label: 'Analytics' },
  { to: '/admin/security', label: 'Security Logs' },
  { to: '/admin/settings', label: 'System Health' },
];

export function AdminConsole() {
  const location = useLocation();
  const section = location.pathname.replace('/admin', '').replace(/^\//, '') || 'overview';

  const [analytics, setAnalytics] = useState<AdminAnalytics | null>(null);
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [opps, setOpps] = useState<Array<Record<string, unknown>>>([]);
  const [sources, setSources] = useState<Array<Record<string, unknown>>>([]);
  const [commReports, setCommReports] = useState<CommunityReport[]>([]);
  const [verReports, setVerReports] = useState<Array<Record<string, unknown>>>([]);
  const [aiLogs, setAiLogs] = useState<Array<Record<string, unknown>>>([]);
  const [secLogs, setSecLogs] = useState<{
    adminLogs: Array<Record<string, unknown>>;
    moderationLogs: Array<Record<string, unknown>>;
  }>({ adminLogs: [], moderationLogs: [] });
  const [health, setHealth] = useState<Record<string, unknown> | null>(null);

  // Add Source Form
  const [srcDomain, setSrcDomain] = useState('');
  const [srcOrg, setSrcOrg] = useState('');
  const [srcType, setSrcType] = useState<SourceType>('Official university website');
  const [srcUrl, setSrcUrl] = useState('');
  const [srcNote, setSrcNote] = useState('');

  // Add Opportunity Form
  const [oppName, setOppName] = useState('');
  const [oppOrg, setOppOrg] = useState('');
  const [oppCat, setOppCat] = useState('Scholarships');
  const [oppCountry, setOppCountry] = useState('International');
  const [oppDeadline, setOppDeadline] = useState('2027-06-01');
  const [oppFees, setOppFees] = useState('Free ($0)');
  const [oppWeb, setOppWeb] = useState('https://example.edu');

  const loadSection = () => {
    apiFetch<AdminAnalytics>('/api/admin/analytics')
      .then(setAnalytics)
      .catch(() => {});

    if (section === 'users') {
      apiFetch<{ users: UserAccount[] }>('/api/admin/users')
        .then((r) => setUsers(r.users))
        .catch(() => {});
    } else if (section === 'opportunities') {
      apiFetch<{ opportunities: Array<Record<string, unknown>> }>('/api/admin/opportunities')
        .then((r) => setOpps(r.opportunities))
        .catch(() => {});
    } else if (section === 'sources') {
      apiFetch<{ sources: Array<Record<string, unknown>> }>('/api/admin/sources')
        .then((r) => setSources(r.sources))
        .catch(() => {});
    } else if (section === 'moderation') {
      apiFetch<{ reports: CommunityReport[] }>('/api/admin/community-reports')
        .then((r) => setCommReports(r.reports))
        .catch(() => {});
    } else if (section === 'reports') {
      apiFetch<{ reports: Array<Record<string, unknown>> }>('/api/admin/reports')
        .then((r) => setVerReports(r.reports))
        .catch(() => {});
    } else if (section === 'ai-usage') {
      apiFetch<{ logs: Array<Record<string, unknown>> }>('/api/admin/ai-usage')
        .then((r) => setAiLogs(r.logs))
        .catch(() => {});
    } else if (section === 'security') {
      apiFetch<typeof secLogs>('/api/admin/security-logs')
        .then(setSecLogs)
        .catch(() => {});
    } else if (section === 'settings' || section === 'overview') {
      apiFetch<Record<string, unknown>>('/api/admin/system-health')
        .then(setHealth)
        .catch(() => {});
    }
  };

  useEffect(() => {
    loadSection();
  }, [section]);

  const updateUser = async (id: string, patch: { role?: string; status?: string }) => {
    await apiFetch(`/api/admin/users/${id}`, { method: 'PUT', body: JSON.stringify(patch) });
    loadSection();
  };

  const moderateReport = async (
    id: string,
    status: 'approved' | 'rejected' | 'needs_evidence',
    note: string
  ) => {
    await apiFetch(`/api/admin/community-reports/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ status, moderator_notes: note }),
    });
    loadSection();
  };

  const addSource = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/admin/sources', {
      method: 'POST',
      body: JSON.stringify({
        domain: srcDomain,
        organization_name: srcOrg,
        source_type: srcType,
        official_website: srcUrl,
        reliability_explanation: srcNote,
      }),
    });
    setSrcDomain('');
    setSrcOrg('');
    setSrcUrl('');
    setSrcNote('');
    loadSection();
  };

  const addOpportunity = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/admin/opportunities', {
      method: 'POST',
      body: JSON.stringify({
        name: oppName,
        organizer: oppOrg,
        category: oppCat,
        country: oppCountry,
        description: `${oppName} administered by ${oppOrg}.`,
        eligibility_summary: 'See official website for full rules.',
        deadline: oppDeadline,
        funding: 'Varies',
        fees: oppFees,
        official_website: oppWeb,
        registration_url: oppWeb,
        evidence_status: 'UNVERIFIED',
      }),
    });
    setOppName('');
    setOppOrg('');
    loadSection();
  };

  return (
    <DashboardLayout title="Admin & Trust Governance Console" breadcrumb={`Admin / ${section}`}>
      <div className="space-y-6">
        <div className="flex flex-wrap gap-1.5 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          {ADMIN_TABS.map((tab) => {
            const active = location.pathname === tab.to;
            return (
              <Link
                key={tab.to}
                to={tab.to}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {tab.label}
              </Link>
            );
          })}
        </div>

        {(section === 'overview' || section === 'analytics') && analytics && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Total Users', val: analytics.totals.users },
                { label: 'Verification Reports', val: analytics.totals.verificationReports },
                { label: 'Active Opportunities', val: analytics.totals.opportunities },
                { label: 'Pending Moderation', val: analytics.totals.pendingCommunityReports },
              ].map((m) => (
                <div
                  key={m.label}
                  className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                >
                  <div className="text-xs text-slate-500">{m.label}</div>
                  <div className="text-2xl font-bold font-mono tabular-nums mt-1">{m.val}</div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
                <h2 className="text-sm font-semibold">Claim Verification Distribution</h2>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.claimDistribution}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
                      <XAxis dataKey="status" tick={{ fontSize: 10 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="count" fill="#2563EB" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
                <h2 className="text-sm font-semibold">Risk Category Distribution</h2>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.riskDistribution}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
                      <XAxis dataKey="risk_category" tick={{ fontSize: 10 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="count" fill="#0EA5E9" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        )}

        {section === 'users' && (
          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                <tr>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">Email</th>
                  <th className="p-3.5">Role</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="p-3.5 font-medium">{u.name}</td>
                    <td className="p-3.5 font-mono">{u.email}</td>
                    <td className="p-3.5">
                      <select
                        value={u.role}
                        onChange={(e) => updateUser(u.id, { role: e.target.value })}
                        className="rounded border border-slate-300 dark:border-slate-700 bg-transparent px-2 py-1"
                      >
                        <option value="student">student</option>
                        <option value="moderator">moderator</option>
                        <option value="admin">admin</option>
                      </select>
                    </td>
                    <td className="p-3.5 font-mono">{u.status}</td>
                    <td className="p-3.5">
                      <button
                        type="button"
                        onClick={() =>
                          updateUser(u.id, {
                            status: u.status === 'active' ? 'suspended' : 'active',
                          })
                        }
                        className="text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        {u.status === 'active' ? 'Suspend' : 'Activate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {section === 'opportunities' && (
          <div className="space-y-6">
            <form
              onSubmit={addOpportunity}
              className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 grid grid-cols-1 md:grid-cols-3 gap-3"
            >
              <input
                type="text"
                required
                placeholder="Opportunity Name"
                value={oppName}
                onChange={(e) => setOppName(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="text"
                required
                placeholder="Organizer"
                value={oppOrg}
                onChange={(e) => setOppOrg(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="text"
                required
                placeholder="Category"
                value={oppCat}
                onChange={(e) => setOppCat(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="text"
                required
                placeholder="Country"
                value={oppCountry}
                onChange={(e) => setOppCountry(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="date"
                required
                value={oppDeadline}
                onChange={(e) => setOppDeadline(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="url"
                required
                placeholder="Official URL"
                value={oppWeb}
                onChange={(e) => setOppWeb(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <button
                type="submit"
                className="md:col-span-3 justify-self-end px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold"
              >
                Add Registry Opportunity
              </button>
            </form>

            <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              {opps.map((o) => (
                <div key={String(o.id)} className="p-4 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="font-semibold text-sm">{String(o.name)}</div>
                    <div className="text-slate-500">
                      {String(o.organizer)} · Due {String(o.deadline)}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <ClaimStatusTag status={String(o.evidence_status) as ClaimStatus} />
                    {!o.archived_at && (
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/api/admin/opportunities/${o.id}`, { method: 'DELETE' });
                          loadSection();
                        }}
                        className="text-red-500 hover:underline"
                      >
                        Archive
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {section === 'sources' && (
          <div className="space-y-6">
            <form
              onSubmit={addSource}
              className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 grid grid-cols-1 md:grid-cols-2 gap-3"
            >
              <input
                type="text"
                required
                placeholder="Domain (e.g. university.edu)"
                value={srcDomain}
                onChange={(e) => setSrcDomain(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="text"
                required
                placeholder="Organization Name"
                value={srcOrg}
                onChange={(e) => setSrcOrg(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <select
                value={srcType}
                onChange={(e) => setSrcType(e.target.value as SourceType)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              >
                {SOURCE_TYPES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
              <input
                type="url"
                required
                placeholder="Official Website URL"
                value={srcUrl}
                onChange={(e) => setSrcUrl(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="text"
                required
                placeholder="Reliability explanation"
                value={srcNote}
                onChange={(e) => setSrcNote(e.target.value)}
                className="md:col-span-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <button
                type="submit"
                className="md:col-span-2 justify-self-end px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold"
              >
                Register Verified Source
              </button>
            </form>

            <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              {sources.map((s) => (
                <div key={String(s.id)} className="p-4 text-xs space-y-1">
                  <div className="font-semibold text-sm">
                    {String(s.organization_name)} · <span className="font-mono">{String(s.domain)}</span>
                  </div>
                  <div className="text-slate-500">
                    {String(s.source_type)} — {String(s.reliability_explanation)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {section === 'moderation' && (
          <div className="space-y-4">
            {commReports.map((r) => (
              <div
                key={r.id}
                className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="font-semibold text-sm">{r.opportunity_name}</div>
                    <div className="text-xs text-slate-500">
                      {r.category} · Status: <span className="font-mono uppercase">{r.status}</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => moderateReport(r.id, 'approved', 'Verified by moderator review.')}
                      className="px-3 py-1 rounded bg-emerald-600 text-white text-xs font-medium"
                    >
                      Approve
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        moderateReport(r.id, 'needs_evidence', 'Requested additional documentation.')
                      }
                      className="px-3 py-1 rounded border border-amber-500 text-amber-600 dark:text-amber-300 text-xs font-medium"
                    >
                      Request Evidence
                    </button>
                    <button
                      type="button"
                      onClick={() => moderateReport(r.id, 'rejected', 'Insufficient corroboration.')}
                      className="px-3 py-1 rounded border border-red-500 text-red-600 dark:text-red-300 text-xs font-medium"
                    >
                      Reject
                    </button>
                  </div>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300">{r.description}</p>
              </div>
            ))}
          </div>
        )}

        {section === 'reports' && (
          <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            {verReports.map((r) => (
              <div key={String(r.id)} className="p-4 flex items-center justify-between gap-3 text-xs">
                <div>
                  <div className="font-semibold text-sm">{String(r.opportunity_name)}</div>
                  <div className="text-slate-500 font-mono">
                    {String(r.organizer_name)} · {String(r.analysis_mode)} · {String(r.model_used)}
                  </div>
                </div>
                <ClaimStatusTag status={String(r.overall_assessment) as ClaimStatus} />
              </div>
            ))}
          </div>
        )}

        {section === 'ai-usage' && (
          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <table className="w-full text-left text-xs font-mono">
              <thead className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                <tr>
                  <th className="p-3">Service</th>
                  <th className="p-3">Model</th>
                  <th className="p-3">Mode</th>
                  <th className="p-3">Tokens (In/Out)</th>
                  <th className="p-3">Latency</th>
                  <th className="p-3">OK</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {aiLogs.map((l) => (
                  <tr key={String(l.id)}>
                    <td className="p-3">{String(l.service_name)}</td>
                    <td className="p-3">{String(l.model)}</td>
                    <td className="p-3">{String(l.mode)}</td>
                    <td className="p-3 tabular-nums">
                      {String(l.prompt_tokens)} / {String(l.output_tokens)}
                    </td>
                    <td className="p-3 tabular-nums">{String(l.latency_ms)} ms</td>
                    <td className="p-3">{l.success ? 'YES' : 'ERR'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {section === 'security' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
              <h2 className="text-sm font-semibold">Admin Audit Log</h2>
              <div className="space-y-2 text-xs font-mono">
                {secLogs.adminLogs.map((l) => (
                  <div key={String(l.id)} className="p-2.5 rounded border border-slate-200 dark:border-slate-800">
                    {String(l.action)} · {String(l.target_type)}:{String(l.target_id)}
                  </div>
                ))}
              </div>
            </div>
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
              <h2 className="text-sm font-semibold">Moderation Audit Log</h2>
              <div className="space-y-2 text-xs font-mono">
                {secLogs.moderationLogs.map((l) => (
                  <div key={String(l.id)} className="p-2.5 rounded border border-slate-200 dark:border-slate-800">
                    {String(l.action)} · {String(l.report_id)} — {String(l.reason)}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {section === 'settings' && health && (
          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
            <h2 className="text-base font-semibold">System Health & Infrastructure Status</h2>
            <pre className="p-4 rounded-lg bg-slate-100 dark:bg-slate-950 text-xs font-mono overflow-x-auto">
              {JSON.stringify(health, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
