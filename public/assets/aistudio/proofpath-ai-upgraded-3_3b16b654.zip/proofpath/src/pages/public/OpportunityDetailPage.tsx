import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Bookmark, CheckCircle2, ClipboardPlus, ExternalLink, ShieldCheck } from 'lucide-react';
import { PublicLayout } from '../../components/PublicLayout.tsx';
import { ClaimStatusTag, DemoDataCallout, EligibilityTag } from '../../components/StatusBadge.tsx';
import { apiFetch } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import type { EligibilityCheckRecord, Opportunity } from '../../types/proofpath.ts';

export function OpportunityDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user, language } = useAuth();
  const navigate = useNavigate();
  const [opp, setOpp] = useState<Opportunity | null>(null);
  const [loading, setLoading] = useState(true);
  const [eligResult, setEligResult] = useState<EligibilityCheckRecord | null>(null);
  const [checkingElig, setCheckingElig] = useState(false);
  const [actionMsg, setActionMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    apiFetch<{ opportunity: Opportunity }>(`/api/opportunities/${id}`)
      .then((res) => setOpp(res.opportunity))
      .catch(() => setOpp(null))
      .finally(() => setLoading(false));
  }, [id]);

  const handleCheckEligibility = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!opp) return;
    setCheckingElig(true);
    try {
      const res = await apiFetch<{ result: EligibilityCheckRecord }>('/api/eligibility/check', {
        method: 'POST',
        body: JSON.stringify({ opportunityId: opp.id, language }),
      });
      setEligResult(res.result);
    } finally {
      setCheckingElig(false);
    }
  };

  const handleTrackApplication = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!opp) return;
    await apiFetch('/api/applications', {
      method: 'POST',
      body: JSON.stringify({
        opportunity_id: opp.id,
        opportunity_name: opp.name,
        organizer: opp.organizer,
        deadline: opp.deadline,
        status: 'RESEARCHING',
        checklist: [
          { id: 'c1', label: 'Confirm official source URL & fee schedule', done: false },
          { id: 'c2', label: 'Check eligibility requirements', done: false },
        ],
        document_checklist: opp.required_documents.map((doc, idx) => ({
          id: `d${idx}`,
          label: doc,
          done: false,
        })),
      }),
    });
    setActionMsg('Added to your Application Tracker.');
  };

  const handleSave = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!opp) return;
    await apiFetch('/api/opportunities/save', {
      method: 'POST',
      body: JSON.stringify({ opportunityId: opp.id }),
    });
    setActionMsg('Opportunity saved to your workspace.');
  };

  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
        <Link
          to="/opportunities"
          className="inline-flex items-center gap-1.5 text-sm text-slate-600 dark:text-slate-400 hover:text-blue-600"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Opportunities</span>
        </Link>

        {loading ? (
          <div className="h-64 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse" />
        ) : !opp ? (
          <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center">
            Opportunity not found.
          </div>
        ) : (
          <>
            {opp.is_demo && <DemoDataCallout label={opp.demo_scenario || undefined} />}
            {actionMsg && (
              <div className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 text-sm text-emerald-800 dark:text-emerald-200">
                {actionMsg}
              </div>
            )}

            <div className="p-6 sm:p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="space-y-2">
                  <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                    {opp.category} · {opp.country} · {opp.delivery_mode}
                  </div>
                  <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
                    {opp.name}
                  </h1>
                  <p className="text-sm text-slate-600 dark:text-slate-300">
                    Organizer: {opp.organizer} · Source Classification: {opp.source_type}
                  </p>
                </div>
                <ClaimStatusTag status={opp.evidence_status} />
              </div>

              <p className="text-sm sm:text-base text-slate-700 dark:text-slate-200 leading-relaxed">
                {opp.description}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-slate-200 dark:border-slate-800 text-sm">
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Deadline</div>
                  <div className="font-mono tabular-nums font-medium mt-0.5">
                    {formatLocalizedDate(opp.deadline, language)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Funding / Prize</div>
                  <div className="font-medium mt-0.5">{opp.funding}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Application Fee</div>
                  <div className="font-medium mt-0.5">{opp.fees}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Last Checked</div>
                  <div className="font-mono tabular-nums mt-0.5">
                    {formatLocalizedDate(opp.last_checked_at, language)}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={handleCheckEligibility}
                  disabled={checkingElig}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{checkingElig ? 'Checking...' : 'Check My Eligibility'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleTrackApplication}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <ClipboardPlus className="w-4 h-4" />
                  <span>Track Application</span>
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <Bookmark className="w-4 h-4" />
                  <span>Save Opportunity</span>
                </button>
                {!opp.is_demo && (
                  <a
                    href={opp.official_website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 ml-auto"
                  >
                    <span>Official Source</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>

            {eligResult && (
              <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
                    Personal Eligibility Result
                  </h2>
                  <EligibilityTag result={eligResult.overall_result} />
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  {eligResult.recommendation_note}
                </p>
                <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
                  {eligResult.checked_requirements.map((req, i) => (
                    <div key={i} className="p-3.5 text-sm flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <div className="font-medium text-slate-900 dark:text-white">
                          {req.requirement}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                          Your profile: {req.student_value} · Rule: {req.opportunity_rule}
                        </div>
                        <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                          {req.explanation}
                        </div>
                      </div>
                      <span className="text-xs font-mono uppercase px-2 py-1 rounded border border-slate-300 dark:border-slate-700 shrink-0">
                        {req.status.replace('_', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
                <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                  Benefits & Eligibility Summary
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  {opp.eligibility_summary}
                </p>
                <ul className="space-y-1.5 text-sm text-slate-700 dark:text-slate-200">
                  {opp.benefits.map((b, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
                <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                  Required Documents & Verification History
                </h2>
                <ul className="space-y-1.5 text-sm text-slate-700 dark:text-slate-200">
                  {opp.required_documents.map((d, i) => (
                    <li key={i} className="font-mono text-xs">
                      • {d}
                    </li>
                  ))}
                </ul>
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
                  {opp.verification_history.map((h, i) => (
                    <div key={i} className="text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-mono">{formatLocalizedDate(h.date, language)}:</span>{' '}
                      {h.note}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </PublicLayout>
  );
}
