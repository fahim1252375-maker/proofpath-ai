import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bookmark, GitCompare, Search } from 'lucide-react';
import { PublicLayout } from '../../components/PublicLayout.tsx';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { ClaimStatusTag, DemoDataCallout } from '../../components/StatusBadge.tsx';
import { apiFetch } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import type { Opportunity } from '../../types/proofpath.ts';

const CATEGORIES = [
  'all',
  'Scholarships',
  'Fellowships',
  'Remote internships',
  'Research internships',
  'Hackathons',
  'AI/ML competitions',
  'Innovation challenges',
  'Free courses',
];

export function OpportunitiesView({ inDashboard = false }: { inDashboard?: boolean }) {
  const { user, language, compareIds, toggleCompareId } = useAuth();
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('all');
  const [mode, setMode] = useState('all');
  const [status, setStatus] = useState('all');
  const [freeOnly, setFreeOnly] = useState(false);
  const [fundedOnly, setFundedOnly] = useState(false);
  const [certificateOnly, setCertificateOnly] = useState(false);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (q.trim()) params.set('q', q.trim());
    if (category !== 'all') params.set('category', category);
    if (mode !== 'all') params.set('mode', mode);
    if (status !== 'all') params.set('status', status);
    if (freeOnly) params.set('free', 'true');
    if (fundedOnly) params.set('fullyFunded', 'true');
    if (certificateOnly) params.set('freeCertificate', 'true');

    apiFetch<{ opportunities: Opportunity[] }>(`/api/opportunities?${params.toString()}`)
      .then((res) => setOpportunities(res.opportunities))
      .catch(() => setOpportunities([]))
      .finally(() => setLoading(false));
  }, [q, category, mode, status, freeOnly, fundedOnly, certificateOnly]);

  useEffect(() => {
    if (!user) return;
    apiFetch<{ opportunities: Opportunity[] }>('/api/opportunities/saved/list')
      .then((res) => setSavedIds(new Set(res.opportunities.map((o) => o.id))))
      .catch(() => {});
  }, [user]);

  const toggleSave = async (oppId: string) => {
    if (!user) return;
    if (savedIds.has(oppId)) {
      await apiFetch(`/api/opportunities/save/${oppId}`, { method: 'DELETE' });
      setSavedIds((prev) => {
        const next = new Set(prev);
        next.delete(oppId);
        return next;
      });
    } else {
      await apiFetch('/api/opportunities/save', {
        method: 'POST',
        body: JSON.stringify({ opportunityId: oppId }),
      });
      setSavedIds((prev) => new Set(prev).add(oppId));
    }
  };

  const content = (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Global Opportunity Discovery
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Filter scholarships, internships, hackathons, and courses with explicit evidence status.
          </p>
        </div>
        {compareIds.length > 0 && (
          <Link
            to={inDashboard ? '/dashboard/compare' : '/compare'}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold whitespace-nowrap shrink-0"
          >
            <GitCompare className="w-3.5 h-3.5" />
            <span>Compare Selected ({compareIds.length})</span>
          </Link>
        )}
      </div>

      <DemoDataCallout />

      {/* Search & Filters */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search scholarships, organizers, countries..."
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
            />
          </div>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            aria-label="Category filter"
            className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c === 'all' ? 'All Categories' : c}
              </option>
            ))}
          </select>
          <select
            value={mode}
            onChange={(e) => setMode(e.target.value)}
            aria-label="Delivery mode filter"
            className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
          >
            <option value="all">Remote & In-Person</option>
            <option value="remote">Remote Only</option>
            <option value="in_person">In-Person</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-700 dark:text-slate-300">
          <label className="inline-flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={freeOnly}
              onChange={(e) => setFreeOnly(e.target.checked)}
              className="rounded border-slate-400"
            />
            <span>Free Entry ($0 Fee)</span>
          </label>
          <label className="inline-flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={fundedOnly}
              onChange={(e) => setFundedOnly(e.target.checked)}
              className="rounded border-slate-400"
            />
            <span>Fully Funded</span>
          </label>
          <label className="inline-flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={certificateOnly}
              onChange={(e) => setCertificateOnly(e.target.checked)}
              className="rounded border-slate-400"
            />
            <span>Free Certificate</span>
          </label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            aria-label="Evidence status filter"
            className="ml-auto rounded-md border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-2.5 py-1 text-xs"
          >
            <option value="all">All Evidence Statuses</option>
            <option value="VERIFIED">VERIFIED</option>
            <option value="SUPPORTED">SUPPORTED</option>
            <option value="CONTRADICTED">CONTRADICTED</option>
            <option value="INSUFFICIENT_EVIDENCE">INSUFFICIENT_EVIDENCE</option>
            <option value="EXPIRED">EXPIRED</option>
          </select>
        </div>
      </div>

      {/* Results Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {[1, 2, 3, 4].map((n) => (
            <div
              key={n}
              className="h-48 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse"
            />
          ))}
        </div>
      ) : opportunities.length === 0 ? (
        <div className="p-10 text-center rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2">
          <p className="text-sm font-medium text-slate-900 dark:text-white">
            No opportunities match your selected filters.
          </p>
          <button
            type="button"
            onClick={() => {
              setQ('');
              setCategory('all');
              setMode('all');
              setStatus('all');
              setFreeOnly(false);
              setFundedOnly(false);
              setCertificateOnly(false);
            }}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
          >
            Reset all filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {opportunities.map((opp) => {
            const isCompared = compareIds.includes(opp.id);
            const isSaved = savedIds.has(opp.id);
            return (
              <div
                key={opp.id}
                className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span>
                      {opp.category} · {opp.country} · {opp.delivery_mode}
                    </span>
                    <span className="font-mono tabular-nums">
                      Due {formatLocalizedDate(opp.deadline, language)}
                    </span>
                  </div>
                  <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
                    {opp.name}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Organizer: {opp.organizer} · Fee: {opp.fees}
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-300 line-clamp-2">
                    {opp.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <ClaimStatusTag status={opp.evidence_status} />

                  <div className="flex items-center gap-2">
                    {user && (
                      <button
                        type="button"
                        onClick={() => toggleSave(opp.id)}
                        className={`px-2.5 py-1.5 rounded-md border text-xs font-medium inline-flex items-center gap-1 ${
                          isSaved
                            ? 'border-blue-500 bg-blue-600/10 text-blue-600 dark:text-blue-400'
                            : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        <Bookmark className="w-3.5 h-3.5" />
                        <span>{isSaved ? 'Saved' : 'Save'}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => toggleCompareId(opp.id)}
                      className={`px-2.5 py-1.5 rounded-md border text-xs font-medium inline-flex items-center gap-1 ${
                        isCompared
                          ? 'border-indigo-500 bg-indigo-600/10 text-indigo-600 dark:text-indigo-400'
                          : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      <GitCompare className="w-3.5 h-3.5" />
                      <span>{isCompared ? 'Added' : 'Compare'}</span>
                    </button>
                    <Link
                      to={`/opportunities/${opp.id}`}
                      className="px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
                    >
                      Inspect
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  if (inDashboard) {
    return (
      <DashboardLayout title="Opportunity Discovery" breadcrumb="Opportunities">
        {content}
      </DashboardLayout>
    );
  }

  return (
    <PublicLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">{content}</div>
    </PublicLayout>
  );
}
