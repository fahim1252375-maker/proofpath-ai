import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CheckCircle2, Lock, ShieldCheck } from 'lucide-react';
import { PublicLayout } from '../../components/PublicLayout.tsx';
import { VerificationWorkbench } from '../../components/VerificationWorkbench.tsx';
import { VerificationReportView } from '../../components/VerificationReportView.tsx';
import { apiFetch } from '../../lib/api.ts';
import type { VerificationReport } from '../../types/proofpath.ts';

export function PublicVerifyPage() {
  return (
    <PublicLayout>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <VerificationWorkbench />
      </div>
    </PublicLayout>
  );
}

export function SharedReportPage() {
  const { token } = useParams<{ token: string }>();
  const [report, setReport] = useState<VerificationReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    apiFetch<{ report: VerificationReport }>(`/api/verification/public/${token}`)
      .then((res) => setReport(res.report))
      .catch(() => setReport(null))
      .finally(() => setLoading(false));
  }, [token]);

  return (
    <PublicLayout>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {loading ? (
          <div className="h-64 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse" />
        ) : !report ? (
          <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center text-sm">
            Shared verification report not found or sharing has been disabled by the owner.
          </div>
        ) : (
          <VerificationReportView report={report} readOnly />
        )}
      </div>
    </PublicLayout>
  );
}

export function FeaturesPage() {
  const features = [
    {
      title: 'Claim-by-Claim Verification Engine',
      desc: 'Breaks every scholarship or internship advertisement into normalized claims—deadline, fee, prize, eligibility—and tracks exact supporting or contradicting evidence.',
    },
    {
      title: 'Transparent Fraud & Scam Risk Intelligence',
      desc: 'Identifies upfront certificate fees, guaranteed scholarship promises, domain mismatches, and requests for banking credentials without falsely accusing legitimate institutions.',
    },
    {
      title: 'Deterministic Eligibility Matching',
      desc: 'Evaluates your country, nationality, age, education level, GPA, and English proficiency against opportunity rules without guessing missing data.',
    },
    {
      title: 'Multimodal Document & Poster Analyzer',
      desc: 'Inspects uploaded PDF guidelines, flyer screenshots, and posters with strict MIME signature verification and zero execution risk.',
    },
    {
      title: 'Application Tracker & Deadline Calendar',
      desc: 'Tracks 10 application stages, custom document checklists, interview dates, and follow-up reminders.',
    },
    {
      title: 'Bilingual ProofPath AI Assistant (EN / বাংলা)',
      desc: 'Answers student questions strictly from verified registry data and saved reports in English or Bangla.',
    },
  ];
  return (
    <PublicLayout>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="max-w-2xl space-y-2">
          <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
            Platform Capabilities
          </h1>
          <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base">
            Built for international students evaluating global scholarships, hackathons, fellowships,
            and remote internships.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div
              key={f.title}
              className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2"
            >
              <ShieldCheck className="w-5 h-5 text-blue-500" />
              <h2 className="text-base font-semibold text-slate-900 dark:text-white">{f.title}</h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </PublicLayout>
  );
}

export function HowItWorksPage() {
  const steps = [
    {
      step: '01. Submit Announcement, URL, or Poster',
      desc: 'Paste text from social media, an email invitation, an official URL, or upload a PDF/image poster. External URLs undergo SSRF and private-IP protection before fetching.',
    },
    {
      step: '02. Structured Extraction & Source Cross-Check',
      desc: 'Claims are extracted into normalized statements and cross-checked against official organizer text, the Evidence Source Registry, and deterministic calendar expiration checks.',
    },
    {
      step: '03. Inspect Claims, Contradictions & Risk Signals',
      desc: 'Every claim receives an explicit status (VERIFIED, SUPPORTED, CONTRADICTED, UNVERIFIED, INSUFFICIENT_EVIDENCE, or EXPIRED) with missing information highlighted clearly.',
    },
    {
      step: '04. Match Eligibility & Track Safely',
      desc: 'Run deterministic eligibility checks against your student profile and organize verified applications in your deadline calendar.',
    },
  ];
  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="space-y-2">
          <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
            How ProofPath AI Works
          </h1>
          <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base">
            Evidence before conclusions—every step is transparent and inspectable.
          </p>
        </div>
        <div className="space-y-4">
          {steps.map((s) => (
            <div
              key={s.step}
              className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2"
            >
              <h2 className="text-lg font-semibold text-slate-900 dark:text-white">{s.step}</h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
        <Link
          to="/verify"
          className="inline-flex items-center px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold"
        >
          Try the Verification Engine
        </Link>
      </div>
    </PublicLayout>
  );
}

export function PricingPage() {
  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="space-y-2 max-w-2xl">
          <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
            Honest Pricing & Deployment Tiers
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Student protection features are free. Advanced institutional integrations require self-hosted
            credentials.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <div className="text-xs font-mono text-blue-500">STUDENT TIER</div>
            <h2 className="text-xl font-bold">Free Student Access</h2>
            <div className="text-3xl font-bold font-mono tabular-nums">$0</div>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-blue-500" />Opportunity claim verification & risk signals</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-blue-500" />Student eligibility profile & matcher</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-blue-500" />Application tracker & calendar</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-blue-500" />English & Bangla AI Assistant</li>
            </ul>
            <Link to="/register" className="inline-block px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold">
              Get Started Free
            </Link>
          </div>
          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <div className="text-xs font-mono text-slate-400">INSTITUTIONAL DEPLOYMENT</div>
            <h2 className="text-xl font-bold">University / NGO Pilot</h2>
            <div className="text-3xl font-bold font-mono">Custom</div>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-slate-500" />Dedicated Gemini & MongoDB Atlas configuration</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-slate-500" />Custom moderator RBAC & audit logging</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-slate-500" />Scheduled background monitoring worker setup</li>
            </ul>
            <Link to="/contact" className="inline-block px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold">
              Contact Sales / Team
            </Link>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}

export function AboutPage() {
  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          About ProofPath AI
        </h1>
        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
          ProofPath AI was designed to protect international high school, college, and university
          students from misleading opportunity advertisements, hidden upfront fees, impersonated
          organizations, and expired cycles.
        </p>
        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3 text-sm text-slate-600 dark:text-slate-300">
          <h2 className="font-semibold text-slate-900 dark:text-white">Core Engineering Principles</h2>
          <p>1. Evidence before conclusions—never fabricate citations or URLs.</p>
          <p>2. Honest uncertainty—when official evidence is absent, state that clearly.</p>
          <p>3. Fair risk signaling—separate structural risk warnings from confirmed fraud.</p>
        </div>
      </div>
    </PublicLayout>
  );
}

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    try {
      const res = await apiFetch<{ message: string }>('/api/contact', {
        method: 'POST',
        body: JSON.stringify({ name, email, subject, message }),
      });
      setSent(res.message);
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    } catch (error) {
      setErr(error instanceof Error ? error.message : 'Failed to send message.');
    }
  };

  return (
    <PublicLayout>
      <div className="max-w-xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="p-6 sm:p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-5">
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Contact ProofPath AI
          </h1>
          {sent && (
            <div className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 text-sm text-emerald-700 dark:text-emerald-300">
              {sent}
            </div>
          )}
          {err && (
            <div className="p-3 rounded-lg border border-red-500/30 bg-red-500/10 text-sm text-red-700 dark:text-red-300">
              {err}
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              required
              placeholder="Your Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
            />
            <input
              type="email"
              required
              placeholder="Your Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
            />
            <input
              type="text"
              required
              placeholder="Subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
            />
            <textarea
              rows={4}
              required
              placeholder="Message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
            />
            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </PublicLayout>
  );
}

export function LegalDocPage({ type }: { type: 'privacy' | 'terms' | 'responsible-ai' }) {
  const titles = {
    privacy: 'Privacy Policy & Data Minimization',
    terms: 'Terms of Service & Acceptable Use Policy',
    'responsible-ai': 'Responsible AI & Security Information',
  };
  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 text-xs font-mono">
          <Lock className="w-4 h-4" />
          <span>PROOFPATH AI GOVERNANCE</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          {titles[type]}
        </h1>
        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          {type === 'privacy' && (
            <>
              <p>
                ProofPath AI practices data minimization: students only store profile fields needed
                for eligibility matching (country, education level, age, optional GPA/test scores).
                Never submit sensitive banking passwords, national ID numbers, or financial credentials.
              </p>
              <p>
                Authenticated users can export all stored personal records in JSON format or delete
                their account anytime from Dashboard Settings. Shared verification reports omit
                personal user identifiers.
              </p>
            </>
          )}
          {type === 'terms' && (
            <>
              <p>
                ProofPath AI provides automated claim extraction and risk indicators for educational
                guidance. Reports are informational and do not constitute legal advice or an official
                institutional endorsement.
              </p>
              <p>
                Acceptable Use: Users must not attempt SSRF probing against private networks, upload
                malicious payloads, or submit defamatory community reports without supporting evidence.
              </p>
            </>
          )}
          {type === 'responsible-ai' && (
            <>
              <p>
                All external web pages, announcements, and uploaded documents are processed as
                untrusted data isolated from system instructions. No arbitrary numerical "probability
                of fraud" score is presented as scientific fact.
              </p>
              <p>
                Security controls include bcrypt password hashing, HTTP-only JWT cookies, strict
                SSRF private-IP/metadata blocking, MIME signature checks on uploads, rate limiting,
                and server-side RBAC enforcement.
              </p>
            </>
          )}
        </div>
      </div>
    </PublicLayout>
  );
}
