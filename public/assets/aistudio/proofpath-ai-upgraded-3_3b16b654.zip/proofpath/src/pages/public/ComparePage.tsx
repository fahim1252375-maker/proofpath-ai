import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PublicLayout } from '../../components/PublicLayout.tsx';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { ClaimStatusTag, DemoDataCallout } from '../../components/StatusBadge.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { apiFetch } from '../../lib/api.ts';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import type { Opportunity } from '../../types/proofpath.ts';

export function CompareView({ inDashboard = false }: { inDashboard?: boolean }) {
  const { compareIds, toggleCompareId, profile, language } = useAuth();
  const [allOpps, setAllOpps] = useState<Opportunity[]>([]);
  const [selectedOpps, setSelectedOpps] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch<{ opportunities: Opportunity[] }>('/api/opportunities?limit=50')
      .then((res) => setAllOpps(res.opportunities))
      .catch(() => setAllOpps([]));
  }, []);

  useEffect(() => {
    if (compareIds.length === 0) {
      setSelectedOpps([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    apiFetch<{ opportunities: Opportunity[] }>('/api/opportunities/compare', {
      method: 'POST',
      body: JSON.stringify({ ids: compareIds }),
    })
      .then((res) => setSelectedOpps(res.opportunities))
      .catch(() => setSelectedOpps([]))
      .finally(() => setLoading(false));
  }, [compareIds]);

  const computeProfileFitNote = (opp: Opportunity): string => {
    if (!profile || (!profile.country && !profile.education_level)) {
      return 'Complete your student profile for personalized fit notes.';
    }
    const notes: string[] = [];
    if (profile.financial_preference === 'free_or_funded' && !opp.is_free) {
      notes.push('Conflicts with your no-fee preference');
    } else if (opp.is_free) {
      notes.push('Matches zero-fee preference');
    }
    if (
      profile.education_level &&
      opp.eligibility_rules.education_levels?.some(
        (lvl) => lvl.toLowerCase() === profile.education_level.toLowerCase()
      )
    ) {
      notes.push(`Fits ${profile.education_level} level`);
    }
    if (opp.evidence_status === 'CONTRADICTED' || opp.evidence_status === 'EXPIRED') {
      notes.push(`Caution: flagged ${opp.evidence_status}`);
    }
    return notes.join(' · ') || 'Review full eligibility criteria';
  };

  const rows: Array<{ label: string; render: (o: Opportunity) => React.ReactNode }> = [
    { label: 'Evidence Status', render: (o) => <ClaimStatusTag status={o.evidence_status} /> },
    { label: 'Source Reliability', render: (o) => o.source_type },
    { label: 'Organizer', render: (o) => o.organizer },
    { label: 'Country & Format', render: (o) => `${o.country} (${o.delivery_mode})` },
    { label: 'Deadline', render: (o) => <span className="font-mono tabular-nums">{formatLocalizedDate(o.deadline, language)}</span> },
    { label: 'Application Fee', render: (o) => o.fees },
    { label: 'Funding / Prize', render: (o) => o.funding },
    { label: 'Free Certificate', render: (o) => (o.free_certificate ? 'Yes ($0)' : 'Not confirmed') },
    { label: 'Eligibility Summary', render: (o) => o.eligibility_summary },
    { label: 'Required Documents', render: (o) => o.required_documents.join(', ') || 'Not specified' },
    { label: 'Personalized Fit Note', render: (o) => computeProfileFitNote(o) },
  ];

  const body = (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Opportunity Comparison Matrix
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Compare up to 4 opportunities side by side across fees, evidence quality, deadlines, and
            eligibility.
          </p>
        </div>
        <Link
          to={inDashboard ? '/dashboard/opportunities' : '/opportunities'}
          className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap"
        >
          Browse Opportunities →
        </Link>
      </div>

      <DemoDataCallout />

      {/* Selector Chips */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2.5">
        <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
          Select up to 4 opportunities to compare ({compareIds.length}/4 selected)
        </div>
        <div className="flex flex-wrap gap-2">
          {allOpps.map((o) => {
            const active = compareIds.includes(o.id);
            return (
              <button
                key={o.id}
                type="button"
                onClick={() => toggleCompareId(o.id)}
                className={`px-3 py-1.5 rounded-md border text-xs font-medium transition-colors ${
                  active
                    ? 'border-blue-600 bg-blue-600 text-white'
                    : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-blue-500'
                }`}
              >
                {o.name.replace(' (DEMO DATA)', '')}
              </button>
            );
          })}
        </div>
      </div>

      {loading ? (
        <div className="h-64 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse" />
      ) : selectedOpps.length === 0 ? (
        <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center text-sm text-slate-500">
          Select at least one opportunity above to inspect side-by-side differences.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <table className="w-full text-left border-collapse min-w-[680px]">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                <th className="p-4 text-xs font-semibold text-slate-500 dark:text-slate-400 w-44">
                  Dimension
                </th>
                {selectedOpps.map((o) => (
                  <th key={o.id} className="p-4 text-sm font-semibold text-slate-900 dark:text-white">
                    <Link to={`/opportunities/${o.id}`} className="hover:text-blue-500">
                      {o.name}
                    </Link>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-sm">
              {rows.map((r) => (
                <tr key={r.label} className="align-top">
                  <td className="p-4 text-xs font-medium text-slate-500 dark:text-slate-400">
                    {r.label}
                  </td>
                  {selectedOpps.map((o) => (
                    <td key={o.id} className="p-4 text-slate-700 dark:text-slate-200">
                      {r.render(o)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  if (inDashboard) {
    return (
      <DashboardLayout title="Compare Opportunities" breadcrumb="Compare">
        {body}
      </DashboardLayout>
    );
  }
  return (
    <PublicLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">{body}</div>
    </PublicLayout>
  );
}
