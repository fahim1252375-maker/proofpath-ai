import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  FileSearch,
  Lock,
  Scale,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { PublicLayout } from '../../components/PublicLayout.tsx';
import { ClaimStatusTag, DemoDataCallout, RiskCategoryTag } from '../../components/StatusBadge.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { apiFetch } from '../../lib/api.ts';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import type { ClaimStatus, Opportunity, RiskCategory } from '../../types/proofpath.ts';

const INTERACTIVE_PREVIEW_CASES: Array<{
  id: string;
  tab: string;
  title: string;
  overall: ClaimStatus;
  risk: RiskCategory;
  claims: Array<{
    claim: string;
    status: ClaimStatus;
    evidence: string;
  }>;
}> = [
  {
    id: 'contradicted',
    tab: 'Fee Contradiction',
    title: 'Global Scholars STEM Summit (DEMO)',
    overall: 'CONTRADICTED',
    risk: 'HIGH CONCERN',
    claims: [
      {
        claim: 'Promotional post: "100% Free entry for all countries"',
        status: 'CONTRADICTED',
        evidence: 'Official guidelines page 2 specifies $45 mandatory fee and 14 eligible countries.',
      },
      {
        claim: 'Application deadline: 2027-02-10',
        status: 'SUPPORTED',
        evidence: 'Matches official university exchange portal date.',
      },
    ],
  },
  {
    id: 'insufficient',
    tab: 'Missing Source',
    title: 'Apex Frontier AI Olympiad (DEMO)',
    overall: 'INSUFFICIENT_EVIDENCE',
    risk: 'MODERATE CONCERN',
    claims: [
      {
        claim: 'Prize pool: $10,000 cash award',
        status: 'INSUFFICIENT_EVIDENCE',
        evidence: 'Circulated via messaging flyer only; no institutional domain or rulebook found.',
      },
      {
        claim: 'Registration link: External form',
        status: 'UNVERIFIED',
        evidence: 'Organizer identity cannot be confirmed independently.',
      },
    ],
  },
  {
    id: 'supported',
    tab: 'Consistent Source',
    title: 'Nordic Youth Climate Grant (DEMO)',
    overall: 'SUPPORTED',
    risk: 'LOW CONCERN',
    claims: [
      {
        claim: 'Application fee: $0 (Free)',
        status: 'SUPPORTED',
        evidence: 'Official announcement confirms zero fee and free digital certificate.',
      },
      {
        claim: 'Open to international students aged 16–24',
        status: 'SUPPORTED',
        evidence: 'Consistent across summary and eligibility section.',
      },
    ],
  },
];

const FAQS = [
  {
    q: 'Does ProofPath AI guarantee an opportunity is legitimate?',
    a: 'No. ProofPath AI distinguishes verified facts, supported claims, contradictions, and missing evidence. Automated checks never replace direct confirmation with the official institution.',
  },
  {
    q: 'How does ProofPath handle announcements without an official website?',
    a: 'When no independent official evidence is available, ProofPath explicitly marks the assessment as INSUFFICIENT EVIDENCE and states: "Official evidence not available. This opportunity remains unverified."',
  },
  {
    q: 'Is an HTTPS padlock treated as proof of safety?',
    a: 'Never. Anyone can obtain an HTTPS certificate for a deceptive domain. ProofPath inspects domain alignment, payment transparency, contradictions, and source registry classification.',
  },
  {
    q: 'Which languages are supported?',
    a: 'ProofPath AI supports English (default) and Bangla (বাংলা) across the interface, verification summaries, eligibility explanations, and the ProofPath AI Assistant.',
  },
];

export function LandingPage() {
  const { t, language } = useAuth();
  const [activePreviewId, setActivePreviewId] = useState(INTERACTIVE_PREVIEW_CASES[0].id);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  useEffect(() => {
    apiFetch<{ opportunities: Opportunity[] }>('/api/opportunities?limit=4')
      .then((res) => setOpportunities(res.opportunities))
      .catch(() => setOpportunities([]));
  }, []);

  const preview =
    INTERACTIVE_PREVIEW_CASES.find((c) => c.id === activePreviewId) ||
    INTERACTIVE_PREVIEW_CASES[0];

  return (
    <PublicLayout>
      {/* 1. Hero Section */}
      <section className="border-b border-slate-200 dark:border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            <div className="text-xs font-mono tracking-wide text-blue-600 dark:text-blue-400">
              {t.brandName} · {t.tagline}
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-slate-900 dark:text-white leading-[1.12]">
              {t.heroHeadline}
            </h1>
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
              {t.heroSubheadline}
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Link
                to="/verify"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                <span>{t.primaryCta}</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/opportunities"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                <span>{t.secondaryCta}</span>
              </Link>
            </div>
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-4 text-xs text-slate-600 dark:text-slate-400">
              <div>
                <div className="font-semibold text-slate-900 dark:text-slate-100">
                  Claim-Level Audits
                </div>
                <div>Evidence before conclusions</div>
              </div>
              <div>
                <div className="font-semibold text-slate-900 dark:text-slate-100">
                  Deterministic Rules
                </div>
                <div>Transparent eligibility checks</div>
              </div>
              <div>
                <div className="font-semibold text-slate-900 dark:text-slate-100">
                  Global & Bilingual
                </div>
                <div>English & Bangla support</div>
              </div>
            </div>
          </div>

          {/* Interactive Verification Preview Workbench */}
          <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                  INTERACTIVE EVIDENCE DEMO
                </div>
                <div className="inline-flex p-1 rounded-lg bg-slate-100 dark:bg-slate-800">
                  {INTERACTIVE_PREVIEW_CASES.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setActivePreviewId(c.id)}
                      className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        activePreviewId === c.id
                          ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                          : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {c.tab}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 space-y-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {preview.title}
                </h2>
                <div className="flex flex-wrap items-center gap-2">
                  <ClaimStatusTag status={preview.overall} />
                  <RiskCategoryTag category={preview.risk} />
                </div>
              </div>

              <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
                {preview.claims.map((item, idx) => (
                  <div key={idx} className="p-3.5 space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-sm font-medium text-slate-900 dark:text-slate-100">
                        {item.claim}
                      </span>
                      <ClaimStatusTag status={item.status} />
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{item.evidence}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800 text-xs">
              <span className="text-slate-500 dark:text-slate-400">
                DEMO DATA — Test with your own scholarship or internship text
              </span>
              <Link
                to="/verify"
                className="font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0"
              >
                Open Full Verifier →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 2. How ProofPath AI Works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-8">
        <div className="max-w-2xl space-y-2">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Evidence Before Conclusions
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
            ProofPath AI does not simply tell students what to trust. It breaks announcements into
            inspectable claims, highlights contradictions, and surfaces missing evidence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              num: '01. Extract Claims',
              desc: 'Parses deadlines, application fees, prize amounts, country restrictions, and required documents from text, URLs, or uploaded posters.',
              Icon: FileSearch,
            },
            {
              num: '02. Compare Evidence',
              desc: 'Cross-checks promotional statements against official organizer text or SSRF-protected source snapshots, labeling each claim honestly.',
              Icon: Scale,
            },
            {
              num: '03. Surface Risk Signals',
              desc: 'Detects upfront certificate fees, guaranteed award phrasing, urgency traps, and banking credential requests without accusing unfairly.',
              Icon: ShieldAlert,
            },
            {
              num: '04. Match Eligibility',
              desc: 'Runs deterministic checks against your student profile—country, age, education level, GPA, and English proficiency—without guessing.',
              Icon: UserCheck,
            },
          ].map(({ num, desc, Icon }) => (
            <div
              key={num}
              className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3"
            >
              <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">{num}</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Asymmetric Feature Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 p-6 sm:p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Complete Student Protection & Application Workflow
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Move safely from discovery to submission. Compare up to four opportunities side by side,
              track checklists and interview dates in your application calendar, and ask the
              bilingual ProofPath AI Assistant questions in English or Bangla.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-sm">
              {[
                'Multimodal PDF, poster & screenshot analyzer',
                'Community fraud reporting with human moderation queue',
                'Side-by-side opportunity & risk comparison matrix',
                'Exportable & privacy-controlled verification reports',
              ].map((item) => (
                <div key={item} className="flex items-start gap-2 text-slate-700 dark:text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 sm:p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <Lock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                Security-First Architecture
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                External URLs pass strict SSRF and private-IP validation. Uploaded files are checked
                by MIME signature and never executed. Untrusted announcements are isolated against
                prompt injection.
              </p>
            </div>
            <Link
              to="/responsible-ai"
              className="text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline"
            >
              Read Responsible AI & Security Disclosure →
            </Link>
          </div>
        </div>
      </section>

      {/* 4. Demo Opportunity Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              Sample Verification Registry
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Explore how ProofPath classifies consistent, contradicted, insufficient-evidence, and
              expired opportunities.
            </p>
          </div>
          <Link
            to="/opportunities"
            className="text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap"
          >
            Browse all listings →
          </Link>
        </div>

        <DemoDataCallout />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {opportunities.map((opp) => (
            <div
              key={opp.id}
              className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span>
                    {opp.category} · {opp.country} · {opp.delivery_mode}
                  </span>
                  <span className="font-mono tabular-nums">
                    Due {formatLocalizedDate(opp.deadline, language)}
                  </span>
                </div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                  {opp.name}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                  {opp.description}
                </p>
              </div>
              <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <ClaimStatusTag status={opp.evidence_status} />
                <Link
                  to={`/opportunities/${opp.id}`}
                  className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap"
                >
                  Inspect Details →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Honest Pricing Overview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <div className="max-w-2xl space-y-2">
          <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Transparent Access & Availability
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Student protection tools are free to test today. Enterprise and institutional feeds are
            honestly marked as configurable deployment options.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <div>
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">FOR STUDENTS</div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                Free Verification Workspace
              </h3>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-2">
                $0 / month
              </div>
            </div>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>Claim-by-claim verification & risk analysis</span>
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>Student eligibility matching & application tracker</span>
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>English & Bangla AI Assistant</span>
              </li>
            </ul>
            <Link
              to="/register"
              className="inline-flex items-center justify-center px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors"
            >
              Create Free Student Account
            </Link>
          </div>

          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <div>
              <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                FOR SCHOOLS & COMMUNITIES
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                Institutional & Moderation Deployment
              </h3>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-2">
                Self-Hosted / Custom
              </div>
            </div>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-500" />
                <span>Dedicated Evidence Source Registry curation</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-500" />
                <span>Moderator review queues & audit logs</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-500" />
                <span>Scheduled external monitoring (requires cron worker setup)</span>
              </li>
            </ul>
            <Link
              to="/contact"
              className="inline-flex items-center justify-center px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-semibold transition-colors"
            >
              Contact Team
            </Link>
          </div>
        </div>
      </section>

      {/* 6. FAQ */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          Frequently Asked Questions
        </h2>
        <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900">
          {FAQS.map((item, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div key={idx} className="p-5">
                <button
                  type="button"
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between gap-4 text-left font-medium text-sm sm:text-base text-slate-900 dark:text-white"
                >
                  <span>{item.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {item.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </PublicLayout>
  );
}
