import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, UserCheck } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { EligibilityTag } from '../../components/StatusBadge.tsx';
import { apiFetch } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import type { EligibilityCheckRecord, Opportunity } from '../../types/proofpath.ts';

export function EligibilityPage() {
  const { language, profile } = useAuth();
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [selectedOppId, setSelectedOppId] = useState('');
  const [history, setHistory] = useState<EligibilityCheckRecord[]>([]);
  const [latest, setLatest] = useState<EligibilityCheckRecord | null>(null);
  const [checking, setChecking] = useState(false);

  const [customMode, setCustomMode] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customDeadline, setCustomDeadline] = useState('2027-04-01');
  const [customCountries, setCustomCountries] = useState('International');
  const [customLevel, setCustomLevel] = useState('Undergraduate');
  const [customMinGpa, setCustomMinGpa] = useState('3.2');
  const [customMaxAge, setCustomMaxAge] = useState('25');

  const loadData = () => {
    apiFetch<{ opportunities: Opportunity[] }>('/api/opportunities?limit=50')
      .then((res) => {
        setOpportunities(res.opportunities);
        if (res.opportunities[0] && !selectedOppId) {
          setSelectedOppId(res.opportunities[0].id);
        }
      })
      .catch(() => {});

    apiFetch<{ history: EligibilityCheckRecord[] }>('/api/eligibility/history')
      .then((res) => setHistory(res.history))
      .catch(() => {});
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCheck = async (e: React.FormEvent) => {
    e.preventDefault();
    setChecking(true);
    try {
      const payload = customMode
        ? {
            language,
            customOpportunity: {
              name: customName || 'Custom Opportunity Rule Check',
              deadline: customDeadline,
              is_free: true,
              is_fully_funded: false,
              delivery_mode: 'remote' as const,
              eligibility_rules: {
                allowed_countries: customCountries
                  .split(',')
                  .map((s) => s.trim())
                  .filter(Boolean),
                education_levels: [customLevel],
                min_gpa: customMinGpa ? Number(customMinGpa) : null,
                max_age: customMaxAge ? Number(customMaxAge) : null,
              },
            },
          }
        : { opportunityId: selectedOppId, language };

      const res = await apiFetch<{ result: EligibilityCheckRecord }>('/api/eligibility/check', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      setLatest(res.result);
      setHistory((prev) => [res.result, ...prev]);
    } finally {
      setChecking(false);
    }
  };

  return (
    <DashboardLayout title="Student Eligibility Intelligence" breadcrumb="Eligibility">
      <div className="space-y-6">
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="text-sm">
            <div className="font-semibold text-slate-900 dark:text-white">
              Active Student Profile Snapshot
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Country: {profile?.country || 'Unset'} · Level: {profile?.education_level || 'Unset'} ·
              Age: {profile?.age ?? 'Unset'} · GPA: {profile?.gpa || 'Unset'} · English:{' '}
              {profile?.english_proficiency || 'Unset'}
            </div>
          </div>
          <Link
            to="/dashboard/profile"
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap"
          >
            Update Profile →
          </Link>
        </div>

        <form
          onSubmit={handleCheck}
          className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">
              Run Deterministic Requirement Check
            </h2>
            <div className="inline-flex p-1 rounded-lg bg-slate-100 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => setCustomMode(false)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                  !customMode ? 'bg-white dark:bg-slate-900 shadow-sm' : ''
                }`}
              >
                From Registry
              </button>
              <button
                type="button"
                onClick={() => setCustomMode(true)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                  customMode ? 'bg-white dark:bg-slate-900 shadow-sm' : ''
                }`}
              >
                Custom Rules
              </button>
            </div>
          </div>

          {!customMode ? (
            <div>
              <label className="block text-xs font-medium mb-1.5">Select Opportunity</label>
              <select
                value={selectedOppId}
                onChange={(e) => setSelectedOppId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
              >
                {opportunities.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name} (Due: {o.deadline})
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <input
                type="text"
                required
                placeholder="Opportunity Name"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <input
                type="date"
                value={customDeadline}
                onChange={(e) => setCustomDeadline(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <input
                type="text"
                placeholder="Allowed Countries (e.g. International or Germany, Japan)"
                value={customCountries}
                onChange={(e) => setCustomCountries(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <select
                value={customLevel}
                onChange={(e) => setCustomLevel(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="High School">High School</option>
                <option value="College">College</option>
                <option value="Undergraduate">Undergraduate</option>
                <option value="Graduate">Graduate</option>
              </select>
              <input
                type="number"
                step="0.1"
                placeholder="Min GPA (e.g. 3.2)"
                value={customMinGpa}
                onChange={(e) => setCustomMinGpa(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <input
                type="number"
                placeholder="Max Age (e.g. 25)"
                value={customMaxAge}
                onChange={(e) => setCustomMaxAge(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={checking}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold"
          >
            {checking ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserCheck className="w-4 h-4" />}
            <span>{checking ? 'Evaluating Rules...' : 'Evaluate Eligibility'}</span>
          </button>
        </form>

        {latest && (
          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {latest.opportunity_name}
              </h3>
              <EligibilityTag result={latest.overall_result} />
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300">{latest.recommendation_note}</p>
            <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
              {latest.checked_requirements.map((req, i) => (
                <div key={i} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-sm">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-white">{req.requirement}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Profile: {req.student_value} · Rule: {req.opportunity_rule}
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                      {req.explanation}
                    </div>
                  </div>
                  <span className="text-xs font-mono uppercase px-2 py-1 rounded border border-slate-300 dark:border-slate-700 shrink-0">
                    {req.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            Eligibility Check History
          </h3>
          {history.length === 0 ? (
            <p className="text-sm text-slate-500">No checks recorded yet.</p>
          ) : (
            <div className="divide-y divide-slate-200 dark:divide-slate-800">
              {history.map((h) => (
                <div key={h.id} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-slate-900 dark:text-white">
                      {h.opportunity_name}
                    </div>
                    <div className="text-xs text-slate-500 font-mono">
                      {formatLocalizedDate(h.created_at, language)}
                    </div>
                  </div>
                  <EligibilityTag result={h.overall_result} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
