import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Bookmark, Trash2 } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { VerificationWorkbench } from '../../components/VerificationWorkbench.tsx';
import { VerificationReportView } from '../../components/VerificationReportView.tsx';
import { ClaimStatusTag, DemoDataCallout } from '../../components/StatusBadge.tsx';
import { apiFetch } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import type { ClaimStatus, Opportunity, VerificationReport } from '../../types/proofpath.ts';

export function DashboardVerifyPage() {
  return (
    <DashboardLayout title="Verify Opportunity" breadcrumb="Verify">
      <VerificationWorkbench />
    </DashboardLayout>
  );
}

export function ReportsListPage() {
  const { language } = useAuth();
  const [reports, setReports] = useState<
    Array<{
      id: string;
      opportunity_name: string;
      organizer_name: string;
      category: string;
      overall_assessment: ClaimStatus;
      evidence_quality: string;
      analysis_mode: 'gemini' | 'demo';
      created_at: string;
    }>
  >([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    apiFetch<{ reports: typeof reports }>('/api/verification/history?limit=50')
      .then((res) => setReports(res.reports))
      .catch(() => setReports([]))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const handleDelete = async (id: string) => {
    await apiFetch(`/api/verification/${id}`, { method: 'DELETE' });
    setReports((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <DashboardLayout title="Saved Verification Reports" breadcrumb="Reports">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Every saved verification report preserves extracted claims, risk indicators, and source
            snapshots.
          </p>
          <Link
            to="/dashboard/verify"
            className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold whitespace-nowrap"
          >
            New Verification
          </Link>
        </div>

        {loading ? (
          <div className="h-48 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse" />
        ) : reports.length === 0 ? (
          <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center text-sm text-slate-500">
            No verification reports saved yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900">
            {reports.map((r) => (
              <div
                key={r.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1 min-w-0">
                  <Link
                    to={`/dashboard/reports/${r.id}`}
                    className="text-sm font-semibold text-slate-900 dark:text-white hover:text-blue-500 block truncate"
                  >
                    {r.opportunity_name}
                  </Link>
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    {r.organizer_name} · {r.category} · {r.analysis_mode.toUpperCase()} ·{' '}
                    {formatLocalizedDate(r.created_at, language)}
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <ClaimStatusTag status={r.overall_assessment} />
                  <Link
                    to={`/dashboard/reports/${r.id}`}
                    className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Open Report
                  </Link>
                  <button
                    type="button"
                    onClick={() => handleDelete(r.id)}
                    className="p-1.5 rounded-md text-slate-400 hover:text-red-500"
                    aria-label="Delete report"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

export function ReportDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [report, setReport] = useState<VerificationReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    apiFetch<{ report: VerificationReport }>(`/api/verification/${id}`)
      .then((res) => setReport(res.report))
      .catch(() => setReport(null))
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <DashboardLayout title={report?.opportunity_name || 'Verification Report'} breadcrumb="Reports">
      {loading ? (
        <div className="h-64 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse" />
      ) : !report ? (
        <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center text-sm">
          Verification report not found.
        </div>
      ) : (
        <VerificationReportView report={report} onReportUpdated={setReport} />
      )}
    </DashboardLayout>
  );
}

export function SavedOpportunitiesPage() {
  const { language } = useAuth();
  const [items, setItems] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch<{ opportunities: Opportunity[] }>('/api/opportunities/saved/list')
      .then((res) => setItems(res.opportunities))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []);

  const removeSaved = async (id: string) => {
    await apiFetch(`/api/opportunities/save/${id}`, { method: 'DELETE' });
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  return (
    <DashboardLayout title="Saved Opportunities" breadcrumb="Saved">
      <div className="space-y-5">
        <DemoDataCallout />
        {loading ? (
          <div className="h-40 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse" />
        ) : items.length === 0 ? (
          <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-3">
            <Bookmark className="w-6 h-6 text-slate-400 mx-auto" />
            <p className="text-sm text-slate-500">You have not saved any opportunities yet.</p>
            <Link
              to="/dashboard/opportunities"
              className="inline-block px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold"
            >
              Browse Opportunities
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {items.map((opp) => (
              <div
                key={opp.id}
                className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3"
              >
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>{opp.category}</span>
                  <span className="font-mono tabular-nums">
                    Due {formatLocalizedDate(opp.deadline, language)}
                  </span>
                </div>
                <h2 className="font-semibold text-slate-900 dark:text-white">{opp.name}</h2>
                <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">
                  <ClaimStatusTag status={opp.evidence_status} />
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => removeSaved(opp.id)}
                      className="text-xs text-red-500 hover:underline"
                    >
                      Remove
                    </button>
                    <Link
                      to={`/opportunities/${opp.id}`}
                      className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      Inspect
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
