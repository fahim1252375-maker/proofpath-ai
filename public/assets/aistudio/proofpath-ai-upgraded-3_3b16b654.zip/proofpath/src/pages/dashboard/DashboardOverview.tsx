import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowRight, Calendar, ClipboardList, FileSearch, ShieldCheck } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { ClaimStatusTag } from '../../components/StatusBadge.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { apiFetch } from '../../lib/api.ts';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import type { ApplicationRecord, ClaimStatus, Opportunity } from '../../types/proofpath.ts';

interface ReportSummary {
  id: string;
  opportunity_name: string;
  organizer_name: string;
  overall_assessment: ClaimStatus;
  analysis_mode: 'gemini' | 'demo';
  created_at: string;
}

export function DashboardOverview() {
  const { user, profile, language } = useAuth();
  const [reports, setReports] = useState<ReportSummary[]>([]);
  const [applications, setApplications] = useState<ApplicationRecord[]>([]);
  const [savedOpps, setSavedOpps] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.allSettled([
      apiFetch<{ reports: ReportSummary[] }>('/api/verification/history?limit=10'),
      apiFetch<{ applications: ApplicationRecord[] }>('/api/applications'),
      apiFetch<{ opportunities: Opportunity[] }>('/api/opportunities/saved/list'),
    ])
      .then(([repRes, appRes, savRes]) => {
        if (repRes.status === 'fulfilled') setReports(repRes.value.reports);
        if (appRes.status === 'fulfilled') setApplications(appRes.value.applications);
        if (savRes.status === 'fulfilled') setSavedOpps(savRes.value.opportunities);
      })
      .finally(() => setLoading(false));
  }, []);

  const profileFields = [
    profile?.country,
    profile?.nationality,
    profile?.age,
    profile?.education_level,
    profile?.institution,
    profile?.gpa,
    profile?.english_proficiency,
  ];
  const completedCount = profileFields.filter(Boolean).length;
  const profilePercent = Math.round((completedCount / profileFields.length) * 100);

  const upcomingDeadlines = applications
    .filter((a) => Date.parse(a.deadline) >= Date.now() - 86400000)
    .slice(0, 4);

  const statusChartData = ['PREPARING', 'RESEARCHING', 'SUBMITTED', 'ACCEPTED', 'INTERVIEW'].map(
    (st) => ({
      status: st,
      count: applications.filter((a) => a.status === st).length,
    })
  );

  return (
    <DashboardLayout title="Student Overview" breadcrumb="Dashboard">
      <div className="space-y-6">
        {/* Welcome Banner */}
        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Welcome back, {user?.name}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Profile completion: <span className="font-mono tabular-nums font-semibold">{profilePercent}%</span> ·{' '}
              {profile?.country ? `${profile.country} · ${profile.education_level}` : 'Complete your profile for deterministic eligibility checks'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <Link
              to="/dashboard/verify"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Verify Opportunity</span>
            </Link>
            <Link
              to="/dashboard/profile"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <span>Edit Profile</span>
            </Link>
          </div>
        </div>

        {/* Real User Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              label: 'Your Verification Reports',
              value: reports.length,
              to: '/dashboard/reports',
              Icon: FileSearch,
            },
            {
              label: 'Tracked Applications',
              value: applications.length,
              to: '/dashboard/applications',
              Icon: ClipboardList,
            },
            {
              label: 'Saved Opportunities',
              value: savedOpps.length,
              to: '/dashboard/saved',
              Icon: ShieldCheck,
            },
            {
              label: 'Upcoming Deadlines',
              value: upcomingDeadlines.length,
              to: '/dashboard/calendar',
              Icon: Calendar,
            },
          ].map(({ label, value, to, Icon }) => (
            <Link
              key={label}
              to={to}
              className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-500/50 transition-colors space-y-2"
            >
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                <span className="text-xs font-medium">{label}</span>
                <Icon className="w-4 h-4" />
              </div>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {loading ? '—' : value}
              </div>
            </Link>
          ))}
        </div>

        {/* Main Grid: Reports + Analytics Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Recent Verification Reports
              </h3>
              <Link
                to="/dashboard/reports"
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {reports.length === 0 ? (
              <div className="py-8 text-center space-y-3">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  No personal verification reports yet. Submit an announcement or load a demo case.
                </p>
                <Link
                  to="/dashboard/verify"
                  className="inline-flex px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold"
                >
                  Run First Verification
                </Link>
              </div>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
                {reports.slice(0, 5).map((r) => (
                  <Link
                    key={r.id}
                    to={`/dashboard/reports/${r.id}`}
                    className="p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-slate-900 dark:text-white truncate">
                        {r.opportunity_name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {r.organizer_name} · {formatLocalizedDate(r.created_at, language)}
                      </div>
                    </div>
                    <ClaimStatusTag status={r.overall_assessment} />
                  </Link>
                ))}
              </div>
            )}
          </div>

          <div className="lg:col-span-5 p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">
              Application Pipeline Breakdown
            </h3>
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={statusChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.25} />
                  <XAxis dataKey="status" tick={{ fontSize: 10 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#2563EB" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
