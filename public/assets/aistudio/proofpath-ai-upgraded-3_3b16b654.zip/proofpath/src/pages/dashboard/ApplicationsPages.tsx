import React, { useEffect, useState } from 'react';
import { Calendar as CalIcon, Plus, Trash2 } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { apiFetch } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import { APPLICATION_STATUSES, type ApplicationRecord, type ApplicationStatus } from '../../types/proofpath.ts';

export function ApplicationsPage() {
  const { language } = useAuth();
  const [apps, setApps] = useState<ApplicationRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [organizer, setOrganizer] = useState('');
  const [deadline, setDeadline] = useState('2027-04-15');
  const [notes, setNotes] = useState('');

  const load = () => {
    setLoading(true);
    apiFetch<{ applications: ApplicationRecord[] }>('/api/applications')
      .then((res) => setApps(res.applications))
      .catch(() => setApps([]))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/applications', {
      method: 'POST',
      body: JSON.stringify({
        opportunity_name: name,
        organizer,
        deadline,
        status: 'INTERESTED',
        notes,
        checklist: [
          { id: 'c1', label: 'Verify official website & fee terms', done: false },
          { id: 'c2', label: 'Complete eligibility check', done: false },
        ],
        document_checklist: [{ id: 'd1', label: 'Academic transcript / enrollment proof', done: false }],
      }),
    });
    setName('');
    setOrganizer('');
    setNotes('');
    setShowForm(false);
    load();
  };

  const updateApp = async (id: string, patch: Partial<ApplicationRecord>) => {
    await apiFetch(`/api/applications/${id}`, {
      method: 'PUT',
      body: JSON.stringify(patch),
    });
    setApps((prev) => prev.map((a) => (a.id === id ? { ...a, ...patch } : a)));
  };

  const deleteApp = async (id: string) => {
    await apiFetch(`/api/applications/${id}`, { method: 'DELETE' });
    setApps((prev) => prev.filter((a) => a.id !== id));
  };

  return (
    <DashboardLayout title="Application Tracker" breadcrumb="Applications">
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Track status, checklists, documents, interview dates, and reminders across every opportunity.
          </p>
          <button
            type="button"
            onClick={() => setShowForm(!showForm)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Application</span>
          </button>
        </div>

        {showForm && (
          <form
            onSubmit={handleCreate}
            className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 grid grid-cols-1 md:grid-cols-4 gap-3"
          >
            <input
              type="text"
              required
              placeholder="Opportunity Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
            />
            <input
              type="text"
              required
              placeholder="Organizer"
              value={organizer}
              onChange={(e) => setOrganizer(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
            />
            <input
              type="date"
              required
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
            />
            <button
              type="submit"
              className="rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold px-4 py-2"
            >
              Save Record
            </button>
            <input
              type="text"
              placeholder="Notes (optional)"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="md:col-span-4 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
            />
          </form>
        )}

        {loading ? (
          <div className="h-48 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 animate-pulse" />
        ) : apps.length === 0 ? (
          <div className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center text-sm text-slate-500">
            No tracked applications yet. Add one above or from any opportunity page.
          </div>
        ) : (
          <div className="space-y-4">
            {apps.map((app) => (
              <div
                key={app.id}
                className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                      {app.opportunity_name}
                    </h2>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {app.organizer} · Deadline:{' '}
                      <span className="font-mono tabular-nums">
                        {formatLocalizedDate(app.deadline, language)}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <select
                      value={app.status}
                      onChange={(e) =>
                        updateApp(app.id, { status: e.target.value as ApplicationStatus })
                      }
                      aria-label="Application status"
                      className="rounded-md border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-2.5 py-1.5 text-xs font-mono"
                    >
                      {APPLICATION_STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => deleteApp(app.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500"
                      aria-label="Delete application"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <div className="font-semibold text-slate-700 dark:text-slate-300">
                      Action Checklist
                    </div>
                    {app.checklist.map((item) => (
                      <label key={item.id} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={item.done}
                          onChange={() =>
                            updateApp(app.id, {
                              checklist: app.checklist.map((c) =>
                                c.id === item.id ? { ...c, done: !c.done } : c
                              ),
                            })
                          }
                        />
                        <span className={item.done ? 'line-through text-slate-400' : ''}>
                          {item.label}
                        </span>
                      </label>
                    ))}
                  </div>
                  <div className="space-y-2">
                    <div className="font-semibold text-slate-700 dark:text-slate-300">
                      Documents & Notes
                    </div>
                    {app.document_checklist.map((doc) => (
                      <label key={doc.id} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={doc.done}
                          onChange={() =>
                            updateApp(app.id, {
                              document_checklist: app.document_checklist.map((d) =>
                                d.id === doc.id ? { ...d, done: !d.done } : d
                              ),
                            })
                          }
                        />
                        <span className={doc.done ? 'line-through text-slate-400' : ''}>
                          {doc.label}
                        </span>
                      </label>
                    ))}
                    <input
                      type="text"
                      value={app.notes}
                      onChange={(e) => updateApp(app.id, { notes: e.target.value })}
                      placeholder="Add personal notes..."
                      className="w-full rounded-md border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-2.5 py-1.5 text-xs mt-1"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

export function CalendarPage() {
  const { language } = useAuth();
  const [apps, setApps] = useState<ApplicationRecord[]>([]);

  useEffect(() => {
    apiFetch<{ applications: ApplicationRecord[] }>('/api/applications')
      .then((res) => setApps(res.applications))
      .catch(() => setApps([]));
  }, []);

  const sorted = [...apps].sort((a, b) => a.deadline.localeCompare(b.deadline));

  return (
    <DashboardLayout title="Deadline & Interview Calendar" breadcrumb="Calendar">
      <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-5">
        <div className="flex items-center gap-2">
          <CalIcon className="w-5 h-5 text-blue-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            Chronological Deadlines & Milestones
          </h2>
        </div>

        {sorted.length === 0 ? (
          <p className="text-sm text-slate-500">
            No scheduled deadlines. Add opportunities in your Application Tracker to see them here.
          </p>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
            {sorted.map((a) => (
              <div key={a.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="font-medium text-sm text-slate-900 dark:text-white">
                    {a.opportunity_name}
                  </div>
                  <div className="text-xs text-slate-500">
                    {a.organizer} · Status: {a.status}
                  </div>
                </div>
                <div className="text-xs font-mono tabular-nums text-blue-600 dark:text-blue-400">
                  Due: {formatLocalizedDate(a.deadline, language)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
