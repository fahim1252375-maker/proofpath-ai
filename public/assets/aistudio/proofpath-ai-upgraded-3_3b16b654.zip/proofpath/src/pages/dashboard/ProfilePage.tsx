import React, { useEffect, useState } from 'react';
import { CheckCircle2, Loader2 } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { apiFetch } from '../../lib/api.ts';
import type { StudentProfile } from '../../types/proofpath.ts';

export function ProfilePage() {
  const { profile, refreshProfile } = useAuth();
  const [form, setForm] = useState({
    country: '',
    nationality: '',
    age: '',
    education_level: 'Undergraduate',
    current_year: '',
    institution: '',
    gpa: '',
    academic_interests: '',
    preferred_categories: '',
    preferred_countries: '',
    english_proficiency: 'Intermediate',
    sat: '',
    ielts: '',
    toefl: '',
    financial_preference: 'free_or_funded' as StudentProfile['financial_preference'],
    mode_preference: 'any' as StudentProfile['mode_preference'],
    team_preference: 'any' as StudentProfile['team_preference'],
  });
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    setForm({
      country: profile.country || '',
      nationality: profile.nationality || '',
      age: profile.age != null ? String(profile.age) : '',
      education_level: profile.education_level || 'Undergraduate',
      current_year: profile.current_year || '',
      institution: profile.institution || '',
      gpa: profile.gpa || '',
      academic_interests: (profile.academic_interests || []).join(', '),
      preferred_categories: (profile.preferred_categories || []).join(', '),
      preferred_countries: (profile.preferred_countries || []).join(', '),
      english_proficiency: profile.english_proficiency || 'Intermediate',
      sat: profile.test_scores?.sat || '',
      ielts: profile.test_scores?.ielts || '',
      toefl: profile.test_scores?.toefl || '',
      financial_preference: profile.financial_preference || 'any',
      mode_preference: profile.mode_preference || 'any',
      team_preference: profile.team_preference || 'any',
    });
  }, [profile]);

  const splitCsv = (val: string) =>
    val
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedMsg(null);
    setError(null);
    try {
      await apiFetch('/api/profile', {
        method: 'PUT',
        body: JSON.stringify({
          country: form.country,
          nationality: form.nationality,
          age: form.age ? Number(form.age) : null,
          education_level: form.education_level,
          current_year: form.current_year,
          institution: form.institution,
          gpa: form.gpa,
          academic_interests: splitCsv(form.academic_interests),
          preferred_categories: splitCsv(form.preferred_categories),
          preferred_countries: splitCsv(form.preferred_countries),
          english_proficiency: form.english_proficiency,
          test_scores: {
            sat: form.sat || undefined,
            ielts: form.ielts || undefined,
            toefl: form.toefl || undefined,
          },
          financial_preference: form.financial_preference,
          mode_preference: form.mode_preference,
          team_preference: form.team_preference,
        }),
      });
      await refreshProfile();
      setSavedMsg('Student profile updated. Deterministic eligibility checks now use these values.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <DashboardLayout title="Student Profile & Eligibility Preferences" breadcrumb="Profile">
      <div className="max-w-4xl">
        <form
          onSubmit={handleSubmit}
          className="p-6 sm:p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6"
        >
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
              Personal & Academic Eligibility Profile
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              ProofPath never infers missing eligibility data. Keep these fields accurate for exact
              matches.
            </p>
          </div>

          {savedMsg && (
            <div className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 text-sm text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{savedMsg}</span>
            </div>
          )}
          {error && (
            <div className="p-3 rounded-lg border border-red-500/30 bg-red-500/10 text-sm text-red-700 dark:text-red-300">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Country of Residence</label>
              <input
                type="text"
                value={form.country}
                onChange={(e) => setForm({ ...form, country: e.target.value })}
                placeholder="e.g. Bangladesh"
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Nationality</label>
              <input
                type="text"
                value={form.nationality}
                onChange={(e) => setForm({ ...form, nationality: e.target.value })}
                placeholder="e.g. Bangladeshi"
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Age</label>
              <input
                type="number"
                min={10}
                max={99}
                value={form.age}
                onChange={(e) => setForm({ ...form, age: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Education Level</label>
              <select
                value={form.education_level}
                onChange={(e) => setForm({ ...form, education_level: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="High School">High School</option>
                <option value="College">College</option>
                <option value="Undergraduate">Undergraduate</option>
                <option value="Graduate">Graduate</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Current Class / Year</label>
              <input
                type="text"
                value={form.current_year}
                onChange={(e) => setForm({ ...form, current_year: e.target.value })}
                placeholder="e.g. 2nd Year"
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Institution</label>
              <input
                type="text"
                value={form.institution}
                onChange={(e) => setForm({ ...form, institution: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">GPA / Academic Score</label>
              <input
                type="text"
                value={form.gpa}
                onChange={(e) => setForm({ ...form, gpa: e.target.value })}
                placeholder="e.g. 3.75 / 4.00"
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">English Proficiency</label>
              <select
                value={form.english_proficiency}
                onChange={(e) => setForm({ ...form, english_proficiency: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="Basic">Basic</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Upper-Intermediate">Upper-Intermediate</option>
                <option value="Advanced">Advanced</option>
                <option value="Native">Native</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">SAT (optional)</label>
              <input
                type="text"
                value={form.sat}
                onChange={(e) => setForm({ ...form, sat: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">IELTS (optional)</label>
              <input
                type="text"
                value={form.ielts}
                onChange={(e) => setForm({ ...form, ielts: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">TOEFL (optional)</label>
              <input
                type="text"
                value={form.toefl}
                onChange={(e) => setForm({ ...form, toefl: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Financial Preference</label>
              <select
                value={form.financial_preference}
                onChange={(e) =>
                  setForm({
                    ...form,
                    financial_preference: e.target.value as StudentProfile['financial_preference'],
                  })
                }
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="free_or_funded">Free or Funded Only</option>
                <option value="fully_funded_only">Fully Funded Only</option>
                <option value="any">Any</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Participation Mode</label>
              <select
                value={form.mode_preference}
                onChange={(e) =>
                  setForm({
                    ...form,
                    mode_preference: e.target.value as StudentProfile['mode_preference'],
                  })
                }
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="any">Remote or In-Person</option>
                <option value="remote">Remote Only</option>
                <option value="in_person">In-Person Only</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Team Preference</label>
              <select
                value={form.team_preference}
                onChange={(e) =>
                  setForm({
                    ...form,
                    team_preference: e.target.value as StudentProfile['team_preference'],
                  })
                }
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="any">Individual or Team</option>
                <option value="individual">Individual Only</option>
                <option value="team">Team Only</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Academic Interests (comma-separated)</label>
              <input
                type="text"
                value={form.academic_interests}
                onChange={(e) => setForm({ ...form, academic_interests: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Preferred Categories</label>
              <input
                type="text"
                value={form.preferred_categories}
                onChange={(e) => setForm({ ...form, preferred_categories: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Preferred Countries</label>
              <input
                type="text"
                value={form.preferred_countries}
                onChange={(e) => setForm({ ...form, preferred_countries: e.target.value })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>{saving ? 'Saving Profile...' : 'Save Student Profile'}</span>
            </button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}
