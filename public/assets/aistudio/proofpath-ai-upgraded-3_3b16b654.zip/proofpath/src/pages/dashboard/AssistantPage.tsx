import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, MessageSquarePlus, Send } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { apiFetch } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  citations?: Array<{ title: string; id: string; type: string; url?: string }>;
  follow_ups?: string[];
}

const EXAMPLE_PROMPTS = [
  'Find free international STEM opportunities for students.',
  'Am I eligible for the Nordic Youth Climate Innovation Grant?',
  'Does Global Scholars STEM Summit require an application fee?',
  'Explain these opportunities in Bangla.',
];

export function AssistantPage() {
  const { language, geminiConfigured } = useAuth();
  const [conversations, setConversations] = useState<Array<{ id: string; title: string }>>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    apiFetch<{ conversations: Array<{ id: string; title: string }> }>('/api/assistant/conversations')
      .then((res) => setConversations(res.conversations))
      .catch(() => {});
  }, []);

  const loadConversation = async (id: string) => {
    setActiveConvId(id);
    const res = await apiFetch<{ messages: ChatMessage[] }>(`/api/assistant/conversations/${id}`);
    setMessages(res.messages);
  };

  const sendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || sending) return;
    setSending(true);
    const optimistic: ChatMessage = {
      id: `local-${Date.now()}`,
      role: 'user',
      content: textToSend,
    };
    setMessages((prev) => [...prev, optimistic]);
    setInput('');

    try {
      const res = await apiFetch<{
        conversationId: string;
        reply: string;
        citations: ChatMessage['citations'];
        followUps: string[];
      }>('/api/assistant/chat', {
        method: 'POST',
        body: JSON.stringify({
          conversationId: activeConvId,
          message: textToSend,
          language,
        }),
      });
      if (!activeConvId) {
        setActiveConvId(res.conversationId);
        setConversations((prev) => [
          { id: res.conversationId, title: textToSend.slice(0, 60) },
          ...prev,
        ]);
      }
      setMessages((prev) => [
        ...prev,
        {
          id: `ast-${Date.now()}`,
          role: 'assistant',
          content: res.reply,
          citations: res.citations,
          follow_ups: res.followUps,
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendMessage(input);
  };

  return (
    <DashboardLayout title="ProofPath AI Assistant" breadcrumb="AI Assistant">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3 h-fit">
          <button
            type="button"
            onClick={() => {
              setActiveConvId(null);
              setMessages([]);
            }}
            className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
          >
            <MessageSquarePlus className="w-3.5 h-3.5" />
            <span>New Conversation</span>
          </button>
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            History
          </div>
          <div className="space-y-1 max-h-80 overflow-y-auto">
            {conversations.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => loadConversation(c.id)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs truncate ${
                  activeConvId === c.id
                    ? 'bg-blue-600/10 text-blue-600 dark:text-blue-400 font-medium'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {c.title}
              </button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-9 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col min-h-[540px]">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
            <span>
              ProofPath AI Assistant ({language === 'bn' ? 'বাংলা / English' : 'English / বাংলা'})
            </span>
            <span className="font-mono">
              {geminiConfigured ? 'Gemini Grounded Mode' : 'DEMO MODE (Registry Grounded)'}
            </span>
          </div>

          <div className="flex-1 p-5 space-y-4 overflow-y-auto">
            {messages.length === 0 ? (
              <div className="space-y-4 py-8">
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  Ask questions about verified opportunities, application fees, documents, or
                  request explanations in Bangla. Responses cite only records present in the ProofPath
                  database.
                </p>
                <div className="flex flex-wrap gap-2">
                  {EXAMPLE_PROMPTS.map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => sendMessage(p)}
                      className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-left hover:border-blue-500"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m) => (
                <div
                  key={m.id}
                  className={`p-4 rounded-xl text-sm space-y-2 ${
                    m.role === 'user'
                      ? 'bg-blue-600 text-white ml-auto max-w-2xl'
                      : 'bg-slate-100 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 max-w-3xl'
                  }`}
                >
                  <div className="whitespace-pre-wrap leading-relaxed">{m.content}</div>
                  {m.citations && m.citations.length > 0 && (
                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-2">
                      {m.citations.map((c) => (
                        <Link
                          key={c.id}
                          to={c.type === 'opportunity' ? `/opportunities/${c.id}` : `/dashboard/reports/${c.id}`}
                          className="text-xs px-2 py-1 rounded border border-blue-500/30 text-blue-600 dark:text-blue-400 hover:underline"
                        >
                          {c.title}
                        </Link>
                      ))}
                    </div>
                  )}
                  {m.follow_ups && m.follow_ups.length > 0 && (
                    <div className="pt-2 flex flex-wrap gap-1.5">
                      {m.follow_ups.map((f) => (
                        <button
                          key={f}
                          type="button"
                          onClick={() => sendMessage(f)}
                          className="text-xs px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-700 hover:border-blue-500"
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          <form
            onSubmit={handleSubmit}
            className="p-4 border-t border-slate-200 dark:border-slate-800 flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                language === 'bn'
                  ? 'বৃত্তি, ফি বা যোগ্যতা সম্পর্কে প্রশ্ন করুন...'
                  : 'Ask about scholarships, application fees, documents, or eligibility...'
              }
              className="flex-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
            />
            <button
              type="submit"
              disabled={sending}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold"
            >
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span>Send</span>
            </button>
          </form>
        </div>
      </div>
    </DashboardLayout>
  );
}
