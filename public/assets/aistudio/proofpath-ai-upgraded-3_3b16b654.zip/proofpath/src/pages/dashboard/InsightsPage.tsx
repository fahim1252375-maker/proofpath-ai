import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Bookmark, CalendarClock, Check, Circle, Sparkles, Download, FileSearch, ShieldCheck, TriangleAlert } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { Skeleton, StatCard, useToast } from '../../components/ui.tsx';
import { apiFetch } from '../../lib/api.ts';

interface Match { id: string; name: string; organizer: string; category: string; country: string; deadline: string; funding: string; evidence_status: string; score: number; reasons: string[] }
interface Insights {
  profileComplete: boolean;
  totals: { reports: number; applications: number; saved: number; flagged: number; trustRate: number | null };
  assessments: { name: string; value: number }[];
  pipeline: { name: string; value: number }[];
  trend: { month: string; reports: number; applications: number }[];
  upcoming: { id: string; opportunity_name: string; organizer: string; deadline: string; status: string }[];
}

const COLORS: Record<string, string> = {
  VERIFIED: '#10b981', SUPPORTED: '#3b82f6', CONTRADICTED: '#ef4444',
  UNVERIFIED: '#f59e0b', INSUFFICIENT_EVIDENCE: '#94a3b8', EXPIRED: '#a855f7',
};

function daysLeft(date: string): number {
  return Math.ceil((new Date(date).getTime() - Date.now()) / 86400000);
}

export function InsightsPage() {
  const toast = useToast();
  const [data, setData] = useState<Insights | null>(null);
  const [matches, setMatches] = useState<{ needsProfile: boolean; matches: Match[] } | null>(null);

  useEffect(() => {
    apiFetch<Insights>('/api/insights')
      .then(setData)
      .catch((e: Error) => toast(e.message || 'Could not load insights.', 'error'));
  }, [toast]);

  useEffect(() => {
    apiFetch<{ needsProfile: boolean; matches: Match[] }>('/api/insights/matches').then(setMatches).catch(() => setMatches({ needsProfile: false, matches: [] }));
    apiFetch<{ created: number }>('/api/insights/reminders/sync', { method: 'POST' })
      .then((r) => { if (r.created > 0) toast(`${r.created} deadline reminder${r.created > 1 ? 's' : ''} added to notifications.`, 'info'); })
      .catch(() => {});
  }, [toast]);

  const exportCsv = () => {
    window.location.href = '/api/insights/export';
    toast('Preparing your applications CSV…', 'info');
  };

  return (
    <DashboardLayout title="Insights" breadcrumb="Analytics">
      <div className="space-y-6 pp-fade-up">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold"><span className="pp-gradient-text">Your opportunity intelligence</span></h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">Live summary of your verifications, applications and deadlines.</p>
          </div>
          <button type="button" onClick={exportCsv} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800">
            <Download className="w-4 h-4" /> Export applications (CSV)
          </button>
        </div>

        {!data ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28" />)}
            <Skeleton className="h-72 lg:col-span-2" /><Skeleton className="h-72 lg:col-span-2" />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard label="Reports verified" value={data.totals.reports} Icon={FileSearch} />
              <StatCard label="Trust rate" value={data.totals.trustRate === null ? '—' : `${data.totals.trustRate}%`} hint="Verified or supported" Icon={ShieldCheck} accent="emerald" />
              <StatCard label="Flagged / expired" value={data.totals.flagged} Icon={TriangleAlert} accent="rose" />
              <StatCard label="Saved opportunities" value={data.totals.saved} hint={`${data.totals.applications} applications tracked`} Icon={Bookmark} accent="amber" />
            </div>

            <div className="pp-card p-5">
              <h3 className="font-display font-semibold mb-3">Getting started</h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { done: data.profileComplete, label: 'Complete your profile', to: '/dashboard/profile' },
                  { done: data.totals.reports > 0, label: 'Verify an opportunity', to: '/dashboard/verify' },
                  { done: data.totals.saved > 0, label: 'Save an opportunity', to: '/dashboard/opportunities' },
                  { done: data.totals.applications > 0, label: 'Track an application', to: '/dashboard/applications' },
                ].map((c) => (
                  <li key={c.label}>
                    <Link to={c.to} className="flex items-center gap-2 text-sm px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
                      {c.done ? <Check className="w-4 h-4 text-emerald-500" /> : <Circle className="w-4 h-4 text-slate-400" />}
                      <span className={c.done ? 'line-through text-slate-400' : ''}>{c.label}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pp-card p-5">
              <h3 className="font-display font-semibold mb-1 flex items-center gap-2"><Sparkles className="w-4 h-4 text-amber-500" /> Smart matches for you</h3>
              <p className="text-xs text-slate-500 mb-3">Ranked from your profile. Each match shows exactly why it was suggested.</p>
              {!matches ? <Skeleton className="h-24" /> : matches.needsProfile ? (
                <p className="text-sm text-slate-500"><Link to="/dashboard/profile" className="text-blue-500 underline">Complete your profile</Link> to get personalised matches.</p>
              ) : matches.matches.length === 0 ? (
                <p className="text-sm text-slate-500">No matches yet. Try adding more preferred categories to your profile.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  {matches.matches.map((m) => (
                    <Link key={m.id} to={`/opportunities/${m.id}`} className="pp-card p-4 block space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-semibold leading-snug">{m.name}</p>
                        <span className="text-[11px] font-mono tabular-nums px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-500">{m.score}</span>
                      </div>
                      <p className="text-xs text-slate-500">{m.organizer} · {m.country} · closes {m.deadline}</p>
                      <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-0.5">
                        {m.reasons.slice(0, 3).map((r) => <li key={r}>• {r}</li>)}
                      </ul>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="pp-card p-5 lg:col-span-2">
                <h3 className="font-display font-semibold mb-3">Activity (last 6 months)</h3>
                <div className="h-64" role="img" aria-label="Area chart of reports and applications per month">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data.trend}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#94a3b833" />
                      <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Area type="monotone" dataKey="reports" stroke="#3b82f6" fill="#3b82f633" name="Reports" />
                      <Area type="monotone" dataKey="applications" stroke="#8b5cf6" fill="#8b5cf633" name="Applications" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="pp-card p-5">
                <h3 className="font-display font-semibold mb-3">Verification outcomes</h3>
                {data.assessments.length === 0 ? (
                  <p className="text-sm text-slate-500">No reports yet. <Link to="/dashboard/verify" className="text-blue-500 underline">Verify your first opportunity</Link>.</p>
                ) : (
                  <div className="h-64" role="img" aria-label="Donut chart of verification outcomes">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={data.assessments} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3}>
                          {data.assessments.map((a) => <Cell key={a.name} fill={COLORS[a.name] ?? '#64748b'} />)}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="pp-card p-5">
                <h3 className="font-display font-semibold mb-3">Application pipeline</h3>
                {data.pipeline.length === 0 ? (
                  <p className="text-sm text-slate-500">No applications tracked yet.</p>
                ) : (
                  <div className="h-60" role="img" aria-label="Bar chart of applications by stage">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={data.pipeline} layout="vertical" margin={{ left: 30 }}>
                        <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                        <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={110} />
                        <Tooltip />
                        <Bar dataKey="value" fill="#6366f1" radius={[0, 6, 6, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>
              <div className="pp-card p-5">
                <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><CalendarClock className="w-4 h-4" /> Upcoming deadlines</h3>
                {data.upcoming.length === 0 ? (
                  <p className="text-sm text-slate-500">No upcoming deadlines.</p>
                ) : (
                  <ul className="divide-y divide-slate-200 dark:divide-slate-800">
                    {data.upcoming.map((u) => {
                      const d = daysLeft(u.deadline);
                      return (
                        <li key={u.id} className="py-2.5 flex items-center justify-between gap-3">
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{u.opportunity_name}</p>
                            <p className="text-xs text-slate-500 truncate">{u.organizer} · {u.status}</p>
                          </div>
                          <span className={`text-xs font-semibold tabular-nums px-2 py-1 rounded-md ${d <= 7 ? 'bg-rose-500/15 text-rose-500' : 'bg-blue-500/15 text-blue-500'}`}>
                            {d <= 0 ? 'Today' : `${d}d left`}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
