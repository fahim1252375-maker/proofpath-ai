import React, { useEffect, useState } from 'react';
import { Bell, Download, ShieldAlert, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { DashboardLayout } from '../../components/DashboardLayout.tsx';
import { apiFetch } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { formatLocalizedDate } from '../../i18n/translations.ts';
import {
  COMMUNITY_REPORT_CATEGORIES,
  type CommunityReport,
  type CommunityReportCategory,
  type NotificationItem,
} from '../../types/proofpath.ts';

export function CommunityPage() {
  const { language } = useAuth();
  const [approvedReports, setApprovedReports] = useState<CommunityReport[]>([]);
  const [myReports, setMyReports] = useState<CommunityReport[]>([]);
  const [oppName, setOppName] = useState('');
  const [targetUrl, setTargetUrl] = useState('');
  const [category, setCategory] = useState<CommunityReportCategory>('Suspicious fee');
  const [description, setDescription] = useState('');
  const [evidenceNotes, setEvidenceNotes] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const load = () => {
    apiFetch<{ reports: CommunityReport[] }>('/api/community/reports')
      .then((res) => setApprovedReports(res.reports))
      .catch(() => {});
    apiFetch<{ reports: CommunityReport[] }>('/api/community/reports?mine=true')
      .then((res) => setMyReports(res.reports))
      .catch(() => {});
  };

  useEffect(() => {
    load();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await apiFetch<{ message: string }>('/api/community/reports', {
      method: 'POST',
      body: JSON.stringify({
        opportunity_name: oppName,
        target_url: targetUrl,
        category,
        description,
        evidence_notes: evidenceNotes,
        is_anonymous: isAnonymous,
      }),
    });
    setFeedback(res.message);
    setOppName('');
    setTargetUrl('');
    setDescription('');
    setEvidenceNotes('');
    load();
  };

  return (
    <DashboardLayout title="Community Intelligence & Reporting" breadcrumb="Community">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-5 p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 h-fit"
        >
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">
              Submit Opportunity Report
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Submitted reports go to human moderation review first. Unreviewed accusations are never
            published automatically.
          </p>

          {feedback && (
            <div className="p-3 rounded-lg border border-blue-500/30 bg-blue-500/10 text-xs text-blue-700 dark:text-blue-300">
              {feedback}
            </div>
          )}

          <input
            type="text"
            required
            placeholder="Opportunity Name"
            value={oppName}
            onChange={(e) => setOppName(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
          />
          <input
            type="url"
            placeholder="Suspicious or Official URL (optional)"
            value={targetUrl}
            onChange={(e) => setTargetUrl(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as CommunityReportCategory)}
            className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
          >
            {COMMUNITY_REPORT_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <textarea
            rows={3}
            required
            minLength={10}
            placeholder="Describe the discrepancy, outdated deadline, or warning indicator..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
          />
          <textarea
            rows={2}
            placeholder="Supporting evidence details..."
            value={evidenceNotes}
            onChange={(e) => setEvidenceNotes(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
          />
          <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={isAnonymous}
              onChange={(e) => setIsAnonymous(e.target.checked)}
            />
            <span>Submit anonymously</span>
          </label>
          <button
            type="submit"
            className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold"
          >
            Submit to Moderation Queue
          </button>
        </form>

        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">
              Moderator-Reviewed Community Advisories
            </h2>
            {approvedReports.length === 0 ? (
              <p className="text-sm text-slate-500">No published advisories yet.</p>
            ) : (
              <div className="space-y-3">
                {approvedReports.map((r) => (
                  <div
                    key={r.id}
                    className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs text-slate-500 font-mono">
                      <span>{r.category}</span>
                      <span>{formatLocalizedDate(r.updated_at, language)}</span>
                    </div>
                    <div className="font-semibold text-sm text-slate-900 dark:text-white">
                      {r.opportunity_name}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">{r.description}</p>
                    {r.moderator_notes && (
                      <p className="text-xs text-blue-600 dark:text-blue-400">
                        Moderator Note: {r.moderator_notes}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">
              Your Submitted Reports
            </h2>
            {myReports.length === 0 ? (
              <p className="text-sm text-slate-500">You have not submitted any reports.</p>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {myReports.map((r) => (
                  <div key={r.id} className="py-3 flex items-center justify-between gap-2 text-sm">
                    <div>
                      <div className="font-medium">{r.opportunity_name}</div>
                      <div className="text-xs text-slate-500">{r.category}</div>
                    </div>
                    <span className="text-xs font-mono uppercase px-2 py-0.5 rounded border border-slate-300 dark:border-slate-700">
                      {r.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

export function NotificationsPage() {
  const { language, refreshNotifications } = useAuth();
  const [items, setItems] = useState<NotificationItem[]>([]);

  const load = () => {
    apiFetch<{ notifications: NotificationItem[] }>('/api/notifications')
      .then((res) => setItems(res.notifications))
      .catch(() => {});
  };

  useEffect(() => {
    load();
  }, []);

  const markAllRead = async () => {
    await apiFetch('/api/notifications/read-all', { method: 'PUT' });
    setItems((prev) => prev.map((n) => ({ ...n, is_read: true })));
    await refreshNotifications();
  };

  const markRead = async (id: string) => {
    await apiFetch(`/api/notifications/${id}/read`, { method: 'PUT' });
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
    await refreshNotifications();
  };

  return (
    <DashboardLayout title="Notifications & Monitoring" breadcrumb="Notifications">
      <div className="space-y-4 max-w-4xl">
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 dark:text-slate-300">
          <span>
            Note: Automated continuous web polling requires an external background cron worker
            configuration in production.
          </span>
          <button
            type="button"
            onClick={markAllRead}
            className="font-semibold text-blue-600 dark:text-blue-400 hover:underline"
          >
            Mark all as read
          </button>
        </div>

        <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900">
          {items.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              <Bell className="w-5 h-5 mx-auto mb-2 text-slate-400" />
              No notifications yet.
            </div>
          ) : (
            items.map((n) => (
              <div
                key={n.id}
                className={`p-4 flex items-start justify-between gap-4 ${
                  !n.is_read ? 'bg-blue-600/5' : ''
                }`}
              >
                <div className="space-y-1">
                  <div className="text-sm font-semibold text-slate-900 dark:text-white">
                    {n.title}
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">{n.message}</p>
                  <div className="text-[11px] font-mono text-slate-400">
                    {formatLocalizedDate(n.created_at, language)}
                  </div>
                </div>
                {!n.is_read && (
                  <button
                    type="button"
                    onClick={() => markRead(n.id)}
                    className="text-xs font-semibold text-blue-600 dark:text-blue-400 shrink-0"
                  >
                    Mark read
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

export function SettingsPage() {
  const { user, language, setLanguage, theme, toggleTheme, logout } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState(user?.name || '');
  const [timezone, setTimezone] = useState(user?.timezone || 'UTC');
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/auth/preferences', {
      method: 'PUT',
      body: JSON.stringify({ name, timezone, preferred_language: language }),
    });
    setSavedMsg('Account settings updated.');
  };

  const handleExport = async () => {
    const data = await apiFetch('/api/auth/export-data');
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `proofpath-data-export-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDeleteAccount = async () => {
    await apiFetch('/api/auth/account', { method: 'DELETE' });
    await logout();
    navigate('/');
  };

  return (
    <DashboardLayout title="Account & Privacy Settings" breadcrumb="Settings">
      <div className="max-w-3xl space-y-6">
        <form
          onSubmit={handleSave}
          className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4"
        >
          <h2 className="text-base font-semibold">Preferences & Localization</h2>
          {savedMsg && (
            <div className="p-2.5 rounded-lg border border-emerald-500/30 bg-emerald-500/10 text-xs text-emerald-700 dark:text-emerald-300">
              {savedMsg}
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Display Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Timezone</label>
              <input
                type="text"
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Interface Language</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as 'en' | 'bn')}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="en">English (Default)</option>
                <option value="bn">বাংলা (Bangla)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Appearance</label>
              <button
                type="button"
                onClick={toggleTheme}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-3 py-2 text-sm text-left"
              >
                Current: {theme === 'dark' ? 'Dark Mode' : 'Light Mode'} (Click to switch)
              </button>
            </div>
          </div>
          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
          >
            Save Settings
          </button>
        </form>

        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
          <h2 className="text-base font-semibold">Privacy & Data Portability</h2>
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={handleExport}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Download className="w-4 h-4" />
              <span>Export My Data (JSON)</span>
            </button>
            <button
              type="button"
              onClick={handleDeleteAccount}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-red-500/40 bg-red-500/10 text-red-700 dark:text-red-300 text-xs font-semibold hover:bg-red-500/20"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete Account</span>
            </button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
