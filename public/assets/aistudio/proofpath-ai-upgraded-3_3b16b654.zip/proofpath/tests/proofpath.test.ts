import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../server.ts';
import { resetDbForTests } from '../server/db/database.ts';
import { validateOutboundUrl } from '../server/security/ssrf.ts';
import { env } from '../server/config/env.ts';

let app: Awaited<ReturnType<typeof createApp>>;
let studentAToken = '';
let studentBToken = '';
let adminToken = '';

beforeAll(async () => {
  process.env.NODE_ENV = 'test';
  process.env.PROOFPATH_DB_PATH = ':memory:';
  resetDbForTests();
  app = await createApp();
});

afterAll(() => {
  resetDbForTests();
});

describe('ProofPath AI Security, Verification & Workflow Suite', () => {
  it('registers users strictly as students and isolates authentication', async () => {
    const resA = await request(app).post('/api/auth/register').send({
      name: 'Alice Student',
      email: 'alice@example.edu',
      password: 'Password123!',
      role: 'admin', // Must be ignored by server
    });
    expect(resA.status).toBe(201);
    expect(resA.body.user.role).toBe('student');
    studentAToken = resA.body.token;

    const resB = await request(app).post('/api/auth/register').send({
      name: 'Bob Student',
      email: 'bob@example.edu',
      password: 'Password123!',
    });
    expect(resB.status).toBe(201);
    studentBToken = resB.body.token;
  });

  it('CASE F: enforces RBAC and rejects student access to /api/admin with 403', async () => {
    const forbiddenRes = await request(app)
      .get('/api/admin/analytics')
      .set('Authorization', `Bearer ${studentAToken}`);
    expect(forbiddenRes.status).toBe(403);

    const adminLogin = await request(app).post('/api/auth/login').send({
      email: env.ADMIN_EMAIL,
      password: env.ADMIN_PASSWORD,
    });
    expect(adminLogin.status).toBe(200);
    adminToken = adminLogin.body.token;

    const okAdmin = await request(app)
      .get('/api/admin/analytics')
      .set('Authorization', `Bearer ${adminToken}`);
    expect(okAdmin.status).toBe(200);
    expect(okAdmin.body.totals.opportunities).toBeGreaterThanOrEqual(5);
  });

  it('CASE A: marks opportunity SUPPORTED when announcement and official evidence align', async () => {
    const res = await request(app)
      .post('/api/verification/analyze')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        rawText:
          'Nordic Youth Climate Grant\nApplication Fee: Free ($0)\nOpen to international students.\nDeadline: 2027-03-15',
        officialEvidenceText:
          'Official Announcement: Zero application fee ($0), deadline 2027-03-15, open to international students.',
      });

    expect(res.status).toBe(201);
    expect(res.body.report.overall_assessment).toBe('SUPPORTED');
  });

  it('CASE B: marks CONTRADICTED when promo claims free but official evidence specifies a fee', async () => {
    const res = await request(app)
      .post('/api/verification/analyze')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        rawText:
          'Global Scholars Summit\n100% Free entry! Open to all countries.\nDeadline: 2027-02-10',
        officialEvidenceText:
          'Official Guidelines: Mandatory application fee: $45. Restricted to partner countries only.',
      });

    expect(res.status).toBe(201);
    expect(res.body.report.overall_assessment).toBe('CONTRADICTED');
    const feeClaim = res.body.report.claims.find(
      (c: { category: string }) => c.category === 'Application Fee'
    );
    expect(feeClaim?.status).toBe('CONTRADICTED');
  });

  it('CASE C: marks INSUFFICIENT_EVIDENCE when no official source is available', async () => {
    const res = await request(app)
      .post('/api/verification/analyze')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        rawText: 'Mystery AI Youth Prize\nWin $10,000! Apply via social form.',
      });

    expect(res.status).toBe(201);
    expect(res.body.report.overall_assessment).toBe('INSUFFICIENT_EVIDENCE');
    // Must not fabricate evidence URLs
    for (const c of res.body.report.claims) {
      expect(c.evidence_url).toBeNull();
    }
  });

  it('CASE D: marks EXPIRED when stated deadline is in the past', async () => {
    const res = await request(app)
      .post('/api/verification/analyze')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        rawText: 'Past Research Exchange\nFree entry.\nDeadline: 2024-05-01',
        officialEvidenceText: 'Official portal confirms cycle deadline 2024-05-01 and free entry.',
      });

    expect(res.status).toBe(201);
    expect(res.body.report.overall_assessment).toBe('EXPIRED');
  });

  it('CASE E: rejects SSRF URLs targeting localhost, private IPs, and cloud metadata', async () => {
    const ssrf1 = await validateOutboundUrl('http://127.0.0.1:3000/api/health');
    expect(ssrf1.valid).toBe(false);

    const ssrf2 = await validateOutboundUrl('http://169.254.169.254/latest/meta-data/');
    expect(ssrf2.valid).toBe(false);

    const ssrf3 = await validateOutboundUrl('http://10.0.0.5/internal');
    expect(ssrf3.valid).toBe(false);

    const apiBlock = await request(app)
      .post('/api/verification/analyze')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        rawText: 'Test SSRF protection',
        officialUrl: 'http://127.0.0.1:3000/api/admin/users',
      });
    expect(apiBlock.status).toBe(400);
  });

  it('rejects spoofed uploaded file magic bytes', async () => {
    const fakePng = Buffer.from('MZ_FAKE_EXECUTABLE_BYTES');
    const res = await request(app)
      .post('/api/verification/analyze-document')
      .set('Authorization', `Bearer ${studentAToken}`)
      .attach('file', fakePng, { filename: 'poster.png', contentType: 'image/png' });

    expect(res.status).toBe(400);
  });

  it('enforces strict user data isolation on verification reports and applications', async () => {
    const createReport = await request(app)
      .post('/api/verification/analyze')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({ rawText: 'Private Student A Report\nDeadline: 2027-06-01' });
    const reportId = createReport.body.report.id;

    // Student B cannot read Student A's report
    const bRead = await request(app)
      .get(`/api/verification/${reportId}`)
      .set('Authorization', `Bearer ${studentBToken}`);
    expect(bRead.status).toBe(403);

    // Application tracker ownership isolation
    const createApp = await request(app)
      .post('/api/applications')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        opportunity_name: 'Student A Tracked Scholarship',
        organizer: 'Org A',
        deadline: '2027-06-01',
      });
    expect(createApp.status).toBe(201);

    const bDeleteApp = await request(app)
      .delete(`/api/applications/${createApp.body.id}`)
      .set('Authorization', `Bearer ${studentBToken}`);
    expect(bDeleteApp.status).toBe(403);
  });

  it('evaluates student eligibility deterministically without inferring missing fields', async () => {
    // Missing profile fields -> Insufficient information / Possibly eligible
    const missingRes = await request(app)
      .post('/api/eligibility/check')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({ opportunityId: 'demo-opp-consistent' });
    expect(missingRes.status).toBe(201);
    expect(['Insufficient information', 'Possibly eligible']).toContain(
      missingRes.body.result.overall_result
    );

    // Populate complete profile -> Eligible
    await request(app)
      .put('/api/profile')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        country: 'Bangladesh',
        nationality: 'Bangladeshi',
        age: 19,
        education_level: 'Undergraduate',
        gpa: '3.8',
        english_proficiency: 'Advanced',
        financial_preference: 'free_or_funded',
      });

    const eligibleRes = await request(app)
      .post('/api/eligibility/check')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({ opportunityId: 'demo-opp-consistent' });
    expect(eligibleRes.status).toBe(201);
    expect(eligibleRes.body.result.overall_result).toBe('Eligible');
  });

  it('keeps unreviewed community reports out of public feed until moderator approval', async () => {
    const submit = await request(app)
      .post('/api/community/reports')
      .set('Authorization', `Bearer ${studentAToken}`)
      .send({
        opportunity_name: 'Unreviewed Test Program',
        category: 'Suspicious fee',
        description: 'Asking for $50 gift card upfront before interview.',
      });
    expect(submit.status).toBe(201);
    expect(submit.body.status).toBe('pending');

    const publicBefore = await request(app).get('/api/community/reports');
    expect(
      publicBefore.body.reports.some(
        (r: { opportunity_name: string }) => r.opportunity_name === 'Unreviewed Test Program'
      )
    ).toBe(false);

    // Moderator/Admin approves
    const approve = await request(app)
      .put(`/api/admin/community-reports/${submit.body.id}`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ status: 'approved', moderator_notes: 'Confirmed fee warning.' });
    expect(approve.status).toBe(200);

    const publicAfter = await request(app).get('/api/community/reports');
    expect(
      publicAfter.body.reports.some(
        (r: { opportunity_name: string }) => r.opportunity_name === 'Unreviewed Test Program'
      )
    ).toBe(true);
  });
});
