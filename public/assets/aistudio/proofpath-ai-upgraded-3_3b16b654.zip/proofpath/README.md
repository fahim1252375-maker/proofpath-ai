# ProofPath AI — Verify Before You Apply

ProofPath AI is a full-stack Student Opportunity Intelligence, Verification, and Protection Platform built with React, TypeScript, Tailwind CSS, Express, Node.js SQLite persistence, and the Google `@google/genai` SDK.

## Key Implemented Capabilities

- **Evidence-First Opportunity Verification Engine**: Extracts claims (deadline, application fee, prize/funding, eligibility, documents) and compares them against official source excerpts or SSRF-protected web snapshots. Distinguishes `VERIFIED`, `SUPPORTED`, `CONTRADICTED`, `UNVERIFIED`, `INSUFFICIENT_EVIDENCE`, and `EXPIRED`.
- **Transparent Risk Intelligence**: Evaluates structural risk signals (upfront fees, guaranteed awards, banking credential requests, missing official sources, expired deadlines) with explicit methodology and limitations rather than fabricated fraud probabilities.
- **Multimodal Document & Poster Analyzer**: Accepts PDF, PNG, JPG, WebP, and TXT uploads validated via MIME and file signature checks (never executed).
- **Deterministic Student Eligibility Matching**: Evaluates country, nationality, age, education level, GPA, English proficiency, financial preferences, and deadline validity without guessing missing profile fields.
- **Global Opportunity Discovery & Side-by-Side Comparison**: Searchable registry (seeded with explicitly labeled `DEMO DATA` covering all 5 core test scenarios) and up-to-4 comparison matrix.
- **Application Tracker & Calendar**: Full 10-stage pipeline, editable checklists, document checklists, notes, and chronological deadline view.
- **Bilingual ProofPath AI Assistant (English & Bangla)**: Context-aware Q&A grounded in database opportunities and saved user verification reports.
- **Community Intelligence & Admin Governance**: Community report submission routed to human moderation queues before public listing, RBAC-protected `/admin/*` console, AI usage logging, and audit trails.

## Architecture & Environment Configuration

Copy `.env.example` to `.env` for local runs or configure secrets in your deployment environment:

- `GEMINI_API_KEY`: Server-side Google Gemini API key. **When unset**, ProofPath AI runs in explicitly labeled **DEMO MODE** using deterministic verification logic so no external dependency crashes the app.
- `GEMINI_MODEL`: Defaults to `gemini-4-hydrogen`.
- `JWT_SECRET`: Secret for signing HTTP-only authentication cookies.
- `PROOFPATH_DB_PATH`: SQLite WAL database path (defaults to `.data/proofpath.db`).
- `MONGODB_URI`: Optional external MongoDB Atlas URI if migrating persistence in production.

## Local Development & Verification

```bash
npm install
npm run dev      # Starts Express + Vite full-stack server on port 3000
npm test         # Runs Vitest + Supertest security and verification tests
npm run lint     # TypeScript type check
npm run build    # Builds production frontend bundle
npm start        # Runs production Node server on server.ts
```

## Demo Accounts (Seeded for Testing)

- **Demo Student**: `student@proofpath.demo` / `StudentPass123!`
- **Demo Admin**: Configured via `ADMIN_EMAIL` / `ADMIN_PASSWORD` environment variables (defaults in dev config; no public admin registration exists).

## Deployment Notes & External Integrations

- **Continuous Background Monitoring**: Monitoring job architecture is built, while automated periodic background crawling requires deploying an external cron worker (e.g., Cloud Scheduler).
- **Outbound Email**: Password reset and email alerts record requests cleanly; actual email delivery requires configuring an SMTP provider in production.
- **Database**: Uses Node 22 built-in persistent `node:sqlite` out of the box for zero-setup reliability; MongoDB Atlas requires providing `MONGODB_URI` and a Mongoose adapter if desired.
