import dotenv from 'dotenv';
import crypto from 'node:crypto';

dotenv.config();

const generatedDevSecret = crypto.randomBytes(32).toString('hex');

export const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: Number(process.env.PORT || 3000),
  APP_URL: process.env.APP_URL || 'http://localhost:3000',
  GEMINI_API_KEY: process.env.GEMINI_API_KEY?.trim() || '',
  GEMINI_MODEL: process.env.GEMINI_MODEL?.trim() || 'gemini-4-hydrogen',
  JWT_SECRET: process.env.JWT_SECRET?.trim() || generatedDevSecret,
  PROOFPATH_DB_PATH:
    process.env.PROOFPATH_DB_PATH ||
    (process.env.NODE_ENV === 'test' ? ':memory:' : '.data/proofpath.db'),
  MONGODB_URI: process.env.MONGODB_URI?.trim() || '',
  ADMIN_EMAIL: process.env.ADMIN_EMAIL?.trim() || 'admin@proofpath.demo',
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD?.trim() || 'AdminPass123!',
};

if (process.env.NODE_ENV === 'production') {
  const missing: string[] = [];
  if (!process.env.JWT_SECRET?.trim() || process.env.JWT_SECRET.trim().length < 32) missing.push('JWT_SECRET (min 32 chars)');
  if (!process.env.ADMIN_PASSWORD?.trim() || process.env.ADMIN_PASSWORD.trim() === 'AdminPass123!') missing.push('ADMIN_PASSWORD (non-default)');
  if (missing.length) {
    throw new Error(`Refusing to start in production. Set: ${missing.join(', ')}`);
  }
}

export function isGeminiConfigured(): boolean {
  return Boolean(env.GEMINI_API_KEY && env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
}
