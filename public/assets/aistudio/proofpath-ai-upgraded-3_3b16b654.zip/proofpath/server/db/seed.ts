import crypto from 'node:crypto';
import { getDb } from './database.ts';
import { hashPassword } from '../security/auth.ts';
import { env } from '../config/env.ts';

export async function seedDatabase(): Promise<void> {
  const db = getDb();

  const existingOpps = db.prepare('SELECT COUNT(*) as c FROM opportunities').get() as { c: number };
  if (existingOpps.c === 0) {
    const now = new Date().toISOString();
    const demoOpps = [
      {
        id: 'demo-opp-consistent',
        name: 'Nordic Youth Climate Innovation Grant (DEMO DATA)',
        organizer: 'Nordic Environmental Youth Council (Demo Organization)',
        category: 'Innovation challenges',
        country: 'International',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. Team and individual youth innovation challenge supporting student-led climate adaptation projects with micro-grants and mentorship.',
        eligibility_summary: 'Open to international high school and undergraduate students aged 16–24.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['International'],
          excluded_countries: [],
          min_age: 16,
          max_age: 24,
          education_levels: ['High School', 'Undergraduate'],
          min_gpa: 3.0,
          english_required: 'Intermediate',
          team_allowed: true,
          individual_allowed: true,
        }),
        deadline: '2027-03-15',
        funding: 'Up to $5,000 project micro-grant',
        fees: 'Free ($0 application fee)',
        is_free: 1,
        is_fully_funded: 0,
        free_certificate: 1,
        is_paid_internship: 0,
        delivery_mode: 'remote',
        benefits: JSON.stringify([
          'Project implementation micro-grant up to $5,000',
          '8-week remote mentorship from climate researchers',
          'Verified digital completion certificate at no fee',
        ]),
        required_documents: JSON.stringify([
          '2-page project proposal',
          'Student enrollment confirmation',
          'Parental consent form (if under 18)',
        ]),
        official_website: 'https://demo-nordic-climate.example.org',
        registration_url: 'https://demo-nordic-climate.example.org/apply',
        evidence_status: 'SUPPORTED',
        source_type: 'Official organization website',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA Scenario A: Promotional claims align with official announcement text.',
            status: 'SUPPORTED',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Scenario A: Consistent supporting evidence',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
      {
        id: 'demo-opp-contradicted',
        name: 'Global Scholars STEM Summit Fellowship (DEMO DATA)',
        organizer: 'Global Scholars Exchange Initiative (Demo Organization)',
        category: 'Fellowships',
        country: 'Germany',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. Social media ads claim 100% free entry worldwide, while the official guidelines excerpt lists a $45 registration fee and restricted country list.',
        eligibility_summary: 'Official guidelines restrict eligibility to 14 partner countries and charge $45.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['Germany', 'France', 'United Kingdom', 'Canada', 'Japan', 'United States'],
          excluded_countries: [],
          min_age: 18,
          max_age: 26,
          education_levels: ['Undergraduate', 'Graduate'],
          min_gpa: 3.3,
          english_required: 'Advanced',
          team_allowed: false,
          individual_allowed: true,
        }),
        deadline: '2027-02-10',
        funding: 'Partial travel stipend for selected fellows',
        fees: '$45 mandatory application fee (contradicts promotional post)',
        is_free: 0,
        is_fully_funded: 0,
        free_certificate: 0,
        is_paid_internship: 0,
        delivery_mode: 'in_person',
        benefits: JSON.stringify(['3-day Berlin symposium access', 'Partial travel stipend']),
        required_documents: JSON.stringify(['Academic transcript', 'Statement of purpose', 'Fee receipt']),
        official_website: 'https://demo-scholars-summit.example.edu',
        registration_url: 'https://demo-scholars-summit.example.edu/fellowship',
        evidence_status: 'CONTRADICTED',
        source_type: 'Official university website',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA Scenario B: Promotional claim ("Free & all countries") contradicted by official guidelines.',
            status: 'CONTRADICTED',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Scenario B: Promotional claim contradicted by official evidence',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
      {
        id: 'demo-opp-insufficient',
        name: 'Apex Frontier AI Youth Olympiad (DEMO DATA)',
        organizer: 'Unverified Social Collective (Demo)',
        category: 'AI/ML competitions',
        country: 'International',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. Circulated as a messaging-app flyer without an institutional domain, verifiable physical address, or official competition rulebook.',
        eligibility_summary: 'States "open to school and college students", no formal rules document published.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['International'],
          min_age: 14,
          max_age: 22,
          education_levels: ['High School', 'College', 'Undergraduate'],
          team_allowed: true,
          individual_allowed: true,
        }),
        deadline: '2027-04-01',
        funding: 'Claimed $10,000 prize pool (unverified)',
        fees: 'Not stated in announcement',
        is_free: 1,
        is_fully_funded: 0,
        free_certificate: 0,
        is_paid_internship: 0,
        delivery_mode: 'remote',
        benefits: JSON.stringify(['Unverified prize pool claim']),
        required_documents: JSON.stringify(['Online Google Form submission']),
        official_website: 'https://demo-unverified-olympiad.example.net',
        registration_url: 'https://demo-unverified-olympiad.example.net/form',
        evidence_status: 'INSUFFICIENT_EVIDENCE',
        source_type: 'Community-submitted content',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA Scenario C: No independent institutional evidence available.',
            status: 'INSUFFICIENT_EVIDENCE',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Scenario C: Insufficient evidence',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
      {
        id: 'demo-opp-expired',
        name: 'Pacific Rim Undergraduate Research Exchange (DEMO DATA)',
        organizer: 'Pacific Academic Consortium (Demo)',
        category: 'Research internships',
        country: 'Japan',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. Summer undergraduate research placement whose official cycle deadline has already passed.',
        eligibility_summary: 'Undergraduate STEM students with GPA >= 3.4; application cycle closed.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['International'],
          min_age: 18,
          max_age: 25,
          education_levels: ['Undergraduate'],
          min_gpa: 3.4,
          english_required: 'Upper-Intermediate',
          team_allowed: false,
          individual_allowed: true,
        }),
        deadline: '2025-11-30',
        funding: 'Fully funded housing and monthly stipend',
        fees: 'Free ($0)',
        is_free: 1,
        is_fully_funded: 1,
        free_certificate: 1,
        is_paid_internship: 1,
        delivery_mode: 'in_person',
        benefits: JSON.stringify(['Return airfare', 'University dorm housing', 'Monthly living stipend']),
        required_documents: JSON.stringify(['Official transcript', 'Two faculty references', 'CV']),
        official_website: 'https://demo-pacific-research.example.edu',
        registration_url: 'https://demo-pacific-research.example.edu/apply',
        evidence_status: 'EXPIRED',
        source_type: 'Official university website',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA Scenario D: Deadline 2025-11-30 has passed.',
            status: 'EXPIRED',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Scenario D: Expired deadline',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
      {
        id: 'demo-opp-fraud',
        name: 'Guaranteed International Merit Grant Award (DEMO DATA)',
        organizer: 'Global EduFund Authority (Impersonation Demo)',
        category: 'Scholarships',
        country: 'United States',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. Simulated high-risk scam pattern featuring guaranteed $15,000 payouts, urgency countdowns, and a $35 certificate processing fee.',
        eligibility_summary: 'Claims everyone who pays the processing fee receives a guaranteed award.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['International'],
          education_levels: ['High School', 'College', 'Undergraduate'],
          team_allowed: false,
          individual_allowed: true,
        }),
        deadline: '2027-01-20',
        funding: 'Claims guaranteed $15,000 scholarship',
        fees: '$35 urgent certificate processing fee via wire/gift card',
        is_free: 0,
        is_fully_funded: 0,
        free_certificate: 0,
        is_paid_internship: 0,
        delivery_mode: 'remote',
        benefits: JSON.stringify(['Unverified guaranteed cash payout claim']),
        required_documents: JSON.stringify(['Passport scan', 'Bank routing number', '$35 processing fee']),
        official_website: 'https://demo-edufund-merit-claim.example.org',
        registration_url: 'https://demo-edufund-merit-claim.example.org/pay-fee',
        evidence_status: 'CONTRADICTED',
        source_type: 'Unknown source',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA Scenario E: Multiple critical fraud indicators (upfront fee, guaranteed payout, banking info request).',
            status: 'CONTRADICTED',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Scenario E: Suspicious payment and fraud indicators',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
      {
        id: 'demo-opp-opensource',
        name: 'Open Civic Security Remote Internship (DEMO DATA)',
        organizer: 'CivicTech Foundation (Demo Organization)',
        category: 'Remote internships',
        country: 'International',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. 12-week paid remote internship auditing open-source educational software for accessibility and web security.',
        eligibility_summary: 'Undergraduate or college students globally with basic TypeScript or Python experience.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['International'],
          min_age: 18,
          max_age: 28,
          education_levels: ['College', 'Undergraduate', 'Graduate'],
          english_required: 'Intermediate',
          team_allowed: false,
          individual_allowed: true,
        }),
        deadline: '2027-05-01',
        funding: '$1,800/month remote stipend',
        fees: 'Free ($0)',
        is_free: 1,
        is_fully_funded: 0,
        free_certificate: 1,
        is_paid_internship: 1,
        delivery_mode: 'remote',
        benefits: JSON.stringify(['$1,800 monthly stipend', '1-on-1 security mentor', 'Public portfolio project']),
        required_documents: JSON.stringify(['GitHub or code sample', 'Short technical essay']),
        official_website: 'https://demo-civictech.example.org',
        registration_url: 'https://demo-civictech.example.org/internships',
        evidence_status: 'VERIFIED',
        source_type: 'Official organization website',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA: Stipend and zero-fee policy confirmed in demo registry.',
            status: 'VERIFIED',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Additional Demo Listing: Paid Remote Internship',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
      {
        id: 'demo-opp-hackathon',
        name: 'Global Student Humanitarian Hackathon (DEMO DATA)',
        organizer: 'University Alliance for Good (Demo)',
        category: 'Hackathons',
        country: 'International',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. 48-hour online hackathon building accessible tools for disaster preparedness and rural education.',
        eligibility_summary: 'High school and university teams of 2–4 students worldwide.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['International'],
          min_age: 15,
          max_age: 25,
          education_levels: ['High School', 'College', 'Undergraduate'],
          team_allowed: true,
          individual_allowed: false,
        }),
        deadline: '2027-02-28',
        funding: '$12,000 total prize pool across 4 tracks',
        fees: 'Free ($0)',
        is_free: 1,
        is_fully_funded: 0,
        free_certificate: 1,
        is_paid_internship: 0,
        delivery_mode: 'remote',
        benefits: JSON.stringify(['Track prizes', 'Free participation certificate', 'Cloud compute credits']),
        required_documents: JSON.stringify(['Team registration', 'Git repository & 3-min demo video']),
        official_website: 'https://demo-humanitarian-hack.example.edu',
        registration_url: 'https://demo-humanitarian-hack.example.edu/register',
        evidence_status: 'SUPPORTED',
        source_type: 'Official university website',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA: Free entry and team requirements aligned.',
            status: 'SUPPORTED',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Additional Demo Listing: International Hackathon',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
      {
        id: 'demo-opp-course',
        name: 'Applied Data Ethics & AI Literacy Certificate (DEMO DATA)',
        organizer: 'Open Learning Consortium (Demo)',
        category: 'Free courses',
        country: 'International',
        description:
          'DEMO DATA — FOR TESTING AND PRESENTATION ONLY. Self-paced 6-week introductory course on responsible AI evaluation with a verified free completion certificate.',
        eligibility_summary: 'Open worldwide to all high school and university learners.',
        eligibility_rules: JSON.stringify({
          allowed_countries: ['International'],
          min_age: 14,
          max_age: 99,
          education_levels: ['High School', 'College', 'Undergraduate', 'Graduate'],
          english_required: 'Basic',
          team_allowed: false,
          individual_allowed: true,
        }),
        deadline: '2027-08-30',
        funding: '100% Tuition & Certificate Waived',
        fees: 'Free ($0)',
        is_free: 1,
        is_fully_funded: 1,
        free_certificate: 1,
        is_paid_internship: 0,
        delivery_mode: 'remote',
        benefits: JSON.stringify(['Free downloadable certificate', 'Open-access syllabus']),
        required_documents: JSON.stringify(['Email registration only']),
        official_website: 'https://demo-openlearning.example.org',
        registration_url: 'https://demo-openlearning.example.org/ai-ethics',
        evidence_status: 'VERIFIED',
        source_type: 'Official organization website',
        verification_history: JSON.stringify([
          {
            date: now,
            note: 'DEMO DATA: Zero-cost certificate verified.',
            status: 'VERIFIED',
          },
        ]),
        is_demo: 1,
        demo_scenario: 'Additional Demo Listing: Free Certificate Course',
        last_checked_at: now,
        created_at: now,
        updated_at: now,
      },
    ];

    const insertOpp = db.prepare(`
      INSERT INTO opportunities (
        id, name, organizer, category, country, description, eligibility_summary,
        eligibility_rules, deadline, funding, fees, is_free, is_fully_funded,
        free_certificate, is_paid_internship, delivery_mode, benefits, required_documents,
        official_website, registration_url, evidence_status, source_type,
        verification_history, is_demo, demo_scenario, last_checked_at, created_at, updated_at
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      )
    `);

    for (const o of demoOpps) {
      insertOpp.run(
        o.id,
        o.name,
        o.organizer,
        o.category,
        o.country,
        o.description,
        o.eligibility_summary,
        o.eligibility_rules,
        o.deadline,
        o.funding,
        o.fees,
        o.is_free,
        o.is_fully_funded,
        o.free_certificate,
        o.is_paid_internship,
        o.delivery_mode,
        o.benefits,
        o.required_documents,
        o.official_website,
        o.registration_url,
        o.evidence_status,
        o.source_type,
        o.verification_history,
        o.is_demo,
        o.demo_scenario,
        o.last_checked_at,
        o.created_at,
        o.updated_at
      );
    }
  }

  const existingSources = db.prepare('SELECT COUNT(*) as c FROM evidence_sources').get() as { c: number };
  if (existingSources.c === 0) {
    const now = new Date().toISOString();
    const sources = [
      {
        id: 'src-nordic',
        domain: 'demo-nordic-climate.example.org',
        organization_name: 'Nordic Environmental Youth Council (Demo)',
        source_type: 'Official organization website',
        reliability_explanation: 'Demo registry entry representing an established non-profit climate education body.',
        official_website: 'https://demo-nordic-climate.example.org',
        verified_by_admin: 1,
      },
      {
        id: 'src-scholars',
        domain: 'demo-scholars-summit.example.edu',
        organization_name: 'Global Scholars Exchange Initiative (Demo)',
        source_type: 'Official university website',
        reliability_explanation: 'Demo academic portal publishing official fee and country eligibility schedules.',
        official_website: 'https://demo-scholars-summit.example.edu',
        verified_by_admin: 1,
      },
      {
        id: 'src-civictech',
        domain: 'demo-civictech.example.org',
        organization_name: 'CivicTech Foundation (Demo)',
        source_type: 'Official organization website',
        reliability_explanation: 'Demo verified non-profit internship host with transparent stipend terms.',
        official_website: 'https://demo-civictech.example.org',
        verified_by_admin: 1,
      },
    ];
    const insertSrc = db.prepare(`
      INSERT INTO evidence_sources (id, domain, organization_name, source_type, reliability_explanation, official_website, verified_by_admin, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const s of sources) {
      insertSrc.run(
        s.id,
        s.domain,
        s.organization_name,
        s.source_type,
        s.reliability_explanation,
        s.official_website,
        s.verified_by_admin,
        now
      );
    }
  }

  // Seed demo student & admin accounts if missing
  const demoStudent = db.prepare('SELECT id FROM users WHERE email = ?').get('student@proofpath.demo');
  if (!demoStudent) {
    const studentId = 'user-demo-student';
    const now = new Date().toISOString();
    const passHash = await hashPassword('StudentPass123!');
    db.prepare(`
      INSERT INTO users (id, email, name, password_hash, role, status, preferred_language, timezone, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'student', 'active', 'en', 'Asia/Dhaka', ?, ?)
    `).run(studentId, 'student@proofpath.demo', 'Nadia Rahman (Demo Student)', passHash, now, now);

    db.prepare(`
      INSERT INTO student_profiles (
        user_id, country, nationality, age, education_level, current_year, institution, gpa,
        academic_interests, preferred_categories, preferred_countries, english_proficiency,
        test_scores, financial_preference, mode_preference, team_preference, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      studentId,
      'Bangladesh',
      'Bangladeshi',
      19,
      'Undergraduate',
      '2nd Year',
      'Dhaka Institute of Science & Technology (Demo)',
      '3.75 / 4.00',
      JSON.stringify(['Artificial Intelligence', 'Climate Technology', 'Mathematics']),
      JSON.stringify(['Scholarships', 'Remote internships', 'Hackathons']),
      JSON.stringify(['International', 'Germany', 'Japan']),
      'Advanced',
      JSON.stringify({ ielts: '7.5', sat: '1420' }),
      'free_or_funded',
      'any',
      'any',
      now
    );

    db.prepare(`
      INSERT INTO applications (
        id, user_id, opportunity_id, opportunity_name, organizer, deadline, status,
        checklist, document_checklist, notes, reminder_enabled, updated_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `).run(
      'app-demo-1',
      studentId,
      'demo-opp-consistent',
      'Nordic Youth Climate Innovation Grant (DEMO DATA)',
      'Nordic Environmental Youth Council (Demo Organization)',
      '2027-03-15',
      'PREPARING',
      JSON.stringify([
        { id: 'c1', label: 'Verify official registration domain', done: true },
        { id: 'c2', label: 'Draft 2-page climate adaptation proposal', done: false },
      ]),
      JSON.stringify([
        { id: 'd1', label: 'University enrollment certificate', done: true },
        { id: 'd2', label: 'Project budget breakdown', done: false },
      ]),
      'Demo tracked application: confirmed $0 application fee in official announcement.',
      now,
      now
    );

    db.prepare(`
      INSERT INTO notifications (id, user_id, type, title, message, link, is_read, created_at)
      VALUES (?, ?, 'verification', ?, ?, ?, 0, ?)
    `).run(
      'notif-demo-1',
      studentId,
      'Welcome to ProofPath AI (Demo Account)',
      'Your student profile is configured for eligibility checks. Note: Marketplace listings labeled DEMO DATA are for testing and demonstration.',
      '/dashboard/verify',
      now
    );
  }

  const existingAdmin = db.prepare('SELECT id FROM users WHERE email = ?').get(env.ADMIN_EMAIL);
  if (!existingAdmin) {
    const now = new Date().toISOString();
    const adminHash = await hashPassword(env.ADMIN_PASSWORD);
    db.prepare(`
      INSERT INTO users (id, email, name, password_hash, role, status, preferred_language, timezone, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'admin', 'active', 'en', 'UTC', ?, ?)
    `).run(
      `user-admin-${crypto.randomBytes(4).toString('hex')}`,
      env.ADMIN_EMAIL,
      'ProofPath Trust & Safety Admin',
      adminHash,
      now,
      now
    );
  }

  const existingCommunity = db.prepare('SELECT COUNT(*) as c FROM community_reports').get() as { c: number };
  if (existingCommunity.c === 0) {
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO community_reports (
        id, user_id, is_anonymous, opportunity_id, opportunity_name, target_url,
        category, description, evidence_notes, status, moderator_notes, created_at, updated_at
      ) VALUES (?, ?, 0, ?, ?, ?, ?, ?, ?, 'approved', ?, ?, ?)
    `).run(
      'comm-demo-1',
      'user-demo-student',
      'demo-opp-contradicted',
      'Global Scholars STEM Summit Fellowship (DEMO DATA)',
      'https://demo-scholars-summit.example.edu/fellowship',
      'Suspicious fee',
      'DEMO DATA: Instagram ad promoted zero entry fee, while official application portal requests $45 before submitting.',
      'Observed fee discrepancy on page 2 of official PDF guidelines.',
      'Moderator verified demo fee discrepancy and flagged listing as CONTRADICTED.',
      now,
      now
    );
  }
}
