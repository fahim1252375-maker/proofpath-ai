import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { env } from '../config/env.ts';

let dbInstance: DatabaseSync | null = null;

export function getDb(): DatabaseSync {
  if (dbInstance) return dbInstance;

  if (env.PROOFPATH_DB_PATH !== ':memory:') {
    const dir = path.dirname(env.PROOFPATH_DB_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new DatabaseSync(env.PROOFPATH_DB_PATH);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  initSchema(db);
  dbInstance = db;
  return db;
}

export function resetDbForTests(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}

function initSchema(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student',
      status TEXT NOT NULL DEFAULT 'active',
      preferred_language TEXT NOT NULL DEFAULT 'en',
      timezone TEXT NOT NULL DEFAULT 'UTC',
      notification_prefs TEXT NOT NULL DEFAULT '{"deadlines":true,"verificationUpdates":true,"weeklySummary":false}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      deleted_at TEXT
    );

    CREATE TABLE IF NOT EXISTS student_profiles (
      user_id TEXT PRIMARY KEY,
      country TEXT NOT NULL DEFAULT '',
      nationality TEXT NOT NULL DEFAULT '',
      age INTEGER,
      education_level TEXT NOT NULL DEFAULT '',
      current_year TEXT NOT NULL DEFAULT '',
      institution TEXT NOT NULL DEFAULT '',
      gpa TEXT NOT NULL DEFAULT '',
      academic_interests TEXT NOT NULL DEFAULT '[]',
      preferred_categories TEXT NOT NULL DEFAULT '[]',
      preferred_countries TEXT NOT NULL DEFAULT '[]',
      english_proficiency TEXT NOT NULL DEFAULT '',
      test_scores TEXT NOT NULL DEFAULT '{}',
      financial_preference TEXT NOT NULL DEFAULT 'any',
      mode_preference TEXT NOT NULL DEFAULT 'any',
      team_preference TEXT NOT NULL DEFAULT 'any',
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS opportunities (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      organizer TEXT NOT NULL,
      category TEXT NOT NULL,
      country TEXT NOT NULL,
      description TEXT NOT NULL,
      eligibility_summary TEXT NOT NULL,
      eligibility_rules TEXT NOT NULL DEFAULT '{}',
      deadline TEXT NOT NULL,
      funding TEXT NOT NULL,
      fees TEXT NOT NULL,
      is_free INTEGER NOT NULL DEFAULT 1,
      is_fully_funded INTEGER NOT NULL DEFAULT 0,
      free_certificate INTEGER NOT NULL DEFAULT 0,
      is_paid_internship INTEGER NOT NULL DEFAULT 0,
      delivery_mode TEXT NOT NULL DEFAULT 'remote',
      benefits TEXT NOT NULL DEFAULT '[]',
      required_documents TEXT NOT NULL DEFAULT '[]',
      official_website TEXT NOT NULL,
      registration_url TEXT NOT NULL,
      evidence_status TEXT NOT NULL DEFAULT 'UNVERIFIED',
      source_type TEXT NOT NULL DEFAULT 'Unknown source',
      verification_history TEXT NOT NULL DEFAULT '[]',
      is_demo INTEGER NOT NULL DEFAULT 1,
      demo_scenario TEXT,
      last_checked_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      archived_at TEXT
    );

    CREATE TABLE IF NOT EXISTS verification_reports (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      opportunity_id TEXT,
      opportunity_name TEXT NOT NULL,
      organizer_name TEXT NOT NULL,
      category TEXT NOT NULL,
      input_type TEXT NOT NULL,
      raw_input TEXT NOT NULL,
      official_url TEXT,
      registration_url TEXT,
      overall_assessment TEXT NOT NULL,
      evidence_quality TEXT NOT NULL,
      executive_summary TEXT NOT NULL,
      extracted_metadata TEXT NOT NULL DEFAULT '{}',
      source_snapshots_json TEXT NOT NULL DEFAULT '[]',
      missing_information TEXT NOT NULL DEFAULT '[]',
      recommended_actions TEXT NOT NULL DEFAULT '[]',
      limitations TEXT NOT NULL,
      analysis_mode TEXT NOT NULL,
      model_used TEXT NOT NULL,
      is_public_share INTEGER NOT NULL DEFAULT 0,
      share_token TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS opportunity_claims (
      id TEXT PRIMARY KEY,
      report_id TEXT NOT NULL,
      opportunity_id TEXT,
      category TEXT NOT NULL,
      extracted_statement TEXT NOT NULL,
      normalized_value TEXT NOT NULL,
      source_text TEXT NOT NULL,
      status TEXT NOT NULL,
      supporting_evidence TEXT,
      contradicting_evidence TEXT,
      evidence_url TEXT,
      source_publication_date TEXT,
      confidence_explanation TEXT NOT NULL,
      last_checked_at TEXT NOT NULL,
      FOREIGN KEY (report_id) REFERENCES verification_reports(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS evidence_sources (
      id TEXT PRIMARY KEY,
      domain TEXT NOT NULL UNIQUE,
      organization_name TEXT NOT NULL,
      source_type TEXT NOT NULL,
      reliability_explanation TEXT NOT NULL,
      official_website TEXT NOT NULL,
      verified_by_admin INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS risk_assessments (
      id TEXT PRIMARY KEY,
      report_id TEXT NOT NULL UNIQUE,
      risk_category TEXT NOT NULL,
      methodology_note TEXT NOT NULL,
      factors TEXT NOT NULL DEFAULT '[]',
      indicators TEXT NOT NULL DEFAULT '[]',
      human_review_recommended INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (report_id) REFERENCES verification_reports(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS eligibility_checks (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      opportunity_id TEXT,
      report_id TEXT,
      opportunity_name TEXT NOT NULL,
      overall_result TEXT NOT NULL,
      checked_requirements TEXT NOT NULL DEFAULT '[]',
      missing_profile_fields TEXT NOT NULL DEFAULT '[]',
      recommendation_note TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS saved_opportunities (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      opportunity_id TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(user_id, opportunity_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (opportunity_id) REFERENCES opportunities(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS applications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      opportunity_id TEXT,
      opportunity_name TEXT NOT NULL,
      organizer TEXT NOT NULL,
      deadline TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'INTERESTED',
      submission_date TEXT,
      checklist TEXT NOT NULL DEFAULT '[]',
      document_checklist TEXT NOT NULL DEFAULT '[]',
      notes TEXT NOT NULL DEFAULT '',
      interview_date TEXT,
      follow_up_date TEXT,
      outcome TEXT NOT NULL DEFAULT '',
      reminder_enabled INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      link TEXT,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS community_reports (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      is_anonymous INTEGER NOT NULL DEFAULT 0,
      opportunity_id TEXT,
      opportunity_name TEXT NOT NULL,
      target_url TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      evidence_notes TEXT NOT NULL DEFAULT '',
      screenshot_data TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      duplicate_of_id TEXT,
      moderator_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS moderation_logs (
      id TEXT PRIMARY KEY,
      report_id TEXT NOT NULL,
      moderator_id TEXT NOT NULL,
      action TEXT NOT NULL,
      reason TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      details TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_usage_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      service_name TEXT NOT NULL,
      model TEXT NOT NULL,
      mode TEXT NOT NULL,
      prompt_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      latency_ms INTEGER NOT NULL DEFAULT 0,
      success INTEGER NOT NULL DEFAULT 1,
      error_message TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      language TEXT NOT NULL DEFAULT 'en',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS conversation_messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      citations TEXT NOT NULL DEFAULT '[]',
      follow_ups TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS uploaded_documents (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      report_id TEXT,
      original_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      extracted_text TEXT NOT NULL DEFAULT '',
      analysis_summary TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS source_snapshots (
      id TEXT PRIMARY KEY,
      url TEXT NOT NULL,
      domain TEXT NOT NULL,
      http_status INTEGER NOT NULL,
      content_hash TEXT NOT NULL,
      extracted_title TEXT NOT NULL DEFAULT '',
      excerpt TEXT NOT NULL DEFAULT '',
      fetched_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS monitoring_jobs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      opportunity_id TEXT NOT NULL,
      frequency TEXT NOT NULL DEFAULT 'weekly',
      enabled INTEGER NOT NULL DEFAULT 1,
      last_run_at TEXT,
      next_run_at TEXT,
      status_note TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS user_feedback (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      report_id TEXT,
      rating INTEGER NOT NULL,
      comment TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS contact_messages (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_opportunities_category ON opportunities(category);
    CREATE INDEX IF NOT EXISTS idx_opportunities_deadline ON opportunities(deadline);
    CREATE INDEX IF NOT EXISTS idx_reports_user ON verification_reports(user_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_claims_report ON opportunity_claims(report_id);
    CREATE INDEX IF NOT EXISTS idx_applications_user ON applications(user_id, deadline);
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
    CREATE INDEX IF NOT EXISTS idx_community_status ON community_reports(status, created_at);
    CREATE INDEX IF NOT EXISTS idx_ai_usage_created ON ai_usage_logs(created_at);
    CREATE INDEX IF NOT EXISTS idx_ai_usage_user ON ai_usage_logs(user_id);
    CREATE INDEX IF NOT EXISTS idx_saved_user ON saved_opportunities(user_id);
    CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_opportunities_country ON opportunities(country);
    CREATE INDEX IF NOT EXISTS idx_reports_share ON verification_reports(share_token);
    CREATE INDEX IF NOT EXISTS idx_conversations_user ON conversations(user_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_messages_conversation ON conversation_messages(conversation_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_admin_logs_created ON admin_logs(created_at);

    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
    INSERT OR IGNORE INTO schema_migrations (version, name, applied_at)
      VALUES (1, 'baseline-schema-and-indexes', datetime('now'));
  `);
}
