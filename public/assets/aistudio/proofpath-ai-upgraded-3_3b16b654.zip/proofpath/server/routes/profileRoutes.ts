import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/database.ts';
import { requireAuth, type AuthenticatedRequest } from '../security/auth.ts';

const router = Router();

const ProfileSchema = z.object({
  country: z.string().trim().max(80).default(''),
  nationality: z.string().trim().max(80).default(''),
  age: z.number().int().min(10).max(99).nullable().optional(),
  education_level: z.string().trim().max(60).default(''),
  current_year: z.string().trim().max(60).default(''),
  institution: z.string().trim().max(140).default(''),
  gpa: z.string().trim().max(40).default(''),
  academic_interests: z.array(z.string().trim().max(60)).max(20).default([]),
  preferred_categories: z.array(z.string().trim().max(60)).max(20).default([]),
  preferred_countries: z.array(z.string().trim().max(60)).max(20).default([]),
  english_proficiency: z.string().trim().max(40).default(''),
  test_scores: z
    .object({
      sat: z.string().trim().max(20).optional(),
      ielts: z.string().trim().max(20).optional(),
      toefl: z.string().trim().max(20).optional(),
    })
    .default({}),
  financial_preference: z.enum(['fully_funded_only', 'free_or_funded', 'any']).default('any'),
  mode_preference: z.enum(['remote', 'in_person', 'any']).default('any'),
  team_preference: z.enum(['individual', 'team', 'any']).default('any'),
});

export function getStudentProfileForUser(userId: string) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM student_profiles WHERE user_id = ?').get(userId) as
    | Record<string, unknown>
    | undefined;
  if (!row) return null;
  return {
    user_id: String(row.user_id),
    country: String(row.country || ''),
    nationality: String(row.nationality || ''),
    age: row.age != null ? Number(row.age) : null,
    education_level: String(row.education_level || ''),
    current_year: String(row.current_year || ''),
    institution: String(row.institution || ''),
    gpa: String(row.gpa || ''),
    academic_interests: JSON.parse(String(row.academic_interests || '[]')),
    preferred_categories: JSON.parse(String(row.preferred_categories || '[]')),
    preferred_countries: JSON.parse(String(row.preferred_countries || '[]')),
    english_proficiency: String(row.english_proficiency || ''),
    test_scores: JSON.parse(String(row.test_scores || '{}')),
    financial_preference: String(row.financial_preference || 'any') as
      | 'fully_funded_only'
      | 'free_or_funded'
      | 'any',
    mode_preference: String(row.mode_preference || 'any') as 'remote' | 'in_person' | 'any',
    team_preference: String(row.team_preference || 'any') as 'individual' | 'team' | 'any',
    updated_at: String(row.updated_at || ''),
  };
}

router.get('/', requireAuth, (req: AuthenticatedRequest, res) => {
  const profile = getStudentProfileForUser(req.user!.userId);
  res.json({ profile });
});

router.put('/', requireAuth, (req: AuthenticatedRequest, res) => {
  const parsed = ProfileSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid student profile fields.', details: parsed.error.flatten() });
    return;
  }

  const db = getDb();
  const now = new Date().toISOString();
  const d = parsed.data;
  db.prepare(`
    INSERT INTO student_profiles (
      user_id, country, nationality, age, education_level, current_year, institution, gpa,
      academic_interests, preferred_categories, preferred_countries, english_proficiency,
      test_scores, financial_preference, mode_preference, team_preference, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET
      country = excluded.country,
      nationality = excluded.nationality,
      age = excluded.age,
      education_level = excluded.education_level,
      current_year = excluded.current_year,
      institution = excluded.institution,
      gpa = excluded.gpa,
      academic_interests = excluded.academic_interests,
      preferred_categories = excluded.preferred_categories,
      preferred_countries = excluded.preferred_countries,
      english_proficiency = excluded.english_proficiency,
      test_scores = excluded.test_scores,
      financial_preference = excluded.financial_preference,
      mode_preference = excluded.mode_preference,
      team_preference = excluded.team_preference,
      updated_at = excluded.updated_at
  `).run(
    req.user!.userId,
    d.country,
    d.nationality,
    d.age ?? null,
    d.education_level,
    d.current_year,
    d.institution,
    d.gpa,
    JSON.stringify(d.academic_interests),
    JSON.stringify(d.preferred_categories),
    JSON.stringify(d.preferred_countries),
    d.english_proficiency,
    JSON.stringify(d.test_scores),
    d.financial_preference,
    d.mode_preference,
    d.team_preference,
    now
  );

  res.json({ profile: getStudentProfileForUser(req.user!.userId) });
});

export default router;
