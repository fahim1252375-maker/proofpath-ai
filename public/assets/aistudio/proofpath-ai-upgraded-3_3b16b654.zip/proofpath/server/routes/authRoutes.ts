import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { getDb } from '../db/database.ts';
import {
  clearSessionCookie,
  hashPassword,
  requireAuth,
  setSessionCookie,
  signAuthToken,
  verifyPassword,
  type AuthenticatedRequest,
} from '../security/auth.ts';

const router = Router();

const RegisterSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(160),
  password: z.string().min(8).max(128),
  preferred_language: z.enum(['en', 'bn']).optional(),
});

const LoginSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(1),
});

// Public registration NEVER allows creating admin or moderator roles.
router.post('/register', async (req, res) => {
  const parsed = RegisterSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid registration data.', details: parsed.error.flatten() });
    return;
  }

  const db = getDb();
  const email = parsed.data.email.toLowerCase();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    res.status(409).json({ error: 'An account with this email already exists.' });
    return;
  }

  const userId = `usr-${crypto.randomUUID().slice(0, 12)}`;
  const now = new Date().toISOString();
  const passwordHash = await hashPassword(parsed.data.password);
  const lang = parsed.data.preferred_language || 'en';

  db.prepare(`
    INSERT INTO users (id, email, name, password_hash, role, status, preferred_language, timezone, created_at, updated_at)
    VALUES (?, ?, ?, ?, 'student', 'active', ?, 'UTC', ?, ?)
  `).run(userId, email, parsed.data.name, passwordHash, lang, now, now);

  db.prepare(`
    INSERT INTO student_profiles (user_id, updated_at) VALUES (?, ?)
  `).run(userId, now);

  db.prepare(`
    INSERT INTO notifications (id, user_id, type, title, message, link, is_read, created_at)
    VALUES (?, ?, 'system', ?, ?, ?, 0, ?)
  `).run(
    `notif-${crypto.randomUUID().slice(0, 8)}`,
    userId,
    'Complete your student profile',
    'Add your country, education level, and preferences to run exact eligibility checks.',
    '/dashboard/profile',
    now
  );

  const token = signAuthToken({ userId, email, role: 'student' });
  setSessionCookie(res, token);

  res.status(201).json({
    token,
    user: {
      id: userId,
      email,
      name: parsed.data.name,
      role: 'student',
      status: 'active',
      preferred_language: lang,
      timezone: 'UTC',
      created_at: now,
    },
  });
});

router.post('/login', async (req, res) => {
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Valid email and password are required.' });
    return;
  }

  const db = getDb();
  const email = parsed.data.email.toLowerCase();
  const user = db
    .prepare('SELECT * FROM users WHERE email = ? AND deleted_at IS NULL')
    .get(email) as Record<string, unknown> | undefined;

  if (!user) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  if (user.status !== 'active') {
    res.status(403).json({ error: 'Account is suspended. Contact support.' });
    return;
  }

  const valid = await verifyPassword(parsed.data.password, String(user.password_hash));
  if (!valid) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  const token = signAuthToken({
    userId: String(user.id),
    email: String(user.email),
    role: String(user.role) as 'student' | 'moderator' | 'admin',
  });
  setSessionCookie(res, token);

  res.json({
    token,
    user: {
      id: String(user.id),
      email: String(user.email),
      name: String(user.name),
      role: String(user.role),
      status: String(user.status),
      preferred_language: String(user.preferred_language),
      timezone: String(user.timezone),
      created_at: String(user.created_at),
    },
  });
});

router.post('/logout', (_req, res) => {
  clearSessionCookie(res);
  res.json({ ok: true });
});

router.post('/forgot-password', (req, res) => {
  const schema = z.object({ email: z.string().trim().email() });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Please provide a valid email address.' });
    return;
  }
  // Honest disclosure: email delivery is not configured in local/preview environments
  res.json({
    ok: true,
    emailDeliveryConfigured: false,
    message:
      'Password reset request recorded. Note: Automated outbound email delivery requires an SMTP provider configuration in production.',
  });
});

router.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const user = db
    .prepare(
      'SELECT id, email, name, role, status, preferred_language, timezone, notification_prefs, created_at FROM users WHERE id = ? AND deleted_at IS NULL'
    )
    .get(req.user!.userId) as Record<string, unknown> | undefined;

  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  res.json({
    user: {
      ...user,
      notification_prefs: JSON.parse(String(user.notification_prefs || '{}')),
    },
  });
});

router.put('/preferences', requireAuth, (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    name: z.string().trim().min(2).max(80).optional(),
    preferred_language: z.enum(['en', 'bn']).optional(),
    timezone: z.string().trim().min(2).max(60).optional(),
    notification_prefs: z
      .object({
        deadlines: z.boolean(),
        verificationUpdates: z.boolean(),
        weeklySummary: z.boolean(),
      })
      .optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid preference fields.' });
    return;
  }
  const db = getDb();
  const current = db
    .prepare('SELECT name, preferred_language, timezone, notification_prefs FROM users WHERE id = ?')
    .get(req.user!.userId) as Record<string, unknown>;

  const now = new Date().toISOString();
  db.prepare(
    'UPDATE users SET name = ?, preferred_language = ?, timezone = ?, notification_prefs = ?, updated_at = ? WHERE id = ?'
  ).run(
    parsed.data.name ?? String(current.name),
    parsed.data.preferred_language ?? String(current.preferred_language),
    parsed.data.timezone ?? String(current.timezone),
    parsed.data.notification_prefs
      ? JSON.stringify(parsed.data.notification_prefs)
      : String(current.notification_prefs),
    now,
    req.user!.userId
  );

  res.json({ ok: true });
});

router.get('/export-data', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const userId = req.user!.userId;
  const user = db
    .prepare('SELECT id, email, name, role, preferred_language, timezone, created_at FROM users WHERE id = ?')
    .get(userId);
  const profile = db.prepare('SELECT * FROM student_profiles WHERE user_id = ?').get(userId);
  const reports = db.prepare('SELECT * FROM verification_reports WHERE user_id = ?').all(userId);
  const applications = db.prepare('SELECT * FROM applications WHERE user_id = ?').all(userId);
  const saved = db.prepare('SELECT * FROM saved_opportunities WHERE user_id = ?').all(userId);
  const eligibility = db.prepare('SELECT * FROM eligibility_checks WHERE user_id = ?').all(userId);

  res.json({
    exportedAt: new Date().toISOString(),
    user,
    profile,
    verificationReports: reports,
    applications,
    savedOpportunities: saved,
    eligibilityChecks: eligibility,
  });
});

router.delete('/account', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare('UPDATE users SET deleted_at = ?, status = ? WHERE id = ?').run(
    now,
    'suspended',
    req.user!.userId
  );
  clearSessionCookie(res);
  res.json({ ok: true, message: 'Account marked for deletion and session terminated.' });
});

export default router;
