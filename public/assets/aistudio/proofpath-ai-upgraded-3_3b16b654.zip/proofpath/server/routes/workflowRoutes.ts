import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { getDb } from '../db/database.ts';
import { optionalAuth, requireAuth, type AuthenticatedRequest } from '../security/auth.ts';
import { getStudentProfileForUser } from './profileRoutes.ts';
import { hydrateOpportunity } from './opportunitiesRoutes.ts';
import { evaluateDeterministicEligibility } from '../services/eligibilityService.ts';
import { runAssistantChat } from '../services/assistantService.ts';
import {
  APPLICATION_STATUSES,
  COMMUNITY_REPORT_CATEGORIES,
} from '../../src/types/proofpath.ts';

export const eligibilityRouter = Router();
export const applicationsRouter = Router();
export const assistantRouter = Router();
export const communityRouter = Router();
export const notificationsRouter = Router();
export const contactRouter = Router();

// --- ELIGIBILITY ---
eligibilityRouter.post('/check', requireAuth, (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    opportunityId: z.string().optional(),
    customOpportunity: z
      .object({
        name: z.string().min(2).max(160),
        deadline: z.string().max(40),
        is_free: z.boolean().default(true),
        is_fully_funded: z.boolean().default(false),
        delivery_mode: z.enum(['remote', 'in_person', 'hybrid']).default('remote'),
        eligibility_rules: z
          .object({
            allowed_countries: z.array(z.string()).optional(),
            min_age: z.number().nullable().optional(),
            max_age: z.number().nullable().optional(),
            education_levels: z.array(z.string()).optional(),
            min_gpa: z.number().nullable().optional(),
            english_required: z.string().nullable().optional(),
          })
          .default({}),
      })
      .optional(),
    language: z.enum(['en', 'bn']).optional(),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid eligibility check request.' });
    return;
  }

  const db = getDb();
  const profile = getStudentProfileForUser(req.user!.userId);

  if (parsed.data.opportunityId) {
    const row = db
      .prepare('SELECT * FROM opportunities WHERE id = ?')
      .get(parsed.data.opportunityId) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Opportunity not found.' });
      return;
    }
    const opp = hydrateOpportunity(row);
    const result = evaluateDeterministicEligibility({
      userId: req.user!.userId,
      profile,
      opportunity: opp,
      language: parsed.data.language || 'en',
    });
    res.status(201).json({ result });
    return;
  }

  if (parsed.data.customOpportunity) {
    const c = parsed.data.customOpportunity;
    const result = evaluateDeterministicEligibility({
      userId: req.user!.userId,
      profile,
      opportunity: {
        id: 'custom-check',
        name: c.name,
        deadline: c.deadline,
        is_free: c.is_free,
        is_fully_funded: c.is_fully_funded,
        delivery_mode: c.delivery_mode,
        eligibility_rules: c.eligibility_rules,
      },
      language: parsed.data.language || 'en',
    });
    res.status(201).json({ result });
    return;
  }

  res.status(400).json({ error: 'Provide opportunityId or customOpportunity.' });
});

eligibilityRouter.get('/history', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM eligibility_checks WHERE user_id = ? ORDER BY created_at DESC LIMIT 30')
    .all(req.user!.userId) as Array<Record<string, unknown>>;

  res.json({
    history: rows.map((r) => ({
      ...r,
      checked_requirements: JSON.parse(String(r.checked_requirements || '[]')),
      missing_profile_fields: JSON.parse(String(r.missing_profile_fields || '[]')),
    })),
  });
});

// --- APPLICATIONS ---
const AppSchema = z.object({
  opportunity_id: z.string().nullable().optional(),
  opportunity_name: z.string().trim().min(2).max(160),
  organizer: z.string().trim().min(1).max(140),
  deadline: z.string().trim().max(40),
  status: z.enum(APPLICATION_STATUSES).default('INTERESTED'),
  submission_date: z.string().nullable().optional(),
  checklist: z
    .array(z.object({ id: z.string(), label: z.string(), done: z.boolean() }))
    .default([]),
  document_checklist: z
    .array(z.object({ id: z.string(), label: z.string(), done: z.boolean() }))
    .default([]),
  notes: z.string().max(4000).default(''),
  interview_date: z.string().nullable().optional(),
  follow_up_date: z.string().nullable().optional(),
  outcome: z.string().max(400).default(''),
  reminder_enabled: z.boolean().default(true),
});

applicationsRouter.get('/', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM applications WHERE user_id = ? ORDER BY deadline ASC, updated_at DESC')
    .all(req.user!.userId) as Array<Record<string, unknown>>;

  res.json({
    applications: rows.map((r) => ({
      ...r,
      checklist: JSON.parse(String(r.checklist || '[]')),
      document_checklist: JSON.parse(String(r.document_checklist || '[]')),
      reminder_enabled: Boolean(r.reminder_enabled),
    })),
  });
});

applicationsRouter.post('/', requireAuth, (req: AuthenticatedRequest, res) => {
  const parsed = AppSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid application record.', details: parsed.error.flatten() });
    return;
  }

  const d = parsed.data;
  const id = `app-${crypto.randomUUID().slice(0, 8)}`;
  const now = new Date().toISOString();
  const db = getDb();

  db.prepare(`
    INSERT INTO applications (
      id, user_id, opportunity_id, opportunity_name, organizer, deadline, status,
      submission_date, checklist, document_checklist, notes, interview_date,
      follow_up_date, outcome, reminder_enabled, updated_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    req.user!.userId,
    d.opportunity_id ?? null,
    d.opportunity_name,
    d.organizer,
    d.deadline,
    d.status,
    d.submission_date ?? null,
    JSON.stringify(d.checklist),
    JSON.stringify(d.document_checklist),
    d.notes,
    d.interview_date ?? null,
    d.follow_up_date ?? null,
    d.outcome,
    d.reminder_enabled ? 1 : 0,
    now,
    now
  );

  res.status(201).json({ id });
});

applicationsRouter.put('/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const existing = db
    .prepare('SELECT id, user_id FROM applications WHERE id = ?')
    .get(req.params.id) as { id: string; user_id: string } | undefined;

  if (!existing) {
    res.status(404).json({ error: 'Application not found.' });
    return;
  }
  if (existing.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden.' });
    return;
  }

  const parsed = AppSchema.partial().safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid application update payload.' });
    return;
  }

  const current = db.prepare('SELECT * FROM applications WHERE id = ?').get(req.params.id) as Record<
    string,
    unknown
  >;
  const d = parsed.data;
  const now = new Date().toISOString();

  db.prepare(`
    UPDATE applications SET
      opportunity_name = ?, organizer = ?, deadline = ?, status = ?, submission_date = ?,
      checklist = ?, document_checklist = ?, notes = ?, interview_date = ?,
      follow_up_date = ?, outcome = ?, reminder_enabled = ?, updated_at = ?
    WHERE id = ? AND user_id = ?
  `).run(
    d.opportunity_name ?? String(current.opportunity_name),
    d.organizer ?? String(current.organizer),
    d.deadline ?? String(current.deadline),
    d.status ?? String(current.status),
    d.submission_date !== undefined ? d.submission_date : (current.submission_date as string | null),
    d.checklist ? JSON.stringify(d.checklist) : String(current.checklist),
    d.document_checklist ? JSON.stringify(d.document_checklist) : String(current.document_checklist),
    d.notes !== undefined ? d.notes : String(current.notes),
    d.interview_date !== undefined ? d.interview_date : (current.interview_date as string | null),
    d.follow_up_date !== undefined ? d.follow_up_date : (current.follow_up_date as string | null),
    d.outcome !== undefined ? d.outcome : String(current.outcome),
    d.reminder_enabled !== undefined ? (d.reminder_enabled ? 1 : 0) : Number(current.reminder_enabled),
    now,
    req.params.id,
    req.user!.userId
  );

  res.json({ ok: true });
});

applicationsRouter.delete('/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const existing = db
    .prepare('SELECT id, user_id FROM applications WHERE id = ?')
    .get(req.params.id) as { id: string; user_id: string } | undefined;

  if (!existing) {
    res.status(404).json({ error: 'Application not found.' });
    return;
  }
  if (existing.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden.' });
    return;
  }
  db.prepare('DELETE FROM applications WHERE id = ? AND user_id = ?').run(
    req.params.id,
    req.user!.userId
  );
  res.json({ ok: true });
});

// --- AI ASSISTANT ---
assistantRouter.post('/chat', requireAuth, async (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    conversationId: z.string().nullable().optional(),
    message: z.string().trim().min(1).max(3000),
    language: z.enum(['en', 'bn']).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Message is required.' });
    return;
  }

  try {
    const result = await runAssistantChat({
      userId: req.user!.userId,
      conversationId: parsed.data.conversationId,
      message: parsed.data.message,
      language: parsed.data.language || 'en',
    });
    res.json(result);
  } catch {
    res.status(500).json({ error: 'Assistant failed to respond.' });
  }
});

assistantRouter.get('/conversations', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 30')
    .all(req.user!.userId);
  res.json({ conversations: rows });
});

assistantRouter.get('/conversations/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const conv = db
    .prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user!.userId);
  if (!conv) {
    res.status(404).json({ error: 'Conversation not found.' });
    return;
  }
  const messages = db
    .prepare('SELECT * FROM conversation_messages WHERE conversation_id = ? ORDER BY created_at ASC')
    .all(req.params.id) as Array<Record<string, unknown>>;

  res.json({
    conversation: conv,
    messages: messages.map((m) => ({
      ...m,
      citations: JSON.parse(String(m.citations || '[]')),
      follow_ups: JSON.parse(String(m.follow_ups || '[]')),
    })),
  });
});

// --- COMMUNITY INTELLIGENCE ---
// Public only sees moderator-approved community advisories (never unreviewed accusations!)
communityRouter.get('/reports', optionalAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const mineOnly = req.query.mine === 'true';

  if (mineOnly) {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const rows = db
      .prepare('SELECT * FROM community_reports WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
      .all(req.user.userId);
    res.json({ reports: rows });
    return;
  }

  const rows = db
    .prepare(
      `SELECT id, is_anonymous, opportunity_id, opportunity_name, target_url, category,
              description, evidence_notes, status, moderator_notes, created_at, updated_at
       FROM community_reports
       WHERE status = 'approved'
       ORDER BY updated_at DESC LIMIT 50`
    )
    .all();

  res.json({ reports: rows });
});

communityRouter.post('/reports', optionalAuth, (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    opportunity_id: z.string().nullable().optional(),
    opportunity_name: z.string().trim().min(2).max(160),
    target_url: z.string().trim().max(400).optional().default(''),
    category: z.enum(COMMUNITY_REPORT_CATEGORIES),
    description: z.string().trim().min(10).max(3000),
    evidence_notes: z.string().trim().max(2000).optional().default(''),
    is_anonymous: z.boolean().optional().default(false),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Please complete all required report fields.' });
    return;
  }

  const d = parsed.data;
  const db = getDb();
  const now = new Date().toISOString();
  const id = `comm-${crypto.randomUUID().slice(0, 8)}`;

  // Simple duplicate detection by opportunity name + category
  const duplicate = db
    .prepare(
      `SELECT id FROM community_reports WHERE LOWER(opportunity_name) = ? AND category = ? LIMIT 1`
    )
    .get(d.opportunity_name.toLowerCase(), d.category) as { id: string } | undefined;

  db.prepare(`
    INSERT INTO community_reports (
      id, user_id, is_anonymous, opportunity_id, opportunity_name, target_url,
      category, description, evidence_notes, status, duplicate_of_id, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
  `).run(
    id,
    req.user?.userId ?? null,
    d.is_anonymous ? 1 : 0,
    d.opportunity_id ?? null,
    d.opportunity_name,
    d.target_url,
    d.category,
    d.description,
    d.evidence_notes,
    duplicate?.id ?? null,
    now,
    now
  );

  res.status(201).json({
    id,
    status: 'pending',
    possibleDuplicateOf: duplicate?.id ?? null,
    message:
      'Report submitted to the moderation queue. Unreviewed reports are never published publicly until verified by a moderator.',
  });
});

// --- NOTIFICATIONS ---
notificationsRouter.get('/', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(req.user!.userId) as Array<Record<string, unknown>>;

  res.json({
    notifications: rows.map((n) => ({ ...n, is_read: Boolean(n.is_read) })),
  });
});

notificationsRouter.put('/read-all', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.user!.userId);
  res.json({ ok: true });
});

notificationsRouter.put('/:id/read', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(
    req.params.id,
    req.user!.userId
  );
  res.json({ ok: true });
});

// --- CONTACT ---
contactRouter.post('/', (req, res) => {
  const schema = z.object({
    name: z.string().trim().min(2).max(100),
    email: z.string().trim().email().max(160),
    subject: z.string().trim().min(2).max(160),
    message: z.string().trim().min(10).max(3000),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Please provide a valid name, email, subject, and message.' });
    return;
  }
  const db = getDb();
  db.prepare(
    'INSERT INTO contact_messages (id, name, email, subject, message, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(
    `msg-${crypto.randomUUID().slice(0, 8)}`,
    parsed.data.name,
    parsed.data.email,
    parsed.data.subject,
    parsed.data.message,
    new Date().toISOString()
  );
  res.status(201).json({ ok: true, message: 'Message recorded. Thank you for contacting ProofPath AI.' });
});
