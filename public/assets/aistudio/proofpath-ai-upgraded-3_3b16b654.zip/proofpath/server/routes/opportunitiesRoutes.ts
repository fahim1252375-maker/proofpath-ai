import { Router } from 'express';
import crypto from 'node:crypto';
import { getDb } from '../db/database.ts';
import { requireAuth, type AuthenticatedRequest } from '../security/auth.ts';
import type { Opportunity } from '../../src/types/proofpath.ts';

const router = Router();

export function hydrateOpportunity(row: Record<string, unknown>): Opportunity {
  return {
    id: String(row.id),
    name: String(row.name),
    organizer: String(row.organizer),
    category: String(row.category),
    country: String(row.country),
    description: String(row.description),
    eligibility_summary: String(row.eligibility_summary),
    eligibility_rules: JSON.parse(String(row.eligibility_rules || '{}')),
    deadline: String(row.deadline),
    funding: String(row.funding),
    fees: String(row.fees),
    is_free: Boolean(row.is_free),
    is_fully_funded: Boolean(row.is_fully_funded),
    free_certificate: Boolean(row.free_certificate),
    is_paid_internship: Boolean(row.is_paid_internship),
    delivery_mode: String(row.delivery_mode) as Opportunity['delivery_mode'],
    benefits: JSON.parse(String(row.benefits || '[]')),
    required_documents: JSON.parse(String(row.required_documents || '[]')),
    official_website: String(row.official_website),
    registration_url: String(row.registration_url),
    evidence_status: String(row.evidence_status) as Opportunity['evidence_status'],
    source_type: String(row.source_type) as Opportunity['source_type'],
    verification_history: JSON.parse(String(row.verification_history || '[]')),
    is_demo: Boolean(row.is_demo),
    demo_scenario: row.demo_scenario ? String(row.demo_scenario) : null,
    last_checked_at: String(row.last_checked_at),
    created_at: String(row.created_at),
  };
}

router.get('/', (req, res) => {
  const db = getDb();
  const q = String(req.query.q || '').trim().toLowerCase();
  const category = String(req.query.category || '').trim();
  const country = String(req.query.country || '').trim();
  const mode = String(req.query.mode || '').trim();
  const status = String(req.query.status || '').trim();
  const freeOnly = req.query.free === 'true';
  const fundedOnly = req.query.fullyFunded === 'true';
  const certificateOnly = req.query.freeCertificate === 'true';
  const paidInternshipOnly = req.query.paidInternship === 'true';
  const limit = Math.min(Number(req.query.limit || 50), 100);
  const offset = Math.max(Number(req.query.offset || 0), 0);

  const clauses = ['archived_at IS NULL'];
  const values: Array<string | number> = [];

  if (category && category !== 'all') {
    clauses.push('category = ?');
    values.push(category);
  }
  if (country && country !== 'all') {
    clauses.push('LOWER(country) LIKE ?');
    values.push(`%${country.toLowerCase()}%`);
  }
  if (mode && mode !== 'all') {
    clauses.push('delivery_mode = ?');
    values.push(mode);
  }
  if (status && status !== 'all') {
    clauses.push('evidence_status = ?');
    values.push(status);
  }
  if (freeOnly) clauses.push('is_free = 1');
  if (fundedOnly) clauses.push('is_fully_funded = 1');
  if (certificateOnly) clauses.push('free_certificate = 1');
  if (paidInternshipOnly) clauses.push('is_paid_internship = 1');
  if (q) {
    clauses.push('(LOWER(name) LIKE ? OR LOWER(organizer) LIKE ? OR LOWER(description) LIKE ?)');
    values.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }

  const whereSql = clauses.join(' AND ');
  const rows = db
    .prepare(`SELECT * FROM opportunities WHERE ${whereSql} ORDER BY created_at DESC LIMIT ? OFFSET ?`)
    .all(...values, limit, offset) as Array<Record<string, unknown>>;

  const countRow = db
    .prepare(`SELECT COUNT(*) as total FROM opportunities WHERE ${whereSql}`)
    .get(...values) as { total: number };

  res.json({
    opportunities: rows.map(hydrateOpportunity),
    total: countRow.total,
  });
});

router.get('/saved/list', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT o.* FROM opportunities o
       INNER JOIN saved_opportunities s ON s.opportunity_id = o.id
       WHERE s.user_id = ? AND o.archived_at IS NULL
       ORDER BY s.created_at DESC`
    )
    .all(req.user!.userId) as Array<Record<string, unknown>>;
  res.json({ opportunities: rows.map(hydrateOpportunity) });
});

router.post('/save', requireAuth, (req: AuthenticatedRequest, res) => {
  const oppId = String(req.body?.opportunityId || '').trim();
  if (!oppId) {
    res.status(400).json({ error: 'opportunityId is required.' });
    return;
  }
  const db = getDb();
  const exists = db.prepare('SELECT id FROM opportunities WHERE id = ?').get(oppId);
  if (!exists) {
    res.status(404).json({ error: 'Opportunity not found.' });
    return;
  }
  db.prepare(
    `INSERT OR IGNORE INTO saved_opportunities (id, user_id, opportunity_id, created_at)
     VALUES (?, ?, ?, ?)`
  ).run(`sav-${crypto.randomUUID().slice(0, 8)}`, req.user!.userId, oppId, new Date().toISOString());

  res.status(201).json({ ok: true });
});

router.delete('/save/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  db.prepare('DELETE FROM saved_opportunities WHERE user_id = ? AND opportunity_id = ?').run(
    req.user!.userId,
    req.params.id
  );
  res.json({ ok: true });
});

router.post('/compare', (req, res) => {
  const ids = Array.isArray(req.body?.ids) ? req.body.ids.map(String).slice(0, 4) : [];
  if (ids.length === 0) {
    res.status(400).json({ error: 'Select at least 1 opportunity ID to compare.' });
    return;
  }
  const db = getDb();
  const placeholders = ids.map(() => '?').join(',');
  const rows = db
    .prepare(`SELECT * FROM opportunities WHERE id IN (${placeholders}) AND archived_at IS NULL`)
    .all(...ids) as Array<Record<string, unknown>>;

  res.json({ opportunities: rows.map(hydrateOpportunity) });
});

router.get('/:id', (req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM opportunities WHERE id = ? AND archived_at IS NULL')
    .get(req.params.id) as Record<string, unknown> | undefined;
  if (!row) {
    res.status(404).json({ error: 'Opportunity not found.' });
    return;
  }
  res.json({ opportunity: hydrateOpportunity(row) });
});

export default router;
