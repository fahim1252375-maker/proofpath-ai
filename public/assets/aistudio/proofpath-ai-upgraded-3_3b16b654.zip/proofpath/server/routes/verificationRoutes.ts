import { Router } from 'express';
import crypto from 'node:crypto';
import multer from 'multer';
import { z } from 'zod';
import { getDb } from '../db/database.ts';
import { optionalAuth, requireAuth, type AuthenticatedRequest } from '../security/auth.ts';
import { normalizeFilename, validateUploadSignature } from '../security/sanitize.ts';
import {
  analyzeOpportunity,
  getVerificationReportById,
  getVerificationReportByShareToken,
} from '../services/verificationEngine.ts';

const router = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB strict limit
});

const AnalyzeSchema = z.object({
  rawText: z.string().max(20000).optional().default(''),
  officialUrl: z.string().max(500).optional().nullable(),
  registrationUrl: z.string().max(500).optional().nullable(),
  officialEvidenceText: z.string().max(15000).optional().nullable(),
  opportunityId: z.string().max(80).optional().nullable(),
  inputType: z.enum(['text', 'url', 'document', 'demo']).optional(),
  language: z.enum(['en', 'bn']).optional(),
});

router.post('/analyze', optionalAuth, async (req: AuthenticatedRequest, res) => {
  const parsed = AnalyzeSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid verification request payload.', details: parsed.error.flatten() });
    return;
  }

  const d = parsed.data;
  if (!d.rawText.trim() && !d.officialUrl?.trim()) {
    res.status(400).json({ error: 'Provide announcement text or an official URL to verify.' });
    return;
  }

  try {
    const report = await analyzeOpportunity({
      userId: req.user?.userId ?? null,
      opportunityId: d.opportunityId ?? null,
      rawText: d.rawText,
      officialUrl: d.officialUrl,
      registrationUrl: d.registrationUrl,
      officialEvidenceText: d.officialEvidenceText,
      inputType: d.inputType || (d.officialUrl ? 'url' : 'text'),
      language: d.language || 'en',
    });
    res.status(201).json({ report });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Verification failed.';
    if (message.startsWith('SSRF_BLOCKED_URL:')) {
      res.status(400).json({ error: message.replace('SSRF_BLOCKED_URL:', '').trim() });
      return;
    }
    res.status(500).json({ error: 'Verification engine failed to complete analysis.' });
  }
});

router.post('/analyze-document', optionalAuth, upload.single('file'), async (req: AuthenticatedRequest, res) => {
  if (!req.file) {
    res.status(400).json({ error: 'No file uploaded. Supported types: PDF, PNG, JPG, JPEG, WebP, TXT.' });
    return;
  }

  const cleanName = normalizeFilename(req.file.originalname);
  const validSig = validateUploadSignature(req.file.buffer, req.file.mimetype, cleanName);
  if (!validSig) {
    res.status(400).json({
      error: 'File failed MIME type or signature validation. Supported: PDF, PNG, JPG, WebP, TXT (max 5 MB).',
    });
    return;
  }

  try {
    const notesText = typeof req.body.notes === 'string' ? req.body.notes : '';
    const txtFallback =
      req.file.mimetype === 'text/plain' ? req.file.buffer.toString('utf8').slice(0, 12000) : '';

    const report = await analyzeOpportunity({
      userId: req.user?.userId ?? null,
      rawText: [notesText, txtFallback].filter(Boolean).join('\n\n') || `Uploaded file: ${cleanName}`,
      officialUrl: typeof req.body.officialUrl === 'string' ? req.body.officialUrl : null,
      officialEvidenceText:
        typeof req.body.officialEvidenceText === 'string' ? req.body.officialEvidenceText : null,
      inputType: 'document',
      language: req.body.language === 'bn' ? 'bn' : 'en',
      uploadedFile:
        req.file.mimetype !== 'text/plain'
          ? {
              buffer: req.file.buffer,
              mimeType: req.file.mimetype,
              originalName: cleanName,
            }
          : undefined,
    });
    res.status(201).json({ report, filename: cleanName, sizeBytes: req.file.size });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Document analysis failed.';
    if (message.startsWith('SSRF_BLOCKED_URL:')) {
      res.status(400).json({ error: message.replace('SSRF_BLOCKED_URL:', '').trim() });
      return;
    }
    res.status(500).json({ error: 'Document verification failed.' });
  }
});

router.get('/history', requireAuth, (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const limit = Math.min(Number(req.query.limit || 25), 100);
  const offset = Math.max(Number(req.query.offset || 0), 0);

  const rows = db
    .prepare(
      `SELECT id, opportunity_name, organizer_name, category, input_type, overall_assessment,
              evidence_quality, analysis_mode, model_used, is_public_share, share_token, created_at
       FROM verification_reports
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`
    )
    .all(req.user!.userId, limit, offset);

  const totalRow = db
    .prepare('SELECT COUNT(*) as total FROM verification_reports WHERE user_id = ?')
    .get(req.user!.userId) as { total: number };

  res.json({ reports: rows, total: totalRow.total });
});

router.get('/public/:shareToken', (req, res) => {
  const report = getVerificationReportByShareToken(req.params.shareToken);
  if (!report) {
    res.status(404).json({ error: 'Shared verification report not found or sharing disabled.' });
    return;
  }
  // Strip user_id for privacy in shared reports
  res.json({ report: { ...report, user_id: null } });
});

router.get('/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
  const report = getVerificationReportById(String(req.params.id));
  if (!report) {
    res.status(404).json({ error: 'Verification report not found.' });
    return;
  }

  // Ownership check: anonymous guest reports created during current session or owned by current user/admin
  if (
    report.user_id &&
    (!req.user || (report.user_id !== req.user.userId && req.user.role !== 'admin'))
  ) {
    res.status(403).json({ error: 'Forbidden: you do not own this verification report.' });
    return;
  }

  res.json({ report });
});

router.post('/:id/share', requireAuth, (req: AuthenticatedRequest, res) => {
  const report = getVerificationReportById(String(req.params.id));
  if (!report) {
    res.status(404).json({ error: 'Report not found.' });
    return;
  }
  if (report.user_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Forbidden.' });
    return;
  }

  const enable = Boolean(req.body?.enable ?? true);
  const token = enable ? report.share_token || crypto.randomBytes(12).toString('hex') : null;
  const db = getDb();
  db.prepare('UPDATE verification_reports SET is_public_share = ?, share_token = ? WHERE id = ?').run(
    enable ? 1 : 0,
    token,
    report.id
  );

  res.json({ is_public_share: enable, share_token: token });
});

router.delete('/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const report = getVerificationReportById(String(req.params.id));
  if (!report) {
    res.status(404).json({ error: 'Report not found.' });
    return;
  }
  if (report.user_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Forbidden.' });
    return;
  }

  const db = getDb();
  db.prepare('DELETE FROM verification_reports WHERE id = ?').run(report.id);
  res.json({ ok: true });
});

export default router;
