import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { getDb } from '../db/database.ts';
import { requireAuth, requireRole, type AuthenticatedRequest } from '../security/auth.ts';
import { env, isGeminiConfigured } from '../config/env.ts';
import { CLAIM_STATUSES, SOURCE_TYPES } from '../../src/types/proofpath.ts';

const router = Router();

// Strictly enforce authentication and admin/moderator RBAC on ALL /api/admin routes
router.use(requireAuth, requireRole('admin', 'moderator'));

function logAdminAction(actorId: string, action: string, targetType: string, targetId: string, details: unknown) {
  const db = getDb();
  db.prepare(
    'INSERT INTO admin_logs (id, actor_id, action, target_type, target_id, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(
    `alog-${crypto.randomUUID().slice(0, 8)}`,
    actorId,
    action,
    targetType,
    targetId,
    JSON.stringify(details ?? {}),
    new Date().toISOString()
  );
}

router.get('/analytics', (_req, res) => {
  const db = getDb();
  const totalUsers = (db.prepare('SELECT COUNT(*) as c FROM users WHERE deleted_at IS NULL').get() as { c: number }).c;
  const totalReports = (db.prepare('SELECT COUNT(*) as c FROM verification_reports').get() as { c: number }).c;
  const totalOpportunities = (
    db.prepare('SELECT COUNT(*) as c FROM opportunities WHERE archived_at IS NULL').get() as { c: number }
  ).c;
  const pendingCommunity = (
    db.prepare("SELECT COUNT(*) as c FROM community_reports WHERE status = 'pending'").get() as { c: number }
  ).c;
  const claimDistribution = db
    .prepare('SELECT status, COUNT(*) as count FROM opportunity_claims GROUP BY status')
    .all();
  const riskDistribution = db
    .prepare('SELECT risk_category, COUNT(*) as count FROM risk_assessments GROUP BY risk_category')
    .all();
  const categoryBreakdown = db
    .prepare('SELECT category, COUNT(*) as count FROM opportunities WHERE archived_at IS NULL GROUP BY category')
    .all();
  const aiSummary = db
    .prepare(
      `SELECT mode, COUNT(*) as requests, SUM(prompt_tokens) as prompt_tokens, SUM(output_tokens) as output_tokens,
              SUM(CASE WHEN success = 0 THEN 1 ELSE 0 END) as failures
       FROM ai_usage_logs GROUP BY mode`
    )
    .all();

  res.json({
    totals: {
      users: totalUsers,
      verificationReports: totalReports,
      opportunities: totalOpportunities,
      pendingCommunityReports: pendingCommunity,
    },
    claimDistribution,
    riskDistribution,
    categoryBreakdown,
    aiSummary,
  });
});

router.get('/users', requireRole('admin'), (_req, res) => {
  const db = getDb();
  const users = db
    .prepare(
      'SELECT id, email, name, role, status, preferred_language, timezone, created_at FROM users WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 100'
    )
    .all();
  res.json({ users });
});

router.put('/users/:id', requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    role: z.enum(['student', 'moderator', 'admin']).optional(),
    status: z.enum(['active', 'suspended']).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid user update fields.' });
    return;
  }

  const db = getDb();
  const current = db.prepare('SELECT id, role, status FROM users WHERE id = ?').get(req.params.id) as
    | { id: string; role: string; status: string }
    | undefined;
  if (!current) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const nextRole = parsed.data.role ?? current.role;
  const nextStatus = parsed.data.status ?? current.status;
  db.prepare('UPDATE users SET role = ?, status = ?, updated_at = ? WHERE id = ?').run(
    nextRole,
    nextStatus,
    new Date().toISOString(),
    req.params.id
  );
  logAdminAction(req.user!.userId, 'USER_UPDATED', 'user', String(req.params.id), {
    role: nextRole,
    status: nextStatus,
  });
  res.json({ ok: true });
});

router.get('/opportunities', (_req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, name, organizer, category, country, deadline, fees, evidence_status, is_demo, archived_at FROM opportunities ORDER BY created_at DESC')
    .all();
  res.json({ opportunities: rows });
});

router.post('/opportunities', (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    name: z.string().min(3).max(160),
    organizer: z.string().min(2).max(140),
    category: z.string().min(2).max(60),
    country: z.string().min(2).max(80),
    description: z.string().min(10).max(2000),
    eligibility_summary: z.string().min(3).max(500),
    deadline: z.string().min(4).max(40),
    funding: z.string().max(160),
    fees: z.string().max(160),
    official_website: z.string().url(),
    registration_url: z.string().url(),
    evidence_status: z.enum(CLAIM_STATUSES).default('UNVERIFIED'),
    source_type: z.enum(SOURCE_TYPES).default('Official organization website'),
    is_free: z.boolean().default(true),
    is_fully_funded: z.boolean().default(false),
    delivery_mode: z.enum(['remote', 'in_person', 'hybrid']).default('remote'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid opportunity payload.', details: parsed.error.flatten() });
    return;
  }
  const d = parsed.data;
  const id = `opp-${crypto.randomUUID().slice(0, 8)}`;
  const now = new Date().toISOString();
  const db = getDb();
  db.prepare(`
    INSERT INTO opportunities (
      id, name, organizer, category, country, description, eligibility_summary,
      eligibility_rules, deadline, funding, fees, is_free, is_fully_funded,
      free_certificate, is_paid_internship, delivery_mode, benefits, required_documents,
      official_website, registration_url, evidence_status, source_type,
      verification_history, is_demo, demo_scenario, last_checked_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, '{}', ?, ?, ?, ?, ?, 0, 0, ?, '[]', '[]', ?, ?, ?, ?, '[]', 0, NULL, ?, ?, ?)
  `).run(
    id,
    d.name,
    d.organizer,
    d.category,
    d.country,
    d.description,
    d.eligibility_summary,
    d.deadline,
    d.funding,
    d.fees,
    d.is_free ? 1 : 0,
    d.is_fully_funded ? 1 : 0,
    d.delivery_mode,
    d.official_website,
    d.registration_url,
    d.evidence_status,
    d.source_type,
    now,
    now,
    now
  );
  logAdminAction(req.user!.userId, 'OPPORTUNITY_CREATED', 'opportunity', id, { name: d.name });
  res.status(201).json({ id });
});

router.delete('/opportunities/:id', (req: AuthenticatedRequest, res) => {
  const db = getDb();
  db.prepare('UPDATE opportunities SET archived_at = ? WHERE id = ?').run(
    new Date().toISOString(),
    req.params.id
  );
  logAdminAction(req.user!.userId, 'OPPORTUNITY_ARCHIVED', 'opportunity', String(req.params.id), {});
  res.json({ ok: true });
});

router.get('/sources', (_req, res) => {
  const db = getDb();
  const sources = db.prepare('SELECT * FROM evidence_sources ORDER BY created_at DESC').all();
  res.json({ sources });
});

router.post('/sources', (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    domain: z.string().trim().min(3).max(160),
    organization_name: z.string().trim().min(2).max(160),
    source_type: z.enum(SOURCE_TYPES),
    reliability_explanation: z.string().trim().min(5).max(500),
    official_website: z.string().url(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid source registry entry.' });
    return;
  }
  const db = getDb();
  const id = `src-${crypto.randomUUID().slice(0, 8)}`;
  const d = parsed.data;
  db.prepare(`
    INSERT INTO evidence_sources (id, domain, organization_name, source_type, reliability_explanation, official_website, verified_by_admin, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
  `).run(
    id,
    d.domain.toLowerCase(),
    d.organization_name,
    d.source_type,
    d.reliability_explanation,
    d.official_website,
    new Date().toISOString()
  );
  logAdminAction(req.user!.userId, 'SOURCE_ADDED', 'evidence_source', id, { domain: d.domain });
  res.status(201).json({ id });
});

router.get('/community-reports', (_req, res) => {
  const db = getDb();
  const reports = db
    .prepare('SELECT * FROM community_reports ORDER BY created_at DESC LIMIT 100')
    .all();
  res.json({ reports });
});

router.put('/community-reports/:id', (req: AuthenticatedRequest, res) => {
  const schema = z.object({
    status: z.enum(['pending', 'under_review', 'approved', 'rejected', 'needs_evidence']),
    moderator_notes: z.string().max(1000).default(''),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid moderation status.' });
    return;
  }

  const db = getDb();
  const now = new Date().toISOString();
  db.prepare('UPDATE community_reports SET status = ?, moderator_notes = ?, updated_at = ? WHERE id = ?').run(
    parsed.data.status,
    parsed.data.moderator_notes,
    now,
    req.params.id
  );
  db.prepare(
    'INSERT INTO moderation_logs (id, report_id, moderator_id, action, reason, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(
    `mod-${crypto.randomUUID().slice(0, 8)}`,
    req.params.id,
    req.user!.userId,
    parsed.data.status,
    parsed.data.moderator_notes,
    now
  );
  logAdminAction(req.user!.userId, 'MODERATION_ACTION', 'community_report', String(req.params.id), {
    status: parsed.data.status,
  });

  res.json({ ok: true });
});

router.get('/reports', (_req, res) => {
  const db = getDb();
  const reports = db
    .prepare(
      `SELECT id, user_id, opportunity_name, organizer_name, category, overall_assessment,
              evidence_quality, analysis_mode, model_used, created_at
       FROM verification_reports ORDER BY created_at DESC LIMIT 100`
    )
    .all();
  res.json({ reports });
});

router.get('/ai-usage', (_req, res) => {
  const db = getDb();
  const logs = db.prepare('SELECT * FROM ai_usage_logs ORDER BY created_at DESC LIMIT 100').all();
  res.json({ logs });
});

router.get('/security-logs', (_req, res) => {
  const db = getDb();
  const adminLogs = db.prepare('SELECT * FROM admin_logs ORDER BY created_at DESC LIMIT 100').all();
  const moderationLogs = db
    .prepare('SELECT * FROM moderation_logs ORDER BY created_at DESC LIMIT 100')
    .all();
  res.json({ adminLogs, moderationLogs });
});

router.get('/system-health', (_req, res) => {
  const db = getDb();
  const dbOk = Boolean(db.prepare('SELECT 1 as ok').get());
  res.json({
    status: 'healthy',
    database: {
      engine: 'sqlite (node:sqlite persistent WAL)',
      connected: dbOk,
      mongodbAdapterConfigured: Boolean(env.MONGODB_URI),
    },
    ai: {
      geminiConfigured: isGeminiConfigured(),
      activeModel: isGeminiConfigured() ? env.GEMINI_MODEL : 'deterministic-demo-engine',
    },
    monitoringScheduler: {
      automatedCronActive: false,
      note: 'Monitoring job records are stored; continuous background polling requires an external cron worker or Cloud Scheduler.',
    },
    timestamp: new Date().toISOString(),
  });
});

export default router;
