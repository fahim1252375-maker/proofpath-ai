import crypto from 'node:crypto';
import { Router } from 'express';
import { getDb } from '../db/database.ts';
import { requireAuth, type AuthenticatedRequest } from '../security/auth.ts';

const router = Router();
router.use(requireAuth);

type Row = Record<string, unknown>;

function monthKeys(n: number): string[] {
  const out: string[] = [];
  const d = new Date();
  d.setUTCDate(1);
  for (let i = n - 1; i >= 0; i--) {
    const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - i, 1));
    out.push(x.toISOString().slice(0, 7));
  }
  return out;
}

router.get('/', (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const uid = req.user!.userId;
  const today = new Date().toISOString().slice(0, 10);

  const assessments = db
    .prepare('SELECT overall_assessment AS name, COUNT(*) AS value FROM verification_reports WHERE user_id = ? GROUP BY overall_assessment')
    .all(uid) as Row[];
  const pipeline = db
    .prepare('SELECT status AS name, COUNT(*) AS value FROM applications WHERE user_id = ? GROUP BY status')
    .all(uid) as Row[];
  const repMonth = db
    .prepare("SELECT substr(created_at,1,7) AS m, COUNT(*) AS c FROM verification_reports WHERE user_id = ? GROUP BY m")
    .all(uid) as Row[];
  const appMonth = db
    .prepare("SELECT substr(created_at,1,7) AS m, COUNT(*) AS c FROM applications WHERE user_id = ? GROUP BY m")
    .all(uid) as Row[];
  const upcoming = db
    .prepare('SELECT id, opportunity_name, organizer, deadline, status FROM applications WHERE user_id = ? AND deadline >= ? ORDER BY deadline ASC LIMIT 5')
    .all(uid, today) as Row[];
  const prof = db.prepare('SELECT country, education_level FROM student_profiles WHERE user_id = ?').get(uid) as Row | undefined;
  const saved = db.prepare('SELECT COUNT(*) AS c FROM saved_opportunities WHERE user_id = ?').get(uid) as Row;

  const totalReports = assessments.reduce((s, r) => s + Number(r.value), 0);
  const trusted = assessments
    .filter((r) => r.name === 'VERIFIED' || r.name === 'SUPPORTED')
    .reduce((s, r) => s + Number(r.value), 0);
  const flagged = assessments
    .filter((r) => r.name === 'CONTRADICTED' || r.name === 'EXPIRED')
    .reduce((s, r) => s + Number(r.value), 0);

  const rm = new Map(repMonth.map((r) => [String(r.m), Number(r.c)]));
  const am = new Map(appMonth.map((r) => [String(r.m), Number(r.c)]));
  const trend = monthKeys(6).map((m) => ({ month: m, reports: rm.get(m) ?? 0, applications: am.get(m) ?? 0 }));

  res.json({
    profileComplete: Boolean(prof && prof.country && prof.education_level),
    totals: {
      reports: totalReports,
      applications: pipeline.reduce((s, r) => s + Number(r.value), 0),
      saved: Number(saved?.c ?? 0),
      flagged,
      trustRate: totalReports ? Math.round((trusted / totalReports) * 100) : null,
    },
    assessments: assessments.map((r) => ({ name: String(r.name), value: Number(r.value) })),
    pipeline: pipeline.map((r) => ({ name: String(r.name), value: Number(r.value) })),
    trend,
    upcoming,
  });
});


function parseList(v: unknown): string[] {
  try {
    const a = JSON.parse(String(v ?? '[]'));
    return Array.isArray(a) ? a.map((x) => String(x).toLowerCase()) : [];
  } catch {
    return [];
  }
}

// Explainable ranking: every point of the score has a human-readable reason.
router.get('/matches', (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const prof = db.prepare('SELECT * FROM student_profiles WHERE user_id = ?').get(req.user!.userId) as Row | undefined;
  if (!prof || (!prof.country && !prof.education_level)) {
    res.json({ needsProfile: true, matches: [] });
    return;
  }
  const today = new Date().toISOString().slice(0, 10);
  const cats = parseList(prof.preferred_categories);
  const countries = [...parseList(prof.preferred_countries), String(prof.country || '').toLowerCase()];
  const rows = db
    .prepare('SELECT * FROM opportunities WHERE archived_at IS NULL AND deadline >= ? LIMIT 200')
    .all(today) as Row[];

  const matches = rows
    .map((o) => {
      let score = 0;
      const reasons: string[] = [];
      if (cats.includes(String(o.category).toLowerCase())) { score += 30; reasons.push('Matches your preferred category'); }
      if (countries.includes(String(o.country).toLowerCase())) { score += 20; reasons.push('In your country or preferred location'); }
      if (prof.financial_preference === 'fully_funded_only' ? o.is_fully_funded : prof.financial_preference === 'free_or_funded' ? o.is_free || o.is_fully_funded : false) {
        score += 20; reasons.push('Fits your funding preference');
      }
      if (prof.mode_preference !== 'any' && prof.mode_preference === o.delivery_mode) { score += 10; reasons.push('Delivery mode matches'); }
      if (o.evidence_status === 'VERIFIED') { score += 15; reasons.push('Verified against official sources'); }
      if (o.evidence_status === 'CONTRADICTED') score -= 40;
      const days = Math.ceil((new Date(String(o.deadline)).getTime() - Date.now()) / 86400000);
      if (days <= 14) { score += 5; reasons.push(`Closes in ${days} day${days === 1 ? '' : 's'}`); }
      return { id: o.id, name: o.name, organizer: o.organizer, category: o.category, country: o.country, deadline: o.deadline, funding: o.funding, evidence_status: o.evidence_status, score, reasons };
    })
    .filter((m) => m.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6);
  res.json({ needsProfile: false, matches });
});

// Idempotent: creates one deadline notification per application per day.
router.post('/reminders/sync', (req: AuthenticatedRequest, res) => {
  const db = getDb();
  const uid = req.user!.userId;
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const limit = new Date(now.getTime() + 7 * 86400000).toISOString().slice(0, 10);
  const apps = db
    .prepare("SELECT id, opportunity_name, deadline FROM applications WHERE user_id = ? AND reminder_enabled = 1 AND deadline BETWEEN ? AND ? AND status NOT IN ('SUBMITTED','ACCEPTED','REJECTED','WITHDRAWN')")
    .all(uid, today, limit) as Row[];
  let created = 0;
  for (const a of apps) {
    const link = `/dashboard/applications?reminder=${a.id}-${today}`;
    const exists = db.prepare("SELECT 1 FROM notifications WHERE user_id = ? AND type = 'deadline' AND link = ?").get(uid, link);
    if (exists) continue;
    db.prepare("INSERT INTO notifications (id, user_id, type, title, message, link, is_read, created_at) VALUES (?, ?, 'deadline', ?, ?, ?, 0, ?)")
      .run(`notif-${crypto.randomUUID().slice(0, 8)}`, uid, 'Deadline approaching', `${a.opportunity_name} closes on ${a.deadline}.`, link, now.toISOString());
    created++;
  }
  res.json({ created });
});

function csvCell(v: unknown): string {
  let s = String(v ?? '');
  if (/^[=+\-@]/.test(s)) s = `'${s}`; // block spreadsheet formula injection
  return `"${s.replace(/"/g, '""')}"`;
}

router.get('/export', (req: AuthenticatedRequest, res) => {
  const rows = getDb()
    .prepare('SELECT opportunity_name, organizer, deadline, status, submission_date, interview_date, outcome, notes FROM applications WHERE user_id = ? ORDER BY deadline ASC')
    .all(req.user!.userId) as Row[];
  const cols = ['opportunity_name', 'organizer', 'deadline', 'status', 'submission_date', 'interview_date', 'outcome', 'notes'];
  const csv = [cols.join(','), ...rows.map((r) => cols.map((c) => csvCell(r[c])).join(','))].join('\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="proofpath-applications.csv"');
  res.send(csv);
});

export default router;
