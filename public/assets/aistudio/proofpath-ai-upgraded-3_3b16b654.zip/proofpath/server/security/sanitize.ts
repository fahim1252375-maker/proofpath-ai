import path from 'node:path';

export const ALLOWED_UPLOAD_MIMES = new Set([
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/webp',
  'text/plain',
]);

export const ALLOWED_UPLOAD_EXTENSIONS = new Set(['.pdf', '.png', '.jpg', '.jpeg', '.webp', '.txt']);

export function normalizeFilename(filename: string): string {
  const base = path.basename(filename || 'upload');
  return base.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120);
}

export function validateUploadSignature(buffer: Buffer, mimeType: string, originalName: string): boolean {
  const ext = path.extname(originalName).toLowerCase();
  if (!ALLOWED_UPLOAD_MIMES.has(mimeType) || !ALLOWED_UPLOAD_EXTENSIONS.has(ext)) {
    return false;
  }
  if (buffer.length === 0) return false;

  if (mimeType === 'application/pdf') {
    return buffer.subarray(0, 5).toString('ascii') === '%PDF-';
  }
  if (mimeType === 'image/png') {
    return (
      buffer.length >= 8 &&
      buffer[0] === 0x89 &&
      buffer[1] === 0x50 &&
      buffer[2] === 0x4e &&
      buffer[3] === 0x47
    );
  }
  if (mimeType === 'image/jpeg') {
    return buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  }
  if (mimeType === 'image/webp') {
    return (
      buffer.length >= 12 &&
      buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
      buffer.subarray(8, 12).toString('ascii') === 'WEBP'
    );
  }
  return true;
}

export function wrapUntrustedContent(label: string, text: string): string {
  const cleaned = text.replace(/\0/g, '').slice(0, 18000);
  return `<<<UNTRUSTED_${label}_START>>>\n${cleaned}\n<<<UNTRUSTED_${label}_END>>>`;
}

export function sanitizePlainText(value: string, maxLength = 5000): string {
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, maxLength);
}
