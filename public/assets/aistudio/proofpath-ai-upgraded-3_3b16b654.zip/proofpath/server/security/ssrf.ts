import dns from 'node:dns/promises';
import net from 'node:net';

const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'localhost.localdomain',
  'metadata.google.internal',
  'metadata',
  'instance-data',
  '169.254.169.254',
]);

function isPrivateOrReservedIPv4(ip: string): boolean {
  const parts = ip.split('.').map(Number);
  if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) {
    return true;
  }
  const [a, b] = parts;
  if (a === 0) return true; // 0.0.0.0/8
  if (a === 10) return true; // 10.0.0.0/8
  if (a === 100 && b >= 64 && b <= 127) return true; // Carrier-grade NAT 100.64.0.0/10
  if (a === 127) return true; // Loopback 127.0.0.0/8
  if (a === 169 && b === 254) return true; // Link-local / Cloud metadata 169.254.0.0/16
  if (a === 172 && b >= 16 && b <= 31) return true; // Private 172.16.0.0/12
  if (a === 192 && b === 168) return true; // Private 192.168.0.0/16
  if (a === 198 && (b === 18 || b === 19)) return true; // Benchmark 198.18.0.0/15
  if (a >= 224) return true; // Multicast & reserved
  return false;
}

function isPrivateOrReservedIPv6(ip: string): boolean {
  const normalized = ip.toLowerCase();
  if (normalized === '::' || normalized === '::1') return true;
  if (normalized.startsWith('::ffff:')) {
    const mappedV4 = normalized.slice(7);
    if (net.isIPv4(mappedV4)) return isPrivateOrReservedIPv4(mappedV4);
  }
  if (normalized.startsWith('fc') || normalized.startsWith('fd')) return true; // ULA fc00::/7
  if (normalized.startsWith('fe8') || normalized.startsWith('fe9') || normalized.startsWith('fea') || normalized.startsWith('feb')) {
    return true; // Link-local fe80::/10
  }
  return false;
}

export function isBlockedIp(ip: string): boolean {
  const version = net.isIP(ip);
  if (version === 4) return isPrivateOrReservedIPv4(ip);
  if (version === 6) return isPrivateOrReservedIPv6(ip);
  return true;
}

export interface ValidatedUrlResult {
  valid: boolean;
  url?: URL;
  resolvedIps?: string[];
  reason?: string;
}

export async function validateOutboundUrl(rawUrl: string): Promise<ValidatedUrlResult> {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    return { valid: false, reason: 'Invalid URL syntax.' };
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { valid: false, reason: 'Only HTTP and HTTPS protocols are allowed.' };
  }

  if (parsed.username || parsed.password) {
    return { valid: false, reason: 'Credentials inside URLs are not permitted.' };
  }

  const hostname = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (!hostname || BLOCKED_HOSTNAMES.has(hostname) || hostname.endsWith('.local') || hostname.endsWith('.internal')) {
    return { valid: false, reason: 'Access to local or internal metadata hostnames is blocked.' };
  }

  if (net.isIP(hostname)) {
    if (isBlockedIp(hostname)) {
      return { valid: false, reason: 'Access to private, loopback, or reserved IP ranges is blocked.' };
    }
    return { valid: true, url: parsed, resolvedIps: [hostname] };
  }

  try {
    const addresses = await dns.lookup(hostname, { all: true, verbatim: true });
    if (!addresses.length) {
      return { valid: false, reason: 'Domain did not resolve to any IP address.' };
    }
    for (const addr of addresses) {
      if (isBlockedIp(addr.address)) {
        return {
          valid: false,
          reason: `Resolved IP (${addr.address}) belongs to a private or restricted network range.`,
        };
      }
    }
    return {
      valid: true,
      url: parsed,
      resolvedIps: addresses.map((a) => a.address),
    };
  } catch {
    return { valid: false, reason: 'DNS resolution failed or domain is unreachable.' };
  }
}

export interface SafeFetchResult {
  ok: boolean;
  url: string;
  domain: string;
  status: number;
  title: string;
  excerpt: string;
  error?: string;
}

export async function safeFetchTextSnapshot(rawUrl: string): Promise<SafeFetchResult> {
  let currentUrl = rawUrl.trim();
  const maxRedirects = 3;

  for (let hop = 0; hop <= maxRedirects; hop++) {
    const check = await validateOutboundUrl(currentUrl);
    if (!check.valid || !check.url) {
      return {
        ok: false,
        url: currentUrl,
        domain: '',
        status: 0,
        title: '',
        excerpt: '',
        error: check.reason || 'URL failed SSRF safety validation.',
      };
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);

    try {
      const res = await fetch(check.url.toString(), {
        method: 'GET',
        redirect: 'manual',
        signal: controller.signal,
        headers: {
          'User-Agent': 'ProofPathAI-Verifier/1.0 (Student-Safety-Bot)',
          Accept: 'text/html,text/plain,application/xhtml+xml;q=0.9',
        },
      });

      if (res.status >= 300 && res.status < 400) {
        const location = res.headers.get('location');
        if (!location) {
          return {
            ok: false,
            url: currentUrl,
            domain: check.url.hostname,
            status: res.status,
            title: '',
            excerpt: '',
            error: 'Redirect response missing Location header.',
          };
        }
        currentUrl = new URL(location, check.url).toString();
        continue;
      }

      const contentType = (res.headers.get('content-type') || '').toLowerCase();
      if (!contentType.includes('text/') && !contentType.includes('html') && !contentType.includes('json')) {
        return {
          ok: false,
          url: currentUrl,
          domain: check.url.hostname,
          status: res.status,
          title: '',
          excerpt: '',
          error: 'Remote resource is not readable text/HTML.',
        };
      }

      const reader = res.body?.getReader();
      let received = 0;
      const chunks: Uint8Array[] = [];
      const MAX_BYTES = 262144; // 256 KB limit
      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            received += value.byteLength;
            if (received > MAX_BYTES) {
              chunks.push(value.slice(0, MAX_BYTES - (received - value.byteLength)));
              await reader.cancel();
              break;
            }
            chunks.push(value);
          }
        }
      }

      const decoder = new TextDecoder('utf-8', { fatal: false });
      const rawBody = decoder.decode(Buffer.concat(chunks));
      const titleMatch = rawBody.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const title = titleMatch ? titleMatch[1].replace(/\s+/g, ' ').trim().slice(0, 160) : check.url.hostname;

      const stripped = rawBody
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 2800);

      return {
        ok: res.ok,
        url: currentUrl,
        domain: check.url.hostname,
        status: res.status,
        title,
        excerpt: stripped,
      };
    } catch (err) {
      return {
        ok: false,
        url: currentUrl,
        domain: check.url.hostname,
        status: 0,
        title: '',
        excerpt: '',
        error: err instanceof Error ? err.message : 'Network fetch timed out or failed.',
      };
    } finally {
      clearTimeout(timer);
    }
  }

  return {
    ok: false,
    url: currentUrl,
    domain: '',
    status: 0,
    title: '',
    excerpt: '',
    error: 'Too many redirects.',
  };
}
