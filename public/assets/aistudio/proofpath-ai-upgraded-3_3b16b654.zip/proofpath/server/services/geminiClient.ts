import { GoogleGenAI, type GenerateContentParameters, type GenerateContentResponse } from '@google/genai';
import crypto from 'node:crypto';
import { env, isGeminiConfigured } from '../config/env.ts';
import { getDb } from '../db/database.ts';

let clientInstance: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI | null {
  if (!isGeminiConfigured()) return null;
  if (!clientInstance) {
    clientInstance = new GoogleGenAI({
      apiKey: env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return clientInstance;
}

export function logAiUsage(params: {
  userId?: string | null;
  serviceName: string;
  model: string;
  mode: 'gemini' | 'demo';
  promptTokens?: number;
  outputTokens?: number;
  latencyMs: number;
  success: boolean;
  errorMessage?: string | null;
}): void {
  try {
    const db = getDb();
    db.prepare(`
      INSERT INTO ai_usage_logs (
        id, user_id, service_name, model, mode, prompt_tokens, output_tokens,
        latency_ms, success, error_message, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      `ai-${crypto.randomUUID()}`,
      params.userId ?? null,
      params.serviceName,
      params.model,
      params.mode,
      params.promptTokens ?? 0,
      params.outputTokens ?? 0,
      params.latencyMs,
      params.success ? 1 : 0,
      params.errorMessage ?? null,
      new Date().toISOString()
    );
  } catch {
    // Logging should never crash primary request flow
  }
}

export async function generateWithRetry(
  serviceName: string,
  userId: string | null | undefined,
  params: Omit<GenerateContentParameters, 'model'> & { model?: string }
): Promise<{ response: GenerateContentResponse; model: string; latencyMs: number }> {
  const client = getGeminiClient();
  if (!client) {
    throw new Error('GEMINI_NOT_CONFIGURED');
  }

  const model = params.model || env.GEMINI_MODEL || 'gemini-4-hydrogen';
  const start = Date.now();
  let lastError: unknown;

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const response = await Promise.race([
        client.models.generateContent({
          ...params,
          model,
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Gemini request timed out after 25s')), 25000)
        ),
      ]);

      const latencyMs = Date.now() - start;
      const usage = response.usageMetadata;
      logAiUsage({
        userId,
        serviceName,
        model,
        mode: 'gemini',
        promptTokens: usage?.promptTokenCount ?? 0,
        outputTokens: usage?.candidatesTokenCount ?? 0,
        latencyMs,
        success: true,
      });

      return { response, model, latencyMs };
    } catch (err) {
      lastError = err;
      if (attempt === 0) {
        await new Promise((r) => setTimeout(r, 700));
      }
    }
  }

  const latencyMs = Date.now() - start;
  const message = lastError instanceof Error ? lastError.message : 'Unknown Gemini API error';
  logAiUsage({
    userId,
    serviceName,
    model,
    mode: 'gemini',
    latencyMs,
    success: false,
    errorMessage: message,
  });

  throw lastError;
}
