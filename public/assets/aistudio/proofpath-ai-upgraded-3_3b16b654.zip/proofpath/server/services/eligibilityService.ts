import crypto from 'node:crypto';
import { getDb } from '../db/database.ts';
import type {
  CheckedRequirement,
  EligibilityCheckRecord,
  EligibilityResult,
  Opportunity,
  StudentProfile,
} from '../../src/types/proofpath.ts';

function parseNumericGpa(gpaStr: string): number | null {
  const m = gpaStr.match(/(\d+(?:\.\d+)?)/);
  return m ? Number(m[1]) : null;
}

const ENGLISH_RANK: Record<string, number> = {
  basic: 1,
  intermediate: 2,
  'upper-intermediate': 3,
  advanced: 4,
  native: 5,
};

export function evaluateDeterministicEligibility(params: {
  userId: string;
  profile: StudentProfile | null;
  opportunity: Pick<
    Opportunity,
    'id' | 'name' | 'deadline' | 'is_free' | 'is_fully_funded' | 'delivery_mode' | 'eligibility_rules'
  >;
  language?: 'en' | 'bn';
}): EligibilityCheckRecord {
  const { userId, profile, opportunity, language = 'en' } = params;
  const rules = opportunity.eligibility_rules || {};
  const checked: CheckedRequirement[] = [];
  const missingFields: string[] = [];

  // 1. Deadline Check
  const deadlineMs = Date.parse(opportunity.deadline);
  const isExpired = !Number.isNaN(deadlineMs) && deadlineMs + 86400000 < Date.now();
  checked.push({
    requirement: 'Application Deadline',
    student_value: new Date().toISOString().slice(0, 10),
    opportunity_rule: opportunity.deadline || 'Not specified',
    status: isExpired ? 'not_met' : opportunity.deadline ? 'met' : 'missing_info',
    explanation: isExpired
      ? `The opportunity deadline (${opportunity.deadline}) has already passed.`
      : `Current date is prior to the deadline (${opportunity.deadline}).`,
  });

  // 2. Country / Nationality Check
  if (rules.allowed_countries && rules.allowed_countries.length > 0) {
    const isInternational = rules.allowed_countries.some((c) => c.toLowerCase() === 'international');
    if (isInternational) {
      checked.push({
        requirement: 'Country & Nationality Eligibility',
        student_value: profile?.country || profile?.nationality || 'Not specified',
        opportunity_rule: 'Open to International applicants',
        status: 'met',
        explanation: 'The opportunity rules allow international applicants.',
      });
    } else if (!profile?.country && !profile?.nationality) {
      missingFields.push('country / nationality');
      checked.push({
        requirement: 'Country & Nationality Eligibility',
        student_value: 'Missing in profile',
        opportunity_rule: rules.allowed_countries.join(', '),
        status: 'missing_info',
        explanation: 'Cannot verify country eligibility because your country/nationality is missing.',
      });
    } else {
      const userCountry = (profile.country || '').toLowerCase();
      const userNat = (profile.nationality || '').toLowerCase();
      const matched = rules.allowed_countries.some(
        (c) => c.toLowerCase() === userCountry || c.toLowerCase() === userNat
      );
      checked.push({
        requirement: 'Country & Nationality Eligibility',
        student_value: `${profile.country} (${profile.nationality})`,
        opportunity_rule: `Restricted to: ${rules.allowed_countries.join(', ')}`,
        status: matched ? 'met' : 'not_met',
        explanation: matched
          ? 'Your country/nationality matches the listed eligible countries.'
          : `Your country/nationality (${profile.country || profile.nationality}) is not listed among eligible countries.`,
      });
    }
  }

  // 3. Age Requirement
  if (rules.min_age != null || rules.max_age != null) {
    const ageRangeText = `${rules.min_age ?? 'Any'} – ${rules.max_age ?? 'Any'}`;
    if (profile?.age == null) {
      missingFields.push('age');
      checked.push({
        requirement: 'Age Requirement',
        student_value: 'Missing in profile',
        opportunity_rule: `Age ${ageRangeText}`,
        status: 'missing_info',
        explanation: 'Add your age in your profile to verify age limits.',
      });
    } else {
      const okMin = rules.min_age == null || profile.age >= rules.min_age;
      const okMax = rules.max_age == null || profile.age <= rules.max_age;
      checked.push({
        requirement: 'Age Requirement',
        student_value: String(profile.age),
        opportunity_rule: `Age ${ageRangeText}`,
        status: okMin && okMax ? 'met' : 'not_met',
        explanation:
          okMin && okMax
            ? `Age ${profile.age} is within the allowed range (${ageRangeText}).`
            : `Age ${profile.age} falls outside the required range (${ageRangeText}).`,
      });
    }
  }

  // 4. Education Level
  if (rules.education_levels && rules.education_levels.length > 0) {
    if (!profile?.education_level) {
      missingFields.push('education_level');
      checked.push({
        requirement: 'Education Level',
        student_value: 'Missing in profile',
        opportunity_rule: rules.education_levels.join(', '),
        status: 'missing_info',
        explanation: 'Education level is missing from your student profile.',
      });
    } else {
      const matches = rules.education_levels.some(
        (lvl) => lvl.toLowerCase() === profile.education_level.toLowerCase()
      );
      checked.push({
        requirement: 'Education Level',
        student_value: profile.education_level,
        opportunity_rule: rules.education_levels.join(', '),
        status: matches ? 'met' : 'not_met',
        explanation: matches
          ? `Your level (${profile.education_level}) is eligible.`
          : `Requires ${rules.education_levels.join(' or ')}; your profile states ${profile.education_level}.`,
      });
    }
  }

  // 5. GPA Requirement
  if (rules.min_gpa != null) {
    const parsedGpa = profile?.gpa ? parseNumericGpa(profile.gpa) : null;
    if (parsedGpa == null) {
      missingFields.push('gpa');
      checked.push({
        requirement: 'Academic GPA',
        student_value: 'Missing in profile',
        opportunity_rule: `Minimum ${rules.min_gpa}`,
        status: 'missing_info',
        explanation: 'Your GPA is not filled in; cannot infer academic eligibility.',
      });
    } else {
      checked.push({
        requirement: 'Academic GPA',
        student_value: String(parsedGpa),
        opportunity_rule: `Minimum ${rules.min_gpa}`,
        status: parsedGpa >= rules.min_gpa ? 'met' : 'not_met',
        explanation:
          parsedGpa >= rules.min_gpa
            ? `Reported GPA (${parsedGpa}) meets the ${rules.min_gpa} threshold.`
            : `Reported GPA (${parsedGpa}) is below the ${rules.min_gpa} requirement.`,
      });
    }
  }

  // 6. English Proficiency
  if (rules.english_required) {
    if (!profile?.english_proficiency) {
      missingFields.push('english_proficiency');
      checked.push({
        requirement: 'English Language Proficiency',
        student_value: 'Missing in profile',
        opportunity_rule: rules.english_required,
        status: 'missing_info',
        explanation: 'Add your English proficiency level to check this requirement.',
      });
    } else {
      const userRank = ENGLISH_RANK[profile.english_proficiency.toLowerCase()] ?? 2;
      const reqRank = ENGLISH_RANK[rules.english_required.toLowerCase()] ?? 2;
      checked.push({
        requirement: 'English Language Proficiency',
        student_value: profile.english_proficiency,
        opportunity_rule: rules.english_required,
        status: userRank >= reqRank ? 'met' : 'likely_met',
        explanation:
          userRank >= reqRank
            ? `Your level (${profile.english_proficiency}) meets or exceeds ${rules.english_required}.`
            : `Your profile states ${profile.english_proficiency}; rule expects ${rules.english_required}.`,
      });
    }
  }

  // 7. Financial & Delivery Preference Check
  if (profile?.financial_preference === 'fully_funded_only' && !opportunity.is_fully_funded) {
    checked.push({
      requirement: 'Financial Preference',
      student_value: 'Fully funded only',
      opportunity_rule: opportunity.is_free ? 'Free entry (not fully funded travel/living)' : 'Has fee',
      status: 'likely_met',
      explanation: 'Does not match your "Fully funded only" preference even if academically eligible.',
    });
  } else if (profile?.financial_preference === 'free_or_funded' && !opportunity.is_free) {
    checked.push({
      requirement: 'Financial Preference',
      student_value: 'Free or funded only',
      opportunity_rule: 'Fee required',
      status: 'not_met',
      explanation: 'This opportunity involves a required fee, conflicting with your no-fee preference.',
    });
  }

  // Determine overall deterministic verdict
  const hasFailed = checked.some((c) => c.status === 'not_met');
  const missingCount = checked.filter((c) => c.status === 'missing_info').length;
  const hasLikely = checked.some((c) => c.status === 'likely_met');

  let overallResult: EligibilityResult = 'Eligible';
  if (hasFailed) overallResult = 'Not eligible';
  else if (missingCount >= 2 || checked.length === 0) overallResult = 'Insufficient information';
  else if (missingCount === 1) overallResult = 'Possibly eligible';
  else if (hasLikely) overallResult = 'Likely eligible';

  const recommendationNoteEn =
    overallResult === 'Eligible'
      ? 'All checked criteria match your profile. Always confirm the latest official rules before submitting.'
      : overallResult === 'Not eligible'
        ? 'At least one mandatory requirement or deadline is not met based on your current profile.'
        : 'Complete missing profile fields and verify full official eligibility criteria before investing application time.';

  const recommendationNoteBn =
    overallResult === 'Eligible'
      ? 'আপনার প্রোফাইল অনুযায়ী সকল যাচাইকৃত শর্ত পূরণ হয়েছে। আবেদন করার আগে অফিসিয়াল ওয়েবসাইট থেকে নিশ্চিত হয়ে নিন।'
      : overallResult === 'Not eligible'
        ? 'আপনার প্রোফাইলের সাথে একটি বা একাধিক আবশ্যিক শর্ত বা সময়সীমা মিলছে না।'
        : 'অনুপস্থিত প্রোফাইল তথ্য পূরণ করুন এবং আবেদন করার আগে অফিসিয়াল শর্তাবলি যাচাই করুন।';

  const record: EligibilityCheckRecord = {
    id: `elig-${crypto.randomUUID().slice(0, 8)}`,
    user_id: userId,
    opportunity_id: opportunity.id,
    opportunity_name: opportunity.name,
    overall_result: overallResult,
    checked_requirements: checked,
    missing_profile_fields: missingFields,
    recommendation_note: language === 'bn' ? recommendationNoteBn : recommendationNoteEn,
    created_at: new Date().toISOString(),
  };

  const db = getDb();
  db.prepare(`
    INSERT INTO eligibility_checks (
      id, user_id, opportunity_id, report_id, opportunity_name, overall_result,
      checked_requirements, missing_profile_fields, recommendation_note, created_at
    ) VALUES (?, ?, ?, NULL, ?, ?, ?, ?, ?, ?)
  `).run(
    record.id,
    record.user_id,
    record.opportunity_id,
    record.opportunity_name,
    record.overall_result,
    JSON.stringify(record.checked_requirements),
    JSON.stringify(record.missing_profile_fields),
    record.recommendation_note,
    record.created_at
  );

  return record;
}
