import express from 'express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { env, isGeminiConfigured } from './server/config/env.ts';
import { getDb } from './server/db/database.ts';
import { seedDatabase } from './server/db/seed.ts';
import authRoutes from './server/routes/authRoutes.ts';
import profileRoutes from './server/routes/profileRoutes.ts';
import verificationRoutes from './server/routes/verificationRoutes.ts';
import opportunitiesRoutes from './server/routes/opportunitiesRoutes.ts';
import {
  applicationsRouter,
  assistantRouter,
  communityRouter,
  contactRouter,
  eligibilityRouter,
  notificationsRouter,
} from './server/routes/workflowRoutes.ts';
import adminRoutes from './server/routes/adminRoutes.ts';
import insightsRoutes from './server/routes/insightsRoutes.ts';

export async function createApp() {
  getDb();
  await seedDatabase();

  const app = express();
  app.set('trust proxy', 1);

  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
    })
  );
  app.use(cookieParser());
  app.use(express.json({ limit: '2mb' }));

  const generalLimiter = rateLimit({
    windowMs: 60 * 1000,
    limit: 180,
    standardHeaders: true,
    legacyHeaders: false,
    skip: () => env.NODE_ENV === 'test',
  });

  const aiLimiter = rateLimit({
    windowMs: 60 * 1000,
    limit: 25,
    message: { error: 'Rate limit exceeded for AI analysis. Please wait a minute and retry.' },
    skip: () => env.NODE_ENV === 'test',
  });

  app.use('/api', generalLimiter);

  // CSRF defence in depth: cross-site browsers cannot forge a same-origin Origin header.
  app.use('/api', (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const origin = req.headers.origin;
    if (origin) {
      try {
        if (new URL(origin).host !== req.headers.host) {
          res.status(403).json({ error: 'Cross-origin request blocked.' });
          return;
        }
      } catch {
        res.status(403).json({ error: 'Invalid Origin header.' });
        return;
      }
    }
    next();
  });

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      service: 'ProofPath AI',
      geminiConfigured: isGeminiConfigured(),
      model: isGeminiConfigured() ? env.GEMINI_MODEL : 'demo-mode',
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/openapi.json', (_req, res) => {
    res.json({
      openapi: '3.0.3',
      info: {
        title: 'ProofPath AI API',
        version: '1.0.0',
        description:
          'Student Opportunity Intelligence, Claim Verification, Fraud Risk Assessment, and Eligibility API.',
      },
      paths: {
        '/api/health': { get: { summary: 'System health and AI capability check' } },
        '/api/auth/register': { post: { summary: 'Register student account' } },
        '/api/auth/login': { post: { summary: 'Sign in and issue HTTP-only JWT session' } },
        '/api/auth/me': { get: { summary: 'Current authenticated user' } },
        '/api/verification/analyze': { post: { summary: 'Analyze text or URL opportunity claims' } },
        '/api/verification/analyze-document': {
          post: { summary: 'Analyze uploaded PDF/image announcement' },
        },
        '/api/verification/history': { get: { summary: 'List user verification reports' } },
        '/api/opportunities': { get: { summary: 'Search and filter opportunity registry' } },
        '/api/eligibility/check': { post: { summary: 'Run deterministic student eligibility check' } },
        '/api/applications': { get: { summary: 'List tracked applications' }, post: { summary: 'Create application' } },
        '/api/assistant/chat': { post: { summary: 'ProofPath AI Assistant chat (EN/BN)' } },
        '/api/community/reports': {
          get: { summary: 'List approved advisories' },
          post: { summary: 'Submit community report to moderation queue' },
        },
        '/api/insights': { get: { summary: 'Personal analytics: trust rate, pipeline, trend, deadlines' } },
        '/api/insights/export': { get: { summary: 'Download applications as CSV' } },
        '/api/admin/analytics': { get: { summary: 'Admin analytics (RBAC protected)' } },
      },
    });
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/profile', profileRoutes);
  app.use('/api/verification', aiLimiter, verificationRoutes);
  app.use('/api/opportunities', opportunitiesRoutes);
  app.use('/api/eligibility', eligibilityRouter);
  app.use('/api/applications', applicationsRouter);
  app.use('/api/assistant', aiLimiter, assistantRouter);
  app.use('/api/community', communityRouter);
  app.use('/api/notifications', notificationsRouter);
  app.use('/api/contact', contactRouter);
  app.use('/api/insights', insightsRoutes);
  app.use('/api/admin', adminRoutes);

  // Centralized safe JSON error handler
  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (err.message?.includes('File too large')) {
      res.status(413).json({ error: 'Uploaded file exceeds the 5 MB limit.' });
      return;
    }
    res.status(500).json({ error: 'An internal server error occurred.' });
  });

  return app;
}

const isMainModule =
  process.argv[1] &&
  path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url));

if (isMainModule) {
  const app = await createApp();

  if (env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(env.PORT, '0.0.0.0', () => {
    console.log(`ProofPath AI server running on http://localhost:${env.PORT}`);
  });
}
